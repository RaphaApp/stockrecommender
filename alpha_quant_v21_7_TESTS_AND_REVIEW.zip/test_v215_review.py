"""v21.5 review tests — Japan fetch + parser patch, reviewed against the full application.

Found in review (each has a test that fails on the supplied code):
  * the accessibility adapter was QUADRATIC: a 1.3 MB page took ~22 s to parse (0.03 s before);
  * grossly malformed markup (many unclosed <script>, a flood of "<") could hang parsing;
  * transport failures surfaced as a bare exception class name, and a 403/429 was re-requested
    for every Japanese stock in a scan;
  * the diagnostic double-counted script occurrences and could not show that a visible number
    and an accessible label disagree.

Everything here is a FIXTURE test. No live Yahoo! page is touched; passing says nothing about
live access. Run: pytest -q test_v215_review.py
"""
import copy
import json
import os
import random
import re
import ssl
import sys
import time
import types
import urllib.error
from datetime import datetime, timedelta, timezone

import jp_fake_http
import numpy as np
import pandas as pd
import pytest

import jp_board_transport as tr
import sentiment_sources as ss
from indicators import forum_sentiment_score

HERE = os.path.dirname(os.path.abspath(__file__))
SB, B, N, S, SS = ss.JP_LABELS
H = ss.JP_POLL_HEADINGS[0]
URL = "https://finance.yahoo.co.jp/quote/7203.T/forum"


def cats(v):
    return f"{SB}{v[0]}% {B}{v[1]}% {N}{v[2]}% {S}{v[3]}% {SS}{v[4]}%"


# buy 75.0 / sell 19.0 / watch 6.0 : the headline numbers named in the handoff
C75 = [60.0, 15.0, 6.0, 4.0, 15.0]
DETAIL75 = cats(C75)
DETAIL = cats([62.96, 9.26, 7.41, 3.70, 16.67])         # buy 72.22 / sell 20.37


def page(*parts, heading=True):
    body = "".join(f"<p>{p}</p>" for p in parts)
    return f"<section>{f'<h2>{H}</h2>' if heading else ''}{body}</section>"


# ============================================================ every supported headline layout
FORMS = {
    "label_first": lambda b, s: f"{B} {b}% / {S} {s}%",
    "mixed_percent_then_label": lambda b, s: f"{b}%{B}{S}{s}%",
    "percent_first": lambda b, s: f"{b}%{B}{s}%{S}",
}


@pytest.mark.parametrize("order", ["summary_before", "summary_after"])
@pytest.mark.parametrize("form", sorted(FORMS))
def test_each_supported_headline_layout_before_and_after_the_breakdown(form, order):
    head = FORMS[form](75, 19)
    parts = (head, DETAIL75) if order == "summary_before" else (DETAIL75, head)
    r = ss.parse_jp_board(page(*parts))
    assert r["status"] == "ok", r["reason"]
    assert (r["buy_pct"], r["sell_pct"], r["neutral_pct"]) == (75.0, 19.0, 6.0)
    assert (r["summary_buy_pct"], r["summary_sell_pct"]) == (75.0, 19.0)


@pytest.mark.parametrize("sep", [" / ", ", ", "、", " | ", ""])
def test_summary_separators(sep):
    r = ss.parse_jp_board(page(f"{B} 75%{sep}{S} 19%", DETAIL75))
    assert r["status"] == "ok" and r["summary_sell_pct"] == 19.0


@pytest.mark.parametrize("form", sorted(FORMS))
def test_a_contradictory_summary_is_rejected_in_every_layout(form):
    r = ss.parse_jp_board(page(DETAIL75, FORMS[form](60, 19)))
    assert r["status"] == "parse_error" and r["reason"] == "summary_conflicts_with_categories"
    assert r["buy_pct"] is None


@pytest.mark.parametrize("form", sorted(FORMS))
def test_two_summaries_are_rejected(form):
    r = ss.parse_jp_board(page(DETAIL75, FORMS[form](75, 19), FORMS[form](75, 19)))
    assert r["status"] == "parse_error" and r["reason"] == "duplicate_or_ambiguous_summary"


def test_two_different_summary_layouts_for_the_same_numbers_are_still_two_summaries():
    r = ss.parse_jp_board(page(DETAIL75, FORMS["label_first"](75, 19), FORMS["percent_first"](75, 19)))
    assert r["status"] == "parse_error"


def test_the_breakdown_repeated_is_rejected():
    assert ss.parse_jp_board(page(DETAIL75, DETAIL75))["reason"] == "duplicate_label"


def test_a_one_sided_summary_beside_an_ordered_breakdown_is_refused_visibly():
    """Stricter than v21.4, which accepted it. Refusing is fail-visible; no live layout is
    known to need it. The score is never guessed."""
    r = ss.parse_jp_board(page(DETAIL75, f"{B} 75%"))
    assert r["status"] == "parse_error" and r["reason"] == "unresolved_numeric_poll_labels"


def test_a_sell_first_summary_is_not_a_recognised_layout_and_fails_visibly():
    r = ss.parse_jp_board(page(DETAIL75, f"{S} 19% / {B} 75%"))
    assert r["status"] == "parse_error" and r["buy_pct"] is None


def test_precise_category_sums_are_scored_not_the_rounded_headline():
    r = ss.parse_jp_board(page(DETAIL, FORMS["label_first"](72, 20)))
    assert (r["buy_pct"], r["sell_pct"]) == (pytest.approx(72.22), pytest.approx(20.37))
    assert forum_sentiment_score(r["buy_pct"], r["sell_pct"], r["neutral_pct"]) \
        != forum_sentiment_score(72.0, 20.0, r["neutral_pct"])


# ---------------------------------------------------- ambiguity (legacy, non-ordered layout)
def _unordered(sb, b, n, s, ss_):
    """Categories separated by words, so no ordered five-label run exists and the
    arithmetic fallback decides."""
    return f"{SB} {sb}% x {B} {b}% x {N} {n}% x {S} {s}% x {SS} {ss_}%"


def test_two_different_readings_that_both_fit_are_ambiguous_not_first_wins():
    detail = _unordered(0, 50.4, 9.6, 20.0, 20.0)
    for order in ((detail, f"{B} 50% {S} 40%"), (f"{B} 50% {S} 40%", detail)):
        r = ss.parse_jp_board(page(*order))
        assert r["status"] == "parse_error" and r["reason"] == "ambiguous_category_summary", order
        assert r["buy_pct"] is None


def test_equal_valued_readings_are_not_ambiguous():
    detail = _unordered(0, 50.0, 10.0, 20.0, 20.0)
    r = ss.parse_jp_board(page(detail, f"{B} 50% {S} 40%"))
    assert r["status"] == "ok" and (r["buy_pct"], r["sell_pct"]) == (50.0, 40.0)


def test_equal_precision_different_values_both_fitting_are_ambiguous():
    """Same display precision, different values (51 vs 50): the older code picked whichever
    came first. Position alone cannot say which is the category."""
    detail = _unordered(0, 51, 9, 20, 20)
    r = ss.parse_jp_board(page(detail, f"{B} 50% {S} 40%"))
    assert r["status"] == "parse_error" and r["reason"] == "ambiguous_category_summary"


# ============================================================ visible + accessible components
ARIA = DETAIL


def _sibling(vis):
    return f'<section><h2>{H}</h2><p>{vis}</p><div aria-label="{ARIA}"></div></section>'


def _nested(vis):
    return f'<section><h2>{H}</h2><div aria-label="{ARIA}"><span>{vis}</span></div></section>'


def test_visible_and_accessible_copies_that_agree():
    r = ss.parse_jp_board(_sibling(DETAIL))
    assert r["status"] == "ok" and "2 agreeing" in r["reason"] and r["buy_pct"] == pytest.approx(72.22)


def test_visible_and_accessible_copies_that_disagree_are_ambiguous():
    r = ss.parse_jp_board(_sibling(cats([10, 20, 30, 20, 20])))
    assert r["status"] == "ambiguous" and r["reason"] == "duplicate_components_disagree"
    assert r["buy_pct"] is None


def test_accessible_label_alone_is_read():
    r = ss.parse_jp_board(f'<section><h2>{H}</h2><div aria-label="{ARIA}"></div></section>')
    assert r["status"] == "ok" and r["buy_pct"] == pytest.approx(72.22)


@pytest.mark.parametrize("label", [
    f"{SB} 10% {B} 20% {N} 30% {S} 40%",                       # four categories
    cats([1, 2, 3, 4, 5]) + " 6%",                             # six percentages
    "share this post"])
def test_incomplete_accessible_labels_are_ignored(label):
    r = ss.parse_jp_board(f'<section><h2>{H}</h2><div aria-label="{label}"></div></section>')
    assert r["status"] != "ok"


def test_accessible_labels_outside_the_poll_scope_are_ignored():
    after = f'<section><h2>{H}</h2><p>no data</p></section><section><div aria-label="{ARIA}"></div></section>'
    before = f'<div aria-label="{ARIA}"></div><section><h2>{H}</h2><p>no data</p></section>'
    for html in (after, before):
        assert ss.parse_jp_board(html)["buy_pct"] is None, html


def test_nested_disagreement_is_not_caught_by_the_scorer_but_the_diagnostic_says_so():
    """KNOWN LIMITATION, pinned. When the visible numbers sit INSIDE the aria-labelled element
    the adapter's injected heading ends the visible scope, so the scorer reads the accessible
    label and never sees the different visible numbers. Scoring is deliberately unchanged (the
    live layout that works may depend on it); the diagnostic surfaces the conflict."""
    html = _nested(cats([10, 20, 30, 20, 20]))
    r = ss.parse_jp_board(html)
    assert r["status"] == "ok" and r["buy_pct"] == pytest.approx(72.22)
    d = ss.describe_poll_page(html)
    assert d["source_disagreement"] is True
    assert d["poll_source"] in ("visible_and_accessible", "accessible_label")
    sys.path.insert(0, HERE)
    import jp_board_diagnose as jd
    assert "WARNING" in jd.verdict(d) and "DIFFERENT numbers" in jd.verdict(d)


def test_the_diagnostic_reports_which_source_produced_the_poll():
    assert ss.describe_poll_page(page(DETAIL))["poll_source"] == "visible_text"
    assert ss.describe_poll_page(_sibling(DETAIL))["poll_source"] == "visible_and_accessible"
    only = f'<section><h2>{H}</h2><div aria-label="{ARIA}"></div></section>'
    assert ss.describe_poll_page(only)["poll_source"] == "accessible_label"
    assert ss.describe_poll_page(page(DETAIL))["source_disagreement"] is False
    assert ss.describe_poll_page(_sibling(DETAIL))["source_disagreement"] is False


# ============================================================ unrelated percentages in adjacent sections
def test_numbers_in_an_adjacent_section_are_never_attributed_to_the_poll():
    other = cats([10, 21, 2, 30, 37])
    after = f"<section><h2>{H}</h2><p>no data yet</p></section><section><h2>投稿</h2><p>{other}</p></section>"
    before = f"<section><h2>投稿</h2><p>{other}</p></section><section><h2>{H}</h2><p>no data yet</p></section>"
    for html in (after, before):
        r = ss.parse_jp_board(html)
        assert r["status"] != "ok" and r["buy_pct"] is None, html


def test_unrelated_percentages_inside_the_scope_do_not_corrupt_a_valid_poll():
    r = ss.parse_jp_board(page("前日比 +2.3% 出来高 15%", DETAIL, "年初来 -12.1%"))
    assert r["status"] == "ok" and r["buy_pct"] == pytest.approx(72.22)


def test_a_poll_beside_unrelated_labelled_numbers_is_refused_not_guessed():
    r = ss.parse_jp_board(page(DETAIL, f"{B} 99%"))
    assert r["status"] == "parse_error"


# ============================================================ speed and bounded behaviour
def _big(n_tags):
    return ("<html><body>" + page(FORMS["label_first"](72, 20), DETAIL)
            + "<div class='c'><span>text 12.5%</span></div>" * (n_tags // 2) + "</body></html>")


def _best(fn, arg, reps=3):
    best = 9e9
    for _ in range(reps):
        t = time.perf_counter()
        fn(arg)
        best = min(best, time.perf_counter() - t)
    return best


def test_a_realistic_large_page_parses_quickly():
    """The supplied adapter took ~22 s here (60,000 tags, 1.3 MB)."""
    p = _big(60_000)
    assert ss.parse_jp_board(p)["status"] == "ok"
    assert _best(ss.parse_jp_board, p) < 2.0


def test_parse_time_grows_roughly_linearly_with_page_size():
    small, large = _best(ss.parse_jp_board, _big(20_000)), _best(ss.parse_jp_board, _big(80_000))
    assert large < max(small * 9, 0.05), (small, large)      # linear ~4x; quadratic would be ~16x


@pytest.mark.parametrize("name,raw,reason", [
    ("unclosed script", "<html><body>" + "<script>" * 50_000 + "</body></html>", "malformed_html_unclosed_blocks"),
    ("unclosed style", "<html>" + "<style>" * 50_000 + "</html>", "malformed_html_unclosed_blocks"),
    ("unclosed head", "<html>" + "<head>" * 20_000, "malformed_html_unclosed_blocks"),
    ("angle flood", "<" * 400_000, "malformed_html_angle_flood")])
def test_grossly_malformed_markup_is_refused_instantly_and_visibly(name, raw, reason):
    t = time.perf_counter()
    r = ss.parse_jp_board(raw)
    d = ss.describe_poll_page(raw)
    assert time.perf_counter() - t < 1.0, name
    assert r["status"] == "parse_error" and r["reason"] == reason and r["buy_pct"] is None
    assert d["malformed_html"] == reason


def test_ordinary_script_heavy_pages_do_not_trip_the_malformed_guard():
    scripts = "".join(f"<script>for(i=0;i<n;i++){{}}</script>" for _ in range(300))
    scripts += "<script>" + "if(a<b){}" * 8000 + "</script>"
    page_ = ("<html><head><title>x</title><style>a{}</style></head><body><header>h</header>"
             + scripts + "<header>again</header>" + page(DETAIL) + "</body></html>")
    assert ss.markup_problem(page_) is None
    assert ss.parse_jp_board(page_)["status"] == "ok"


def _reference_accessible_poll_text(raw):
    """The supplied (quadratic) implementation, kept ONLY as a test oracle."""
    def replace(match):
        tag = match.group(0)
        prefix = raw[:match.start()]
        heading = max((prefix.rfind(h) for h in ss.JP_POLL_HEADINGS), default=-1)
        if heading < 0 or ss._BOUNDARY.search(prefix, heading):
            return tag
        attr = re.search(r'\baria-label\s*=\s*([\x22\x27])(.*?)\1', tag, re.I | re.S)
        if not attr:
            return tag
        import html as _h
        text = _h.unescape(attr.group(2))
        if all(lab in text for lab in ss.JP_LABELS) and len(re.findall(r'\d+(?:\.\d+)?\s*[%\uff05]', text)) == 5:
            return tag + '<h6>みんなの評価</h6>' + _h.escape(text) + '<h6>poll detail end</h6>'
        return tag
    return re.sub(r'<[^>]+>', replace, raw)


def test_the_linear_adapter_is_identical_to_the_supplied_one_on_random_pages():
    rng = random.Random(215)
    good = [cats([62.96, 9.26, 7.41, 3.70, 16.67]), cats([10, 21, 2, 30, 37]), cats([0, 0, 100, 0, 0])]
    bad = [f"{SB}10% {B}20% {N}30% {S}40%", cats([1, 2, 3, 4, 5]) + " 6%", "just some label", ""]

    def token():
        r = rng.random()
        if r < 0.12: return f"<h2>{H}</h2>"
        if r < 0.16: return H
        if r < 0.30: return rng.choice(["<section>", "</section>", "<h3>x</h3>", "<nav>", "<footer>", "<article>", "</article>", "<aside>"])
        if r < 0.50:
            text = rng.choice(good + bad); q = rng.choice(['"', "'"])
            attr = rng.choice(["aria-label", "ARIA-LABEL", "Aria-Label", "aria-label "])
            if rng.random() < 0.15: text = text.replace("%", "&#37;")
            return f"<div {attr}={q}{text}{q}>"
        if r < 0.58: return f'<span class="aria-label">{rng.choice(good)}</span>'
        if r < 0.70: return rng.choice(["<div>", "</div>", "<p>", "</p>", "<span>", "</span>", "<br/>"])
        if r < 0.85: return rng.choice(good)
        return rng.choice(["text 12.5%", "hello", "株価 100円", "<img alt='x'>", "<a href=\"#\">"])
    injected = 0
    for _ in range(1500):
        p = "".join(token() for _ in range(rng.randint(3, 60)))
        a, b = _reference_accessible_poll_text(p), ss._accessible_poll_text(p)
        assert a == b, p
        injected += a != p
    assert injected > 300, "the generator must exercise the adapter"


# ============================================================ the real transport (fake HTTP only)
def test_transport_success_returns_text_and_provenance():
    text, meta = tr.fetch_board_page("7203.T", opener=lambda req, timeout=None, context=None:
                                     jp_fake_http.FakeResponse("<p>ok</p>".encode(), URL))
    assert text == "<p>ok</p>"
    assert meta["source_url"] == URL and meta["http_status"] == 200 and meta["transport"] == "urllib_verified_tls"
    assert meta["page_bytes"] == len("<p>ok</p>") and meta["fetched_at"].endswith("+00:00")
    datetime.fromisoformat(meta["fetched_at"])


@pytest.mark.parametrize("bad", ["AAPL", "7203", "72030.T", "7203.T/../x", "7203.TO", "", None, "7203.T?x=1", " ../.T"])
def test_transport_rejects_anything_that_is_not_a_tokyo_ticker(bad):
    with pytest.raises(tr.BoardTransportError) as e:
        tr.fetch_board_page(bad, opener=lambda *a, **k: pytest.fail("no request for an invalid ticker"))
    assert e.value.reason == "invalid_ticker" and isinstance(e.value, ValueError)


def test_transport_accepts_alphanumeric_codes_and_normalises_case():
    for t in ("285A.T", "7203.t"):
        tr.fetch_board_page(t, opener=lambda req, timeout=None, context=None: jp_fake_http.FakeResponse(
            b"x", f"https://finance.yahoo.co.jp/quote/{t.upper()}/forum"))


def test_transport_refuses_a_redirect():
    with pytest.raises(tr.BoardTransportError) as e:
        tr.fetch_board_page("7203.T", opener=lambda req, timeout=None, context=None:
                            jp_fake_http.FakeResponse(b"x", "https://login.yahoo.co.jp/consent"))
    assert e.value.reason == "unexpected_redirect"


def test_transport_enforces_the_size_cap_and_reads_no_more_than_the_cap_plus_one():
    seen = {}

    class Big(jp_fake_http.FakeResponse):
        def read(self, n=-1):
            seen["n"] = n
            return super().read(n)
    body = b"x" * (tr.MAX_PAGE_BYTES + 10)
    with pytest.raises(tr.BoardTransportError) as e:
        tr.fetch_board_page("7203.T", opener=lambda req, timeout=None, context=None: Big(body, URL))
    assert e.value.reason == "page_too_large" and seen["n"] == tr.MAX_PAGE_BYTES + 1
    ok = tr.fetch_board_page("7203.T", opener=lambda req, timeout=None, context=None:
                             jp_fake_http.FakeResponse(b"x" * tr.MAX_PAGE_BYTES, URL))
    assert ok[1]["page_bytes"] == tr.MAX_PAGE_BYTES


@pytest.mark.parametrize("code", [403, 429, 500, 503])
def test_http_errors_keep_their_status_code(code):
    def op(req, timeout=None, context=None):
        raise urllib.error.HTTPError(URL, code, "x", {}, None)
    with pytest.raises(urllib.error.HTTPError) as e:
        tr.fetch_board_page("7203.T", opener=op)
    assert e.value.code == code


@pytest.mark.parametrize("exc,reason", [
    (urllib.error.URLError(ssl.SSLCertVerificationError("bad cert")), "tls_verification_failed"),
    (ssl.SSLError("handshake"), "tls_verification_failed"),
    (TimeoutError(), "timeout"),
    (urllib.error.URLError(TimeoutError()), "timeout"),
    (urllib.error.URLError("no route"), "network_error"),
    (ConnectionResetError(), "network_error")])
def test_transport_failures_carry_a_stable_reason(exc, reason):
    def op(req, timeout=None, context=None):
        raise exc
    with pytest.raises(tr.BoardTransportError) as e:
        tr.fetch_board_page("7203.T", opener=op)
    assert e.value.reason == reason


def test_a_tls_failure_tells_the_user_about_the_ca_bundle_and_keeps_verification_on():
    def op(req, timeout=None, context=None):
        raise ssl.SSLCertVerificationError("bad")
    with pytest.raises(tr.BoardTransportError) as e:
        tr.fetch_board_page("7203.T", opener=op)
    assert "STOCKREC_CA_BUNDLE" in str(e.value)


def test_insecure_ssl_switch_is_ignored_and_verification_stays_on(monkeypatch):
    monkeypatch.setenv("STOCKREC_INSECURE_SSL", "1")
    monkeypatch.setenv("STOCKREC_INSECURE", "1")
    got = {}

    def op(req, timeout=None, context=None):
        got["ctx"], got["req"] = context, req
        return jp_fake_http.FakeResponse(b"x", URL)
    tr.fetch_board_page("7203.T", opener=op)
    assert got["ctx"].verify_mode == ssl.CERT_REQUIRED and got["ctx"].check_hostname is True


def test_the_request_carries_no_cookie_or_credential_headers():
    got = {}

    def op(req, timeout=None, context=None):
        got["h"] = {k.lower(): v for k, v in req.header_items()}
        return jp_fake_http.FakeResponse(b"x", URL)
    tr.fetch_board_page("7203.T", opener=op)
    assert not set(got["h"]) & {"cookie", "authorization", "proxy-authorization", "x-api-key"}
    assert got["h"]["accept-language"] == "ja"


def test_an_unreadable_ca_bundle_is_reported(monkeypatch, tmp_path):
    monkeypatch.setenv("STOCKREC_CA_BUNDLE", str(tmp_path / "missing.pem"))
    with pytest.raises(tr.BoardTransportError) as e:
        tr.fetch_board_page("7203.T", opener=lambda *a, **k: pytest.fail("must not request"))
    assert e.value.reason == "ca_bundle_unreadable"


def test_an_unknown_charset_name_does_not_crash_decoding():
    text, _ = tr.fetch_board_page("7203.T", opener=lambda req, timeout=None, context=None:
                                  jp_fake_http.FakeResponse("日本語".encode(), URL, charset="x-not-a-real-charset"))
    assert text == "日本語"


def test_a_declared_charset_is_honoured():
    text, _ = tr.fetch_board_page("7203.T", opener=lambda req, timeout=None, context=None:
                                  jp_fake_http.FakeResponse("日本語".encode("shift_jis"), URL, charset="shift_jis"))
    assert text == "日本語"


# ============================================================ the app's status reporting and breaker
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getitem__(self, i): return _Any()
    def __bool__(self): return False
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    def __getattr__(self, n): return _Any()
    def columns(self, spec, **k):
        return [_Any() for _ in range(spec if isinstance(spec, int) else len(spec))]
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    sys.path.insert(0, HERE)
    spec = importlib.util.spec_from_file_location("app_v215", os.path.join(HERE, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    return app


def _frame():
    idx = pd.bdate_range("2026-01-05", periods=230)
    return pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)], "High": [101 * 1.001 ** i for i in range(230)],
                         "Low": [99 * 1.001 ** i for i in range(230)], "Volume": [1e6] * 230}, index=idx)


def _scan_env(app, monkeypatch, tickers=("7203.T",)):
    frame = _frame()
    monkeypatch.setattr(app, "TICKER_UNIVERSE", {"Japan": list(tickers)})
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})
    return frame


def _http(code):
    return urllib.error.HTTPError(URL, code, "x", {}, None)


@pytest.mark.parametrize("exc,status,reason", [
    (urllib.error.URLError(ssl.SSLCertVerificationError("bad")), "network_error", "tls_verification_failed"),
    (TimeoutError(), "network_error", "timeout"),
    (urllib.error.URLError("no route"), "network_error", "network_error"),
    (_http(500), "unavailable", "http_500"),
    (_http(404), "unavailable", "http_404")])
def test_failures_are_reported_with_a_status_and_a_precise_reason_and_no_number(db, monkeypatch, exc, status, reason):
    jp_fake_http.install(monkeypatch, exc)
    d = db.fetch_jp_forum_detail("7203.T")
    assert (d["status"], d["reason"]) == (status, reason)
    assert d["buy_pct"] is None and d["sell_pct"] is None and d["neutral_pct"] is None
    assert db._jp_board_circuit_code() is None, "only 403/429 open the breaker"


def test_a_redirect_and_an_oversized_page_are_unavailable_not_a_network_error(db, monkeypatch):
    jp_fake_http.install(monkeypatch, jp_fake_http.FakeResponse(b"x", "https://login.yahoo.co.jp/c"))
    assert db.fetch_jp_forum_detail("7203.T")["reason"] == "unexpected_redirect"
    jp_fake_http.install(monkeypatch, jp_fake_http.FakeResponse(b"x" * (tr.MAX_PAGE_BYTES + 5), URL))
    d = db.fetch_jp_forum_detail("7203.T")
    assert (d["status"], d["reason"]) == ("unavailable", "page_too_large")


@pytest.mark.parametrize("code", [403, 429])
def test_a_block_stops_further_requests_instead_of_asking_for_every_stock(db, monkeypatch, code):
    calls = []
    jp_fake_http.install(monkeypatch, _http(code), calls)
    first = db.fetch_jp_forum_detail("7203.T")
    rest = [db.fetch_jp_forum_detail(t) for t in ("6758.T", "9984.T", "8306.T")]
    assert len(calls) == 1, "after a 403/429 the app must stop asking"
    assert first["reason"] == f"http_{code}" and first["http_status"] == code
    assert all(r["reason"] == f"circuit_open_http_{code}" and r["status"] == "unavailable" for r in rest)
    assert all(r["buy_pct"] is None for r in rest)


def test_the_breaker_closes_after_the_cooldown(db, monkeypatch):
    calls = []
    jp_fake_http.install(monkeypatch, _http(403), calls)
    db.fetch_jp_forum_detail("7203.T")
    old = datetime.now(timezone.utc) - timedelta(minutes=db.JP_BOARD_CIRCUIT_MINUTES + 1)
    db.st.session_state["_jp_board_circuit"] = {"code": 403, "at": old.isoformat(timespec="seconds")}
    db.fetch_jp_forum_detail("6758.T")
    assert len(calls) == 2


def test_a_missing_transport_module_is_reported_by_name_not_as_a_crash(db, monkeypatch):
    monkeypatch.setattr(db, "_jpt", None)
    d = db.fetch_jp_forum_detail("7203.T")
    assert (d["status"], d["reason"]) == ("unavailable", "jp_board_transport_missing")


def test_blocked_data_never_becomes_a_zero_or_a_neutral_score_in_a_real_scan(db, monkeypatch):
    app = db
    _scan_env(app, monkeypatch)
    jp_fake_http.install(monkeypatch, _http(403))
    on, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    off, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=False)
    assert on[0]["jp_board"]["status"] == "unavailable" and on[0]["jp_board"]["reason"] == "http_403"
    assert str(on[0]["jp_bull"]) == "nan" and str(on[0]["jp_bear"]) == "nan"
    assert on[0]["hype_score"] == pytest.approx(off[0]["hype_score"]), "no poll -> hype untouched, not blended with 0 or 50"
    assert on[0]["composite"] == pytest.approx(off[0]["composite"])


# ============================================================ fetch -> parser -> validity -> hype -> ledger
def test_the_whole_chain_persists_precise_values_summary_provenance_and_transport_metadata(db, monkeypatch):
    app, calls = db, []
    _scan_env(app, monkeypatch)
    html = f"<html><body>{page(FORMS['mixed_percent_then_label'](72, 20), DETAIL)}</body></html>"
    jp_fake_http.install(monkeypatch, html, calls)
    on, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    r = on[0]
    assert len(calls) == 1 and r["jp_forum_enabled"] is True
    assert (r["jp_bull"], r["jp_bear"]) == (pytest.approx(72.22), pytest.approx(20.37))
    with app.get_conn() as c:
        row = c.execute("SELECT retail_sentiment, model_version FROM observations").fetchone()
        snap = c.execute("SELECT inputs FROM observation_snapshots").fetchone()
    rec = json.loads(row[0])["jp_board"]
    assert rec["status"] == "ok"
    assert rec["categories"] == {SB: 62.96, B: 9.26, N: 7.41, S: 3.70, SS: 16.67}
    assert (rec["buy_pct"], rec["sell_pct"], rec["neutral_pct"]) == (pytest.approx(72.22), pytest.approx(20.37), 7.41)
    assert (rec["summary_buy_pct"], rec["summary_sell_pct"]) == (72.0, 20.0)
    assert rec["parser_version"] == ss.JP_PARSER_VERSION and rec["layout"] == "five_category"
    assert rec["source_url"] == URL and rec["http_status"] == 200 and rec["transport"] == "urllib_verified_tls"
    assert rec["fetched_at"].endswith("+00:00") and rec["page_bytes"] == len(html.encode())
    assert row[1] == "composite-v9-manual-stocktwits"
    assert json.loads(json.loads(snap[0])["retail_sentiment"])["jp_board"]["summary_buy_pct"] == 72.0, \
        "the append-only log keeps the provenance too"
    off, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=False)
    fs = forum_sentiment_score(72.22, 20.37, 7.41)
    assert on[0]["hype_score"] == pytest.approx(min(100.0, max(0.0, 0.5 * off[0]["hype_score"] + 0.5 * fs)))
    assert on[0]["composite"] != off[0]["composite"], "an enabled poll that parses DOES change the composite"


def test_the_toggle_is_off_by_default_and_gates_every_scan_path(db, monkeypatch):
    app, calls = db, []
    _scan_env(app, monkeypatch)
    jp_fake_http.install(monkeypatch, f"<html>{page(DETAIL)}</html>", calls)
    assert app.JP_FORUM_DEFAULT_ON is False
    res, _ = app.run_engine(regions=["Japan"], sources=[])
    assert calls == [] and res[0]["jp_forum_enabled"] is False and res[0].get("jp_board") is None
    monkeypatch.setattr(app, "deep_universe_for", lambda region: (["7203.T", "6758.T"], 0))
    app.run_deep_scan("Japan")
    assert calls == [], "Deep Scan must not request the board"


def test_earlier_model_versions_stay_stored_and_only_comparable_ones_are_pooled(db):
    """Superseded in v21.7: an earlier version is pooled where its formula was identical
    (here: a v7 US row) and still excluded where it was not (a v7 Japan row: the Japan board
    was read differently). Nothing is deleted either way. Full rules: test_v217."""
    app = db
    old_v, cur = "composite-v7-jp-summary-crosscheck", app.PRODUCTION_MODEL_VERSION
    rng = np.random.default_rng(3)
    with app.get_conn() as c:
        for d in range(8):
            day = (datetime(2026, 3, 2) + timedelta(days=7 * d)).date().isoformat()
            for i in range(30):
                mv, region = (old_v, "USA") if i < 10 else (old_v, "Japan") if i < 20 else (cur, "USA")
                c.execute("INSERT INTO observations (scan_id, obs_date, ticker, region, composite, rank_pct, factors, x20, model_version) "
                          "VALUES (?,?,?,?,?,?,?,?,?)", ("s", day, f"T{d}-{i}", region, 50 + float(rng.normal()), 50.0, "{}", float(rng.normal()), mv))
        n_all = c.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
    assert n_all == 240, "every row is preserved"
    assert app.composite_summary(20)["n"] == 160, "current + comparable v7 US rows; v7 Japan rows excluded"
    assert app.model_lab_population() == {"current": 80, "pooled_earlier": 80, "excluded": 80}


def test_the_preserved_constants_are_unchanged(app):
    assert {k: round(v, 4) for k, v in app.DEFAULT_WEIGHTS.items()} == {
        "momentum": 0.2, "value": 0.18, "technical": 0.18, "hype": 0.16, "quality": 0.16, "theme": 0.12}
    assert (app.BUY_THRESHOLD, app.SELL_THRESHOLD) == (65.0, 45.0)
    assert app.ENABLE_LEGACY_WEIGHT_LEARNING is False and app.ENABLE_STOCKTWITS is True
    import indicators
    assert indicators.MOMENTUM_REL_SESSIONS == 63


# ============================================================ saved-page import cannot mutate anything
class _Upload:
    def __init__(self, data: bytes, size=None):
        self._d, self.size = data, len(data) if size is None else size

    def getvalue(self):
        return self._d


def _render_with_upload(app, monkeypatch, upload, result):
    rec = {"json": [], "warning": [], "caption": []}
    monkeypatch.setattr(app.st, "file_uploader", lambda *a, **k: upload, raising=False)
    monkeypatch.setattr(app.st, "json", lambda v, **k: rec["json"].append(v), raising=False)
    monkeypatch.setattr(app.st, "warning", lambda v, **k: rec["warning"].append(v), raising=False)
    monkeypatch.setattr(app.st, "caption", lambda v, **k: rec["caption"].append(v), raising=False)
    app.render_hype_sentiment(result)
    return rec


def _ledger_counts(app):
    with app.get_conn() as c:
        return {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                for t in ("observations", "observation_snapshots", "recommendations", "mock_portfolio", "kpi_weights")}


def _result():
    return {"ticker": "7203.T", "hype_score": 55.0, "hype_mentions": 12.0, "hype": {"breakout_days": 2},
            "price_date": "2026-10-09", "composite": 61.5, "recommendation": "HOLD", "jp_forum_enabled": False}


def test_a_saved_page_import_is_shown_but_changes_no_score_and_writes_nothing(db, monkeypatch):
    app = db
    result, before_counts = _result(), _ledger_counts(app)
    snapshot = copy.deepcopy(result)
    weights_before = app.get_latest_weights()
    rec = _render_with_upload(app, monkeypatch, _Upload(f"<html>{page(DETAIL, FORMS['label_first'](72, 20))}</html>".encode()), result)
    shown = rec["json"][0]
    assert shown["status"] == "ok" and shown["buy_pct"] == pytest.approx(72.22) and shown["summary_buy_pct"] == 72.0
    assert result == snapshot, "the scan result must be untouched"
    assert _ledger_counts(app) == before_counts, "nothing may be written to the ledger"
    assert app.get_latest_weights() == weights_before
    assert app.tr("hype_jp_saved_not_scored") in rec["caption"], "the import is labelled as not scored"


def test_an_oversized_saved_page_is_refused_without_parsing(db, monkeypatch):
    app = db
    monkeypatch.setattr(app._ss, "parse_jp_board", lambda *a, **k: pytest.fail("an oversized upload must not be parsed"))
    rec = _render_with_upload(app, monkeypatch, _Upload(b"x", size=5_000_001), _result())
    assert rec["warning"] == [app.tr("hype_jp_saved_large")] and rec["json"] == []


def test_an_unreadable_or_malformed_saved_page_shows_the_reason_and_never_hangs(db, monkeypatch):
    app = db
    t = time.perf_counter()
    rec = _render_with_upload(app, monkeypatch, _Upload(("<html>" + "<script>" * 40_000).encode()), _result())
    assert time.perf_counter() - t < 2.0
    assert rec["json"] == [] and rec["warning"] == ["malformed_html_unclosed_blocks"]
    rec = _render_with_upload(app, monkeypatch, _Upload(b"<html>Access denied</html>"), _result())
    assert rec["json"] == [] and rec["warning"] == ["poll_heading_not_found"]


def test_non_tokyo_results_get_no_saved_page_control(db, monkeypatch):
    app = db
    monkeypatch.setattr(app.st, "file_uploader", lambda *a, **k: pytest.fail("no uploader for a US listing"), raising=False)
    app.render_hype_sentiment(dict(_result(), ticker="AAPL"))


def test_the_saved_page_control_is_a_per_ticker_widget_so_one_upload_cannot_leak_to_another(db, monkeypatch):
    app, keys = db, []
    monkeypatch.setattr(app.st, "file_uploader", lambda *a, **k: (keys.append(k.get("key")), None)[1], raising=False)
    app.render_hype_sentiment(dict(_result(), ticker="7203.T"))
    app.render_hype_sentiment(dict(_result(), ticker="6758.T"))
    assert keys[0] != keys[1] and "7203.T" in keys[0] and "6758.T" in keys[1]


# ============================================================ the diagnostic script
def _run_diag(tmp_path, html, *args):
    import subprocess
    f = tmp_path / "saved.html"
    f.write_text(html, encoding="utf-8")
    return subprocess.run([sys.executable, os.path.join(HERE, "jp_board_diagnose.py"), "--file", str(f), *args],
                          capture_output=True, text=True, cwd=HERE, timeout=60)


def test_diagnose_writes_a_run_record_with_the_fields_needed_to_preserve_a_working_case(tmp_path):
    rec = tmp_path / "run.json"
    r = _run_diag(tmp_path, page(FORMS["label_first"](72, 20), DETAIL), "--record", str(rec))
    assert r.returncode == 0 and "READABLE" in r.stdout
    d = json.loads(rec.read_text())
    assert d["status"] == "ok" and d["buy_pct"] == pytest.approx(72.22) and d["neutral_pct"] == 7.41
    assert (d["summary_buy_pct"], d["summary_sell_pct"]) == (72.0, 20.0)
    assert d["parser_version"] == ss.JP_PARSER_VERSION and d["poll_source"] == "visible_text"
    assert set(d) >= {"ticker", "fetched_at", "http_status", "page_bytes", "transport"}


def test_diagnose_poll_fixture_is_small_reproduces_the_result_and_drops_the_rest_of_the_page(tmp_path):
    secret_page = (f"<html><head><title>x</title><script>token=SECRET123</script></head><body>"
                   f"<nav>user@example.com logged in</nav>" + page(FORMS["label_first"](72, 20), DETAIL)
                   + "<footer>private account stuff</footer></body></html>")
    fx = tmp_path / "poll.html"
    r = _run_diag(tmp_path, secret_page, "--poll-html", str(fx))
    text = fx.read_text(encoding="utf-8")
    assert "round-trip check: the fixture reproduces the original result." in r.stdout
    assert "SECRET123" not in text and "user@example.com" not in text and "private account" not in text
    assert len(text) < len(secret_page)
    again = ss.parse_jp_board(text)
    assert again["status"] == "ok" and again["buy_pct"] == pytest.approx(72.22)


def test_diagnose_fixture_round_trip_holds_for_accessible_label_layouts(tmp_path):
    for html in (_sibling(DETAIL), f'<section><h2>{H}</h2><div aria-label="{ARIA}"></div></section>', _nested(DETAIL)):
        fx = tmp_path / "poll.html"
        r = _run_diag(tmp_path, f"<html><body>{html}</body></html>", "--poll-html", str(fx))
        assert "reproduces the original result" in r.stdout, html


def test_diagnose_warns_when_a_fixture_would_contain_something_that_looks_secret(tmp_path):
    html = page(DETAIL, "contact: someone@example.com")
    r = _run_diag(tmp_path, html, "--poll-html", str(tmp_path / "p.html"))
    assert "looks like a secret or an e-mail address" in r.stdout


def test_diagnose_explains_malformed_and_script_only_pages(tmp_path):
    assert "too malformed to parse safely" in _run_diag(tmp_path, "<html>" + "<script>" * 40_000).stdout
    only = f'<html><div id="r"></div><script>{{"{H}":1,"{SB}":62.96,"{B}":9.26}}</script></html>'
    assert "ONLY inside script data" in _run_diag(tmp_path, only).stdout


def test_diagnose_counts_a_script_occurrence_once_and_sees_escaped_json_too():
    plain = f'<html><script>{{"{H}":1,"{SB}":62.96}}</script></html>'
    d = ss.describe_poll_page(plain)
    assert d["heading_in_script_data"] == 1 and d["label_counts_script_data"][SB] == 1
    esc = ("".join(f"\\u{ord(c):04x}" for c in H))
    d2 = ss.describe_poll_page(f'<html><script>{{"k":"{esc}"}}</script></html>')
    assert d2["heading_in_script_data"] == 1 and d2["heading_in_visible_text"] == 0
    assert ss.parse_jp_board(f'<html><script>{{"k":"{esc} {cats([10, 21, 2, 30, 37])}"}}</script></html>')["buy_pct"] is None, \
        "script data is for DETECTION only and is never scored"


def test_diagnose_fetch_failures_report_the_reason_and_never_guess(monkeypatch, capsys):
    sys.path.insert(0, HERE)
    import jp_board_diagnose as jd
    monkeypatch.setattr(jd, "fetch_page", lambda t, timeout=15.0: (_ for _ in ()).throw(tr.BoardTransportError("tls_verification_failed", "bad cert")))
    assert jd.main(["7203.T"]) == 2
    out = capsys.readouterr().out
    assert "FETCH FAILED" in out and "tls_verification_failed" in out and "STOCKREC_CA_BUNDLE" in out
    monkeypatch.setattr(jd, "fetch_page", lambda t, timeout=15.0: (_ for _ in ()).throw(urllib.error.HTTPError(URL, 403, "x", {}, None)))
    assert jd.main(["7203.T"]) == 2
    out = capsys.readouterr().out
    assert "403" in out and "no bypass is attempted" in out


def test_diagnose_a_successful_fetch_records_the_retrieval_metadata(tmp_path, monkeypatch, capsys):
    sys.path.insert(0, HERE)
    import jp_board_diagnose as jd
    html = f"<html>{page(DETAIL)}</html>"
    meta = {"fetched_at": "2026-10-16T01:02:03+00:00", "http_status": 200, "page_bytes": len(html), "transport": "urllib_verified_tls"}
    monkeypatch.setattr(jd, "fetch_page", lambda t, timeout=15.0: (html, meta))
    out = tmp_path / "run.json"
    assert jd.main(["7203.T", "--record", str(out)]) == 0
    rec = json.loads(out.read_text())
    assert rec["ticker"] == "7203.T" and rec["fetched_at"] == "2026-10-16T01:02:03+00:00" and rec["http_status"] == 200


# ============================================================ restored snapshots and both UI languages (real Streamlit)
@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    from test_v213_hype_panel import PANEL_SCRIPT, PANEL_DRIVER, _run_driver, jp_ok, JP_BASE, UNUSABLE
    new_shape = dict(jp_ok(72.22, 7.41, 20.37), summary_buy_pct=72.0, summary_sell_pct=20.0, source_url=URL,
                     http_status=200, transport="urllib_verified_tls", page_bytes=123456,
                     fetched_at="2026-10-14T14:29:03+00:00")
    cases = {
        "new_applied": dict(JP_BASE, jp_board=new_shape, jp_bull=72.22, jp_bear=20.37, jp_forum_enabled=True),
        # a snapshot saved by an older build: no jp_forum_enabled, no summary or transport fields
        "restored_old_ok": dict(JP_BASE, jp_board=jp_ok(), jp_bull=31.0, jp_bear=67.0),
        "restored_old_none": dict(JP_BASE),
        "blocked": dict(JP_BASE, jp_forum_enabled=True, jp_board=dict(UNUSABLE("http_403", "unavailable"), http_status=403)),
        "circuit": dict(JP_BASE, jp_forum_enabled=True, jp_board=UNUSABLE("circuit_open_http_429", "unavailable")),
        "tls": dict(JP_BASE, jp_forum_enabled=True, jp_board=UNUSABLE("tls_verification_failed", "network_error")),
        "malformed": dict(JP_BASE, jp_forum_enabled=True, jp_board=UNUSABLE("malformed_html_unclosed_blocks", "parse_error")),
        "ambiguous": dict(JP_BASE, jp_forum_enabled=True, jp_board=UNUSABLE("ambiguous_category_summary", "parse_error")),
    }
    batch = {f"{n}|{lang}": {"record": r, "lang": lang} for n, r in cases.items() for lang in ("en", "ja")}
    res = _run_driver(PANEL_DRIVER, tmp_path_factory.mktemp("panel215"), batch, PANEL_SCRIPT)
    for k, v in res.items():
        assert not v["exceptions"], (k, v["exceptions"])
    return res


def T(key, lang="en", **kw):
    import config
    return config.TRANSLATIONS[lang][key].format(**kw)


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_restored_snapshots_without_the_new_fields_render_in_both_languages(panel, lang):
    for name in ("restored_old_ok", "restored_old_none", "new_applied"):
        r = panel[f"{name}|{lang}"]
        assert "みんなの評価" in " | ".join(r["markdown"]) and "Stocktwits" in " | ".join(r["markdown"]), name
    assert panel[f"restored_old_ok|{lang}"]["metric"][T("crowd_jp_buy", lang)] == "31.00%"
    assert T("hype_feed_not_collected", lang) in panel[f"restored_old_none|{lang}"]["caption"]


@pytest.mark.parametrize("lang", ["en", "ja"])
@pytest.mark.parametrize("name,reason", [("blocked", "http_403"), ("circuit", "circuit_open_http_429"),
                                         ("tls", "tls_verification_failed"), ("malformed", "malformed_html_unclosed_blocks"),
                                         ("ambiguous", "ambiguous_category_summary")])
def test_every_failure_reason_is_visible_and_never_a_number(panel, name, reason, lang):
    r = panel[f"{name}|{lang}"]
    assert any(reason in t for t in r["text"]), "the reason is shown in the source details"
    assert T("hype_no_number", lang) in r["info"] and T("hype_jp_diag_hint", lang) in r["caption"]
    assert not any("%" in v for v in r["metric"].values())


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_a_new_shape_record_shows_the_summary(panel, lang):
    assert T("hype_jp_summary", lang, buy="72%", sell="20%") in panel[f"new_applied|{lang}"]["text"]


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_the_saved_page_control_is_offered_for_tokyo_listings_in_both_languages(panel, lang):
    for name in ("new_applied", "restored_old_ok", "restored_old_none", "blocked", "tls"):
        assert T("hype_jp_saved_title", lang) in panel[f"{name}|{lang}"]["expander"], (name, lang)
