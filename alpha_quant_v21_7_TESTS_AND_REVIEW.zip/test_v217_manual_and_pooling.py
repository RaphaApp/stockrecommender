"""v21.7 tests — hand-entered Stocktwits scores, Guba links, and Model Lab pooling.

1. MANUAL STOCKTWITS SCORE. The Stocktwits API is not available, so the user may read the
   sentiment score on the public page and type it in for a US listing. A FRESH entry (<= 72 h)
   is blended 50/50 into Hype from the next MAIN scan. Tested here: validation, storage,
   expiry, the blend through a real scan, what is written to the ledger, that nothing else
   moves, that Deep Scan / Sell Scanner / non-US listings ignore it, and the entry form
   clicked in real Streamlit.
2. GUBA LINKS for mainland-China and Hong Kong listings (links only; nothing is fetched).
3. MODEL LAB POOLING. Earlier model versions are pooled only where the formula was identical.

Fixtures only; no network. Run: pytest -q test_v217_manual_and_pooling.py
"""
import copy
import json
import os
import sys
import textwrap
import types
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd
import pytest

from indicators import MANUAL_SENTIMENT_BLEND, blend_manual_sentiment, manual_sentiment_value

HERE = os.path.dirname(os.path.abspath(__file__))


# ============================================================ pure scoring helpers
@pytest.mark.parametrize("raw,expected", [(28, 28.0), ("28", 28.0), (0, 0.0), (100, 100.0), (49.5, 49.5),
                                          (None, None), (True, None), (False, None), ("x", None), ("", None),
                                          (float("nan"), None), (float("inf"), None), (-1, None), (100.01, None),
                                          ([28], None), ({}, None)])
def test_manual_value_validation(raw, expected):
    assert manual_sentiment_value(raw) == expected


def test_the_blend_is_half_and_half_like_the_japan_poll():
    assert MANUAL_SENTIMENT_BLEND == 0.5
    assert blend_manual_sentiment(50.0, 28) == pytest.approx(39.0)
    assert blend_manual_sentiment(80.0, 0) == pytest.approx(40.0)
    assert blend_manual_sentiment(10.0, 100) == pytest.approx(55.0)


@pytest.mark.parametrize("bad", [None, "x", float("nan"), -5, 250, True])
def test_an_unusable_entry_leaves_hype_untouched_and_never_becomes_50(bad):
    assert blend_manual_sentiment(73.0, bad) == 73.0


# ============================================================ app fixtures
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getitem__(self, i): return _Any()
    def __bool__(self): return False
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    secrets: dict = {}          # `name in st.secrets` must terminate (no credentials configured)
    def __getattr__(self, n): return _Any()
    def columns(self, spec, **k):
        return [_Any() for _ in range(spec if isinstance(spec, int) else len(spec))]
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    sys.path.insert(0, HERE)
    spec = importlib.util.spec_from_file_location("app_v217", os.path.join(HERE, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    return app


def _old_entry(app, ticker, score, hours_ago, source="stocktwits"):
    at = (datetime.now(timezone.utc) - timedelta(hours=hours_ago)).isoformat(timespec="seconds")
    with app.get_conn() as c:
        c.execute("INSERT INTO manual_sentiment (ticker, source, score, entered_at) VALUES (?,?,?,?)",
                  (ticker, source, score, at))
        c.commit()


# ============================================================ storage
def test_save_read_replace_and_clear(db):
    app = db
    assert app.manual_sentiment_entries() == {}
    rec = app.save_manual_sentiment("mpc", 28)
    assert rec["ticker"] == "MPC" and rec["score"] == 28.0 and rec["entered_at"].endswith("+00:00")
    e = app.manual_sentiment_entries()["MPC"]
    assert e["score"] == 28.0 and e["fresh"] is True and 0 <= e["age_hours"] < 0.1
    app.save_manual_sentiment("MPC", 61)
    assert app.manual_sentiment_entries(["MPC"])["MPC"]["score"] == 61.0, "the latest entry wins"
    app.clear_manual_sentiment("MPC")
    assert app.manual_sentiment_entries() == {}
    with app.get_conn() as c:
        assert c.execute("SELECT COUNT(*) FROM manual_sentiment").fetchone()[0] == 3, "history is kept"


@pytest.mark.parametrize("ticker", ["7203.T", "SHEL.L", "0700.HK", "600519.SS", "^GSPC", "", "AA PL"])
def test_only_us_listings_can_carry_a_stocktwits_entry(db, ticker):
    with pytest.raises(ValueError):
        db.save_manual_sentiment(ticker, 50)
    assert db.manual_sentiment_entries() == {}


@pytest.mark.parametrize("bad", [None, "abc", -1, 101, float("nan"), True])
def test_bad_numbers_are_refused_not_stored(db, bad):
    with pytest.raises(ValueError):
        db.save_manual_sentiment("MPC", bad)
    assert db.manual_sentiment_entries() == {}


def test_entries_expire_after_the_limit(db):
    app = db
    assert app.MANUAL_SENTIMENT_MAX_AGE_HOURS == 72
    _old_entry(app, "MPC", 28, hours_ago=71)
    _old_entry(app, "XOM", 40, hours_ago=73)
    e = app.manual_sentiment_entries()
    assert e["MPC"]["fresh"] is True and e["XOM"]["fresh"] is False
    assert e["XOM"]["score"] == 40.0, "an expired entry is still shown, just not used"


def test_a_database_without_the_table_simply_has_no_entries(app, tmp_path):
    app.DB_PATH = str(tmp_path / "never_initialised.db")
    assert app.manual_sentiment_entries() == {}


# ============================================================ through a real main scan
def _frame():
    idx = pd.bdate_range("2026-01-05", periods=230)
    return pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)], "High": [101 * 1.001 ** i for i in range(230)],
                         "Low": [99 * 1.001 ** i for i in range(230)], "Volume": [1e6] * 230}, index=idx)


def _env(app, monkeypatch, universe):
    frame = _frame()
    monkeypatch.setattr(app, "TICKER_UNIVERSE", universe)
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_expectations", lambda t: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})
    return frame


OTHER = ("momentum", "value", "technical", "quality", "theme")


def test_a_fresh_entry_is_blended_into_hype_and_nothing_else_moves(db, monkeypatch):
    app = db
    _env(app, monkeypatch, {"USA": ["MPC", "XOM"]})
    base = {r["ticker"]: r for r in app.run_engine(regions=["USA"], sources=[])[0]}
    assert base["MPC"]["manual_sentiment"] is None and "st_manual" not in base["MPC"]
    app.save_manual_sentiment("MPC", 28)
    got = {r["ticker"]: r for r in app.run_engine(regions=["USA"], sources=[])[0]}
    mpc, h0 = got["MPC"], base["MPC"]["hype_score"]
    assert mpc["hype_score"] == pytest.approx(0.5 * h0 + 0.5 * 28)
    assert mpc["manual_sentiment"] == {"score": 28.0, "hype_before": pytest.approx(h0)}
    assert mpc["st_manual"]["applied"] is True and mpc["st_manual"]["score"] == 28.0 and mpc["st_manual"]["expired"] is False
    for f in OTHER:
        assert mpc[f] == base["MPC"][f], f"a manual entry must not change {f}"
    w = mpc["weights_snapshot"]["hype"]
    assert mpc["composite"] == pytest.approx(base["MPC"]["composite"] + w * (mpc["hype_score"] - h0))
    # a stock WITHOUT an entry is scored exactly as before
    for k in ("hype_score", "composite", "recommendation"):
        assert got["XOM"][k] == base["XOM"][k]
    assert "st_manual" not in got["XOM"]


def test_the_switch_turns_every_entry_off(db, monkeypatch):
    app = db
    _env(app, monkeypatch, {"USA": ["MPC"]})
    base = app.run_engine(regions=["USA"], sources=[])[0][0]
    app.save_manual_sentiment("MPC", 5)
    off = app.run_engine(regions=["USA"], sources=[], use_manual_sentiment=False)[0][0]
    assert off["hype_score"] == base["hype_score"] and off["composite"] == base["composite"]
    assert off["manual_sentiment"] is None and "st_manual" not in off


def test_expired_and_cleared_entries_are_not_used_but_expiry_is_reported(db, monkeypatch):
    app = db
    _env(app, monkeypatch, {"USA": ["MPC", "XOM"]})
    base = {r["ticker"]: r for r in app.run_engine(regions=["USA"], sources=[])[0]}
    _old_entry(app, "MPC", 5, hours_ago=100)
    app.save_manual_sentiment("XOM", 5)
    app.clear_manual_sentiment("XOM")
    got = {r["ticker"]: r for r in app.run_engine(regions=["USA"], sources=[])[0]}
    assert got["MPC"]["hype_score"] == base["MPC"]["hype_score"]
    assert got["MPC"]["st_manual"]["applied"] is False and got["MPC"]["st_manual"]["expired"] is True
    assert got["XOM"]["hype_score"] == base["XOM"]["hype_score"] and "st_manual" not in got["XOM"]


def test_an_entry_row_for_a_non_us_listing_is_ignored_even_if_it_reaches_the_table(db, monkeypatch):
    app = db
    _env(app, monkeypatch, {"Japan": ["7203.T"], "Europe": ["SHEL.L"]})
    base = {r["ticker"]: r for r in app.run_engine(regions=["Japan", "Europe"], sources=[])[0]}
    _old_entry(app, "7203.T", 1, hours_ago=1)
    _old_entry(app, "SHEL.L", 1, hours_ago=1)
    got = {r["ticker"]: r for r in app.run_engine(regions=["Japan", "Europe"], sources=[])[0]}
    for t in ("7203.T", "SHEL.L"):
        assert got[t]["hype_score"] == base[t]["hype_score"] and got[t]["manual_sentiment"] is None


def test_the_ledger_records_the_entry_its_effect_and_the_model_version(db, monkeypatch):
    app = db
    _env(app, monkeypatch, {"USA": ["MPC"]})
    app.save_manual_sentiment("MPC", 28)
    r = app.run_engine(regions=["USA"], sources=[])[0][0]
    with app.get_conn() as c:
        row = c.execute("SELECT retail_sentiment, candidates, model_version FROM observations").fetchone()
        snap = c.execute("SELECT inputs FROM observation_snapshots").fetchone()
    man = json.loads(row[0])["stocktwits_manual"]
    assert man["score"] == 28.0 and man["applied"] is True and man["expired"] is False
    assert man["hype_before"] == pytest.approx(r["manual_sentiment"]["hype_before"]) and man["entered_at"].endswith("+00:00")
    assert json.loads(row[1])["stocktwits_manual_score"] == 28.0
    assert row[2] == app.PRODUCTION_MODEL_VERSION == "composite-v9-manual-stocktwits"
    assert json.loads(json.loads(snap[0])["retail_sentiment"])["stocktwits_manual"]["score"] == 28.0


def test_an_expired_entry_is_not_offered_to_the_model_lab_as_a_candidate(db, monkeypatch):
    app = db
    _env(app, monkeypatch, {"USA": ["MPC"]})
    _old_entry(app, "MPC", 28, hours_ago=200)
    app.run_engine(regions=["USA"], sources=[])
    with app.get_conn() as c:
        assert "stocktwits_manual_score" not in json.loads(c.execute("SELECT candidates FROM observations").fetchone()[0])


def test_deep_scan_and_sell_scanner_ignore_manual_entries(db, monkeypatch):
    app = db
    frame = _env(app, monkeypatch, {"USA": ["MPC"]})
    monkeypatch.setattr(app, "deep_universe_for", lambda region: (["MPC", "XOM"], 0))
    monkeypatch.setattr(app, "fetch_analyst_signals", lambda t: {
        "changes": [], "num_analysts": 0, "rec_key": "", "rec_mean": float("nan"), "target_mean": float("nan"), "currency": ""})
    monkeypatch.setattr(app, "fetch_insider_activity", lambda t: {
        "available": False, "buy_value": 0.0, "n_buys": 0, "n_sells": 0, "sell_value": 0.0})
    deep0 = {r["ticker"]: r["hype_score"] for r in app.run_deep_scan("USA")[0]}
    sell0 = app.analyze_sell_signals("MPC", hist=frame)["composite"]
    app.save_manual_sentiment("MPC", 1)
    assert {r["ticker"]: r["hype_score"] for r in app.run_deep_scan("USA")[0]} == deep0
    assert app.analyze_sell_signals("MPC", hist=frame)["composite"] == sell0


def test_the_api_path_and_the_japan_toggle_are_unaffected(db, monkeypatch):
    app = db
    _env(app, monkeypatch, {"USA": ["MPC"]})
    app.save_manual_sentiment("MPC", 28)
    r = app.run_engine(regions=["USA"], sources=[])[0][0]
    assert r["stocktwits"]["status"] == "not_configured", "no API request is ever made without credentials"
    assert app.JP_FORUM_DEFAULT_ON is False and app.ENABLE_LEGACY_WEIGHT_LEARNING is False
    assert (app.BUY_THRESHOLD, app.SELL_THRESHOLD) == (65.0, 45.0)
    assert {k: round(v, 4) for k, v in app.DEFAULT_WEIGHTS.items()} == {
        "momentum": 0.2, "value": 0.18, "technical": 0.18, "hype": 0.16, "quality": 0.16, "theme": 0.12}


# ============================================================ preview (never mutates)
def _scored(app):
    r = {"ticker": "MPC", "momentum": 60.0, "value": 55.0, "technical": 50.0, "hype_score": 48.0,
         "quality": 65.0, "theme": 50.0}
    w = dict(app.DEFAULT_WEIGHTS)
    r.update(app.score_with_weights(r, w))
    r["weights_snapshot"] = w
    return r


def test_preview_shows_the_effect_without_changing_the_result(app):
    r = _scored(app)
    before = copy.deepcopy(r)
    p = app.manual_sentiment_preview(r, 28)
    assert r == before, "a preview must not touch the scan result"
    assert p["hype_now"] == 48.0 and p["hype_new"] == pytest.approx(38.0)
    assert p["composite_new"] == pytest.approx(r["composite"] + r["weights_snapshot"]["hype"] * (38.0 - 48.0))
    assert p["recommendation"] in ("BUY", "HOLD", "SELL")
    assert app.manual_sentiment_preview(r, "abc") is None and app.manual_sentiment_preview(r, None) is None


def test_preview_does_not_blend_twice_when_an_entry_is_already_applied(app):
    r = _scored(app)
    r["manual_sentiment"] = {"score": 28.0, "hype_before": 60.0}
    r["hype_score"] = 44.0                                  # = blend(60, 28)
    assert app.manual_sentiment_preview(r, 28)["hype_new"] == pytest.approx(44.0)
    assert app.manual_sentiment_preview(r, 80)["hype_new"] == pytest.approx(70.0)


# ============================================================ the entry form, in-process
class _Rec:
    def __init__(self): self.caption, self.success = [], []


def _wire(app, monkeypatch, value=None, save=False, clear=False):
    rec = _Rec()
    monkeypatch.setattr(app.st, "caption", lambda v, **k: rec.caption.append(v), raising=False)
    monkeypatch.setattr(app.st, "success", lambda v, **k: rec.success.append(v), raising=False)
    monkeypatch.setattr(app.st, "number_input", lambda *a, **k: value, raising=False)

    class _Col:
        def __init__(self, hit): self.hit = hit
        def button(self, *a, **k): return self.hit
    monkeypatch.setattr(app.st, "columns", lambda n, **k: [_Col(save), _Col(clear)], raising=False)
    monkeypatch.setattr(app.st, "rerun", lambda: None, raising=False)
    return rec


def test_saving_from_the_form_stores_the_entry_and_confirms_on_the_next_render(db, monkeypatch):
    app = db
    r = _scored(app)
    before = copy.deepcopy(r)
    rec = _wire(app, monkeypatch, value=28.0, save=True)
    app._render_manual_stocktwits(r)
    assert app.manual_sentiment_entries()["MPC"]["score"] == 28.0 and r == before
    assert any("Preview on this scan's numbers" in c for c in rec.caption)
    rec = _wire(app, monkeypatch)                               # next render
    app._render_manual_stocktwits(r)
    assert rec.success == [app.tr("manual_st_saved", hours=72)]
    assert any(c.startswith("Your current entry: 28/100") for c in rec.caption)
    assert app.tr("manual_st_next_scan") in rec.caption, "it is not in the scan on screen yet"


def test_the_form_reports_applied_expired_and_cleared_states(db, monkeypatch):
    app = db
    r = dict(_scored(app), st_manual={"score": 28.0, "applied": True, "hype_before": 60.0, "expired": False})
    app.save_manual_sentiment("MPC", 28)
    rec = _wire(app, monkeypatch)
    app._render_manual_stocktwits(r)
    assert app.tr("manual_st_applied", score="28", before="60.0") in rec.caption
    assert app.tr("manual_st_next_scan") not in rec.caption, "the same entry is already in this scan"
    _wire(app, monkeypatch, clear=True)
    app._render_manual_stocktwits(r)
    assert app.manual_sentiment_entries() == {}
    _old_entry(app, "MPC", 33, hours_ago=90)
    rec = _wire(app, monkeypatch)
    app._render_manual_stocktwits(_scored(app))
    assert any("no longer used" in c and "33/100" in c for c in rec.caption)


def test_the_caveat_is_always_shown_with_the_form(db, monkeypatch):
    rec = _wire(db, monkeypatch)
    db._render_manual_stocktwits(_scored(db))
    assert db.tr("manual_st_caveat") in rec.caption


# ============================================================ the form in real Streamlit (clicked)
INTERACT_SCRIPT = textwrap.dedent('''
    import importlib.util, json, os, sys
    import streamlit as st
    HERE = %r
    sys.path.insert(0, HERE)
    if "appmod_cached" not in sys.modules:
        sp = importlib.util.spec_from_file_location("appmod_cached", os.path.join(HERE, "app.py"))
        mod = importlib.util.module_from_spec(sp); sys.modules["appmod_cached"] = mod
        sp.loader.exec_module(mod)
        mod.DB_PATH = os.path.join(os.getcwd(), "live.db"); mod.DEMO_DB_PATH = os.path.join(os.getcwd(), "demo.db")
        mod.init_db()
    m = sys.modules["appmod_cached"]
    st.session_state["lang"] = "en"
    m.render_hype_sentiment(json.loads(st.session_state["case_json"]))
''') % HERE

INTERACT_DRIVER = textwrap.dedent('''
    import json, sqlite3, sys
    from streamlit.testing.v1 import AppTest
    case = json.load(open(sys.argv[1]))
    at = AppTest.from_string(open(sys.argv[2]).read(), default_timeout=120)
    at.session_state["case_json"] = json.dumps(case["record"]); at.run()
    def rows(): return sqlite3.connect("live.db").execute("SELECT ticker, source, score FROM manual_sentiment ORDER BY id").fetchall()
    def btn(prefix): return [b for b in at.button if b.key and b.key.startswith(prefix)][0]
    out = {"labels": [x.label for x in at.number_input], "save_disabled_empty": btn("manual_st_save_").disabled,
           "clear_disabled_empty": btn("manual_st_clear_").disabled}
    at.number_input[0].set_value(28.0).run()
    out["captions_after_typing"] = [c.value for c in at.caption]
    out["rows_after_typing"] = rows()
    btn("manual_st_save_").click().run()
    out["success_after_save"] = [s.value for s in at.success]
    out["captions_after_save"] = [c.value for c in at.caption]
    out["rows_after_save"] = rows()
    btn("manual_st_clear_").click().run()
    out["success_after_clear"] = [s.value for s in at.success]
    out["rows_after_clear"] = rows()
    out["exceptions"] = [e.value for e in at.exception]
    print("RESULT_JSON:" + json.dumps(out))
''')


@pytest.fixture(scope="module")
def clicked(tmp_path_factory):
    from test_v213_hype_panel import _run_driver, US_BASE
    rec = dict(US_BASE, ticker="MPC", momentum=60.0, value=55.0, technical=50.0, quality=65.0, theme=50.0,
               composite=54.4, recommendation="HOLD",
               weights_snapshot={"momentum": 0.2, "value": 0.18, "technical": 0.18, "hype": 0.16, "quality": 0.16, "theme": 0.12})
    out = _run_driver(INTERACT_DRIVER, tmp_path_factory.mktemp("clicked"), {"record": rec}, INTERACT_SCRIPT)
    assert not out["exceptions"], out["exceptions"]
    return out


def T(key, lang="en", **kw):
    import config
    return config.TRANSLATIONS[lang][key].format(**kw)


def test_real_streamlit_typing_previews_but_saves_nothing(clicked):
    assert clicked["labels"] == [T("manual_st_input")]
    assert clicked["save_disabled_empty"] is True and clicked["clear_disabled_empty"] is True
    assert clicked["rows_after_typing"] == [], "typing alone must not store anything"
    assert any(c.startswith("Preview on this scan's numbers: Hype 48.0 → 38.0") for c in clicked["captions_after_typing"])


def test_real_streamlit_save_then_remove(clicked):
    assert clicked["rows_after_save"] == [["MPC", "stocktwits", 28.0]]
    assert clicked["success_after_save"] == [T("manual_st_saved", hours=72)]
    assert any(c.startswith("Your current entry: 28/100") for c in clicked["captions_after_save"])
    assert clicked["rows_after_clear"] == [["MPC", "stocktwits", 28.0], ["MPC", "stocktwits", None]]
    assert clicked["success_after_clear"] == [T("manual_st_cleared")]


# ============================================================ where the form and the links appear (real Streamlit)
@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    from test_v213_hype_panel import PANEL_SCRIPT, PANEL_DRIVER, _run_driver, JP_BASE, US_BASE
    cases = {
        "us": dict(US_BASE),
        "us_applied": dict(US_BASE, st_manual={"score": 28.0, "applied": True, "hype_before": 60.0, "expired": False}),
        "jp": dict(JP_BASE), "uk": {"ticker": "SHEL.L", "hype_score": 40.0},
        "hk": {"ticker": "0700.HK", "hype_score": 40.0}, "cn": {"ticker": "600519.SS", "hype_score": 40.0},
    }
    batch = {f"{n}|{lang}": {"record": r, "lang": lang} for n, r in cases.items() for lang in ("en", "ja")}
    res = _run_driver(PANEL_DRIVER, tmp_path_factory.mktemp("panel217"), batch, PANEL_SCRIPT)
    for k, v in res.items():
        assert not v["exceptions"], (k, v["exceptions"])
    return res


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_the_entry_form_appears_for_us_listings_only(panel, lang):
    us = panel[f"us|{lang}"]
    assert us["number_input"] == [T("manual_st_input", lang)]
    assert T("manual_st_save", lang) in us["button"] and T("manual_st_clear", lang) in us["button"]
    assert T("manual_st_caveat", lang) in us["caption"] and T("hype_st_role", lang) in us["caption"]
    for other in ("jp", "uk", "hk", "cn"):
        assert panel[f"{other}|{lang}"]["number_input"] == [], other


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_an_applied_entry_is_stated_on_the_card(panel, lang):
    assert T("manual_st_applied", lang, score="28", before="60.0") in panel[f"us_applied|{lang}"]["caption"]


def test_the_card_no_longer_claims_stocktwits_never_changes_hype(panel):
    assert not any("Never changes Hype" in c for c in panel["us|en"]["caption"])


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_china_listings_get_a_guba_link_and_an_honest_note(panel, lang):
    for name, url in (("hk", "https://guba.eastmoney.com/list,hk00700.html"),
                      ("cn", "https://guba.eastmoney.com/list,600519.html")):
        r = panel[f"{name}|{lang}"]
        assert r["link_button"] == [{"label": T("hype_open_guba", lang), "url": url, "help": T("hype_link_help", lang)}]
        assert T("hype_guba_note", lang) in r["caption"]
    assert all("guba" not in l["url"] for l in panel[f"us|{lang}"]["link_button"])


# ============================================================ Guba link format
@pytest.mark.parametrize("ticker,url", [
    ("600519.SS", "https://guba.eastmoney.com/list,600519.html"),
    ("000001.SZ", "https://guba.eastmoney.com/list,000001.html"),
    ("0700.HK", "https://guba.eastmoney.com/list,hk00700.html"),
    ("9988.HK", "https://guba.eastmoney.com/list,hk09988.html"),
    ("1810.hk", "https://guba.eastmoney.com/list,hk01810.html"),
    ("BABA", None), ("7203.T", None), ("SHEL.L", None), ("60051.SS", None), ("ABC.HK", None),
    ("600519.SS/../x", None), ("123456.HK", None)])
def test_guba_links(app, ticker, url):
    assert app.source_links(ticker)["guba"] == url


def test_chinese_adrs_use_stocktwits_not_guba(app):
    for t in ("BABA", "JD", "PDD", "NIO", "BIDU"):
        links = app.source_links(t)
        assert links["stocktwits"] == f"https://stocktwits.com/symbol/{t}" and links["guba"] is None


# ============================================================ Model Lab pooling
VERSIONS = {"v1": "composite-v1-absolute-momentum", "v2": "composite-v2-relative-momentum",
            "v3": "composite-v3-jp-board-parser-fix", "v5": "composite-v5-jp-poll-shared-validity-optin",
            "v7": "composite-v7-jp-summary-crosscheck", "v8": "composite-v8-jp-visible-detail",
            "v9": "composite-v9-manual-stocktwits", "none": None}
LISTINGS = [("AAPL", "USA"), ("7203.T", "Japan"), ("ASML.AS", "Europe"), ("SAP.DE", "Europe"), ("0700.HK", "China")]
EXPECT = {  # which listings are comparable with the current model, per version
    "v1": set(), "none": set(),
    "v2": {"AAPL", "SAP.DE", "0700.HK"},                    # not Japan; not the SPY-benchmarked exchanges
    "v3": {"AAPL", "ASML.AS", "SAP.DE", "0700.HK"}, "v5": {"AAPL", "ASML.AS", "SAP.DE", "0700.HK"},
    "v7": {"AAPL", "ASML.AS", "SAP.DE", "0700.HK"},
    "v8": {t for t, _ in LISTINGS}, "v9": {t for t, _ in LISTINGS},
}


def _fill(app):
    with app.get_conn() as c:
        for name, v in VERSIONS.items():
            for t, region in LISTINGS:
                c.execute("INSERT INTO observations (scan_id, obs_date, ticker, region, composite, rank_pct, factors, "
                          "x20, model_version) VALUES (?,?,?,?,?,?,?,?,?)",
                          (name, "2026-10-01", t, region, 60.0, 50.0, "{}", 1.0, v))
        c.commit()


def test_pooling_rules_per_version_and_listing(db):
    app = db
    _fill(app)
    sql, params = app.comparable_model_clause()
    with app.get_conn() as c:
        got = c.execute(f"SELECT scan_id, ticker FROM observations WHERE {sql}", params).fetchall()
    for name in VERSIONS:
        assert {t for n, t in got if n == name} == EXPECT[name], name
    used = sum(len(v) for v in EXPECT.values())
    assert app.model_lab_population() == {"current": 5, "pooled_earlier": used - 5, "excluded": 40 - used}


@pytest.mark.parametrize("suffix", [".AS", ".CO", ".HE", ".MC", ".MI", ".OL", ".ST", ".SW"])
def test_v2_rows_from_exchanges_then_benchmarked_against_spy_are_never_pooled(db, suffix):
    app = db
    with app.get_conn() as c:
        for mv, sid in ((VERSIONS["v2"], "old"), (VERSIONS["v3"], "new")):
            c.execute("INSERT INTO observations (scan_id, obs_date, ticker, region, composite, rank_pct, factors, x20, "
                      "model_version) VALUES (?,?,?,?,?,?,?,?,?)", (sid, "2026-10-01", "XXX" + suffix, "Europe", 60.0, 50.0, "{}", 1.0, mv))
        c.commit()
        sql, params = app.comparable_model_clause()
        assert [r[0] for r in c.execute(f"SELECT scan_id FROM observations WHERE {sql}", params)] == ["new"]


def test_every_model_lab_reader_uses_the_pooled_population(db):
    app = db
    rng = np.random.default_rng(7)
    with app.get_conn() as c:
        for d in range(12):
            day = (datetime(2026, 8, 3) + timedelta(days=7 * d)).date().isoformat()
            x = rng.normal(size=20)
            for i in range(20):
                mv = VERSIONS["v3"] if d < 8 else VERSIONS["v9"]         # history spans a version bump
                c.execute("INSERT INTO observations (scan_id, obs_date, ticker, region, benchmark_type, composite, rank_pct, "
                          "factors, candidates, x20, model_version) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                          ("s", day, f"T{i}", "USA", "etf_total_return", 60.0 + float(x[i]), 50.0,
                           json.dumps({"momentum": float(x[i])}), "{}", float(x[i] + rng.normal(0, .3)), mv))
        c.commit()
    assert app.composite_summary(20)["n"] == 240
    ic, n_dates = app.factor_ic_report(20)
    assert n_dates == 12, "the IC table sees all twelve scan dates, not only those after the bump"
    assert len(app.observation_buckets(20)) > 0 and int(app.region_breakdown(20)["count"].sum()) == 240
    assert app.benchmark_mix() == {"etf_total_return": 240}


def test_the_clause_is_valid_for_postgres_too(app):
    sql, params = app.comparable_model_clause()
    assert sql.count("?") == len(params) == 16
    assert app._pg_sql(sql).count("%s") == len(params) and "?" not in app._pg_sql(sql)
    assert "%" not in sql, "LIKE patterns travel as parameters, so no literal % reaches psycopg"


# ============================================================ texts
def test_the_toggle_help_states_the_same_limit_the_code_enforces(app):
    import config
    for lang in ("en", "ja"):
        assert str(app.MANUAL_SENTIMENT_MAX_AGE_HOURS) in config.TRANSLATIONS[lang]["manual_st_help"]
        assert set(config.TRANSLATIONS["en"]) == set(config.TRANSLATIONS["ja"])
