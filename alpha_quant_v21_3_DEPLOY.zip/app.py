from __future__ import annotations

import base64
import hashlib
import json
import logging
import math
import os
import re
import sqlite3
import ssl
import threading
import time
import urllib.parse
import urllib.request
import warnings
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd
import streamlit as st
import altair as alt

try:
    import yfinance as yf
except Exception:
    yf = None

# Optional: powers the six-factor radar in the Deep-Dive tab. Guarded like yfinance
# so the app runs without it (the radar section is simply skipped). Add `plotly`
# to requirements.txt to enable it.
try:
    import plotly.graph_objects as go
except Exception:
    go = None

# Optional companion module (sec_research.py). Powers the US-only Conviction tab from
# SEC EDGAR fundamentals. Guarded so the app still runs if it's absent.
try:
    import sec_research
except Exception:
    sec_research = None

# Rakuten trade-history parsing (portfolio.py). Guarded like sec_research so an
# out-of-sync file set degrades to "page unavailable" instead of failing the import
# and taking the whole app down.
try:
    import portfolio as pf
except Exception:
    pf = None

logger = logging.getLogger("alpha_quant")

# yfinance prints a multi-line "possibly delisted; no price data found" block to the
# terminal for every symbol a bulk download misses. Those misses are transient far
# more often than they are real delistings, and the app now tracks and displays them
# properly (symbol_health + the Deep Scan health panel), so the raw chatter is noise
# that makes a healthy scan look broken. Quiet it to ERROR, with an escape hatch:
#   STOCKREC_VERBOSE_YF=1  restores yfinance's own logging.
if os.environ.get("STOCKREC_VERBOSE_YF") != "1":
    for _n in ("yfinance", "yfinance.data", "yfinance.utils", "peewee"):
        logging.getLogger(_n).setLevel(logging.CRITICAL)

# ----------------------------------------------------------------------------
# Networking — corporate-friendly SSL handling for yfinance
# ----------------------------------------------------------------------------
def _build_yf_session():
    """Return a curl_cffi session for yfinance that copes with corporate SSL.

    Large corporate networks and many VPNs run TLS inspection: a proxy re-signs
    HTTPS traffic with an internal root CA. libcurl (which yfinance uses under the
    hood) doesn't trust that internal CA, so every fetch fails with
    'curl: (60) ... unable to get local issuer certificate'. Two opt-in escape
    hatches, both via environment variables so the secure default is unchanged:

        STOCKREC_CA_BUNDLE    = C:\\path\\to\\corp-ca.pem   (secure: trust your corp CA)
        STOCKREC_INSECURE_SSL = 1                           (quick: skip verification)

    On a private/home network you set neither, and behaviour is the normal secure
    default. The helper degrades gracefully if curl_cffi isn't importable.
    """
    if yf is None:
        return None
    try:
        from curl_cffi import requests as cffi_requests
    except Exception:
        return None

    kwargs = {"impersonate": "chrome"}
    ca_bundle = os.environ.get("STOCKREC_CA_BUNDLE")
    if ca_bundle:
        kwargs["verify"] = ca_bundle                     # trust a specific CA file
    elif os.environ.get("STOCKREC_INSECURE_SSL") == "1":
        kwargs["verify"] = False                         # skip verification entirely
        warnings.filterwarnings("ignore", message=".*[Vv]erif.*")
    try:
        return cffi_requests.Session(**kwargs)
    except Exception:
        return None

_YF_SESSION = _build_yf_session()

def _ticker(symbol: str):
    """Construct a yfinance Ticker, reusing the shared curl_cffi session if present.

    This is the single entry point every fetch (history, fundamentals, analyst and
    insider data) goes through. The session built in _build_yf_session impersonates
    Chrome, which both copes with corporate TLS inspection and makes Yahoo far less
    likely to rate-limit the IP. If no session was created (curl_cffi missing) or a
    given yfinance version doesn't accept the `session=` argument, fall back to a
    plain Ticker so the app still works.
    """
    if _YF_SESSION is not None:
        try:
            return yf.Ticker(symbol, session=_YF_SESSION)
        except TypeError:
            pass   # this yfinance build doesn't take session=; use the default
    return yf.Ticker(symbol)

def _reddit_ssl_context() -> ssl.SSLContext | None:
    """Match the rest of the app's SSL behaviour for the urllib Reddit call.

    urllib uses Python's own ssl module (not curl_cffi), so on a TLS-inspecting
    corporate network it would fail independently. Honour the same env vars used
    for yfinance so the Reddit feed behaves consistently. Returns None to let
    urllib use its default context on a normal network.
    """
    ca_bundle = os.environ.get("STOCKREC_CA_BUNDLE")
    if ca_bundle:
        try:
            return ssl.create_default_context(cafile=ca_bundle)
        except Exception:
            return None
    if os.environ.get("STOCKREC_INSECURE_SSL") == "1":
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    return None

def _get_secret(name: str, default: str | None = None) -> str | None:
    """Read a credential from Streamlit secrets first (set in the Cloud dashboard),
    then fall back to environment variables (handy for local runs). Never raises if
    no secrets file is configured."""
    try:
        if name in st.secrets:
            return str(st.secrets[name])
    except Exception:
        pass
    return os.environ.get(name, default)

def _count_ticker_mentions(blob_upper: str, tickers: list) -> dict:
    """Count mentions of each ticker in an uppercased text blob.

    Sub-3-char symbols (e.g. 'V', 'KO') require an explicit '$' cashtag so ordinary
    words aren't mistaken for tickers; longer symbols use a plain word boundary,
    which still matches the $ form because '$' is itself a boundary-forming char.
    """
    counts = {}
    for t in tickers:
        pattern = (r"\$" + re.escape(t) + r"\b") if len(t) < 3 else (r"\b" + re.escape(t) + r"\b")
        counts[t] = len(re.findall(pattern, blob_upper, re.IGNORECASE))
    return counts

# Small finance lexicons for a *gentle* directional tilt on Reddit buzz. Mention count is
# volume; this nudges it by the bull/bear words appearing near each mention, so a heavily
# bearish-discussed name doesn't earn the same hype as a bullish one. The tilt is bounded
# and multiplicative — it can dampen the positive kick toward zero but never manufactures
# negative hype (the sell scanner owns bearishness). With sparse text it's ~0, i.e. a
# plain count. Empty either set to disable that side.
_BULL_WORDS = {"BUY", "BUYING", "BOUGHT", "LONG", "CALL", "CALLS", "MOON", "MOONING",
               "BULLISH", "BULL", "BREAKOUT", "RALLY", "SQUEEZE", "PUMP", "ROCKET",
               "UNDERVALUED", "BEAT", "BEATS", "UPGRADE", "UPGRADED", "GAINS", "GREEN",
               "HODL", "ACCUMULATE", "OVERSOLD", "RIP"}
_BEAR_WORDS = {"SELL", "SELLING", "SOLD", "SHORT", "SHORTING", "PUT", "PUTS", "CRASH",
               "CRASHING", "BEARISH", "BEAR", "DUMP", "DUMPING", "DROP", "DROPPING",
               "OVERVALUED", "MISS", "MISSES", "MISSED", "DOWNGRADE", "DOWNGRADED",
               "RED", "BAGHOLDER", "PUKE", "TANK", "TANKING", "DEAD"}
_TONE_WINDOW = 80     # chars of context examined each side of a mention
_TONE_GAIN = 0.15     # tilt per net (bull - bear) distinct word
_TONE_CAP = 0.5       # max |tilt|, so buzz is scaled within [0.5x, 1.5x]

def _tone_weighted_counts(blob_upper: str, tickers: list) -> dict:
    """Mention count per ticker, gently scaled by the bull/bear tone of the text around
    each mention: volume * (1 + tilt), tilt in [-_TONE_CAP, +_TONE_CAP], floored at 0.
    Distinct sentiment words per window (so spam can't dominate). Degrades to a plain
    count when no sentiment words are nearby."""
    out = {}
    for t in tickers:
        pattern = (r"\$" + re.escape(t) + r"\b") if len(t) < 3 else (r"\b" + re.escape(t) + r"\b")
        matches = list(re.finditer(pattern, blob_upper, re.IGNORECASE))
        n = len(matches)
        if n == 0:
            out[t] = 0.0
            continue
        net = 0
        for m in matches:
            ctx = blob_upper[max(0, m.start() - _TONE_WINDOW): m.end() + _TONE_WINDOW]
            words = set(re.findall(r"[A-Z]+", ctx))
            net += len(words & _BULL_WORDS) - len(words & _BEAR_WORDS)
        tilt = max(-_TONE_CAP, min(_TONE_CAP, _TONE_GAIN * net))
        out[t] = max(0.0, n * (1.0 + tilt))
    return out

def _reddit_get(url: str, headers: dict, data: bytes | None = None) -> str:
    """Single urllib request honouring the app's SSL context. Raises on failure."""
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=10, context=_reddit_ssl_context()) as resp:
        return resp.read().decode("utf-8", errors="ignore")

def _reddit_oauth_token() -> str | None:
    """Application-only (userless) OAuth token via the client_credentials grant.

    Needs only a client id + secret from a Reddit 'script' app — no username or
    password. Returns None when credentials aren't configured, so the caller can
    fall back to the public RSS feed.
    """
    cid = _get_secret("REDDIT_CLIENT_ID")
    csec = _get_secret("REDDIT_CLIENT_SECRET")
    if not cid or not csec:
        return None
    ua = _get_secret("REDDIT_USER_AGENT", "stockrec-hype/1.0")
    auth = base64.b64encode(f"{cid}:{csec}".encode()).decode()
    body = urllib.parse.urlencode({"grant_type": "client_credentials"}).encode()
    raw = _reddit_get("https://www.reddit.com/api/v1/access_token", data=body,
                      headers={"Authorization": f"Basic {auth}", "User-Agent": ua})
    return json.loads(raw).get("access_token")

# Records which path last produced data, for an at-a-glance UI status indicator.
_LAST_REDDIT_SOURCE = "offline"

# Public finance subreddits polled for the hype signal. More subs = broader coverage
# but more requests and higher block risk on unauthenticated access, so this is a
# deliberate handful of high ticker-density communities. Each is polled ONCE per scan
# (titles + bodies counted across the whole blob), never per ticker — per-ticker search
# would be one request per ticker per sub and get throttled fast.
REDDIT_SUBS = ["wallstreetbets", "stocks", "investing", "StockMarket", "options"]

def _reddit_collect(url_fn, headers_fn, parse_fn) -> str | None:
    """Fetch each REDDIT_SUBS listing, run parse_fn(raw) -> list[str], and join them.
    Per-sub failures are skipped; returns the combined UPPERCASED text, or None if
    every subreddit failed (so the caller can drop to the next tier)."""
    chunks, ok = [], False
    for sub in REDDIT_SUBS:
        try:
            chunks.extend(parse_fn(_reddit_get(url_fn(sub), headers_fn())))
            ok = True
        except Exception:
            continue   # this subreddit unavailable -> skip, keep polling the rest
        time.sleep(0.3)   # courtesy spacing between public requests
    return (" ".join(chunks).upper() if ok else None)

def _parse_reddit_json(raw: str) -> list:
    texts = []
    for child in json.loads(raw).get("data", {}).get("children", []):
        d = child.get("data", {})
        texts.append(str(d.get("title", "")))
        texts.append(str(d.get("selftext", "")))
    return texts

def _parse_reddit_rss(raw: str) -> list:
    blocks = re.findall(r"<title[^>]*>(.*?)</title>", raw, re.DOTALL | re.IGNORECASE)
    blocks += re.findall(r"<content[^>]*>(.*?)</content>", raw, re.DOTALL | re.IGNORECASE)
    return blocks if blocks else [raw]

def fetch_reddit_hype(tickers: list) -> dict:
    """Count mentions per ticker across several public finance subreddits, preferring
    authenticated access.

    Three-tier, fully fail-safe:
      1. Authenticated OAuth (REDDIT_CLIENT_ID / REDDIT_CLIENT_SECRET) — most reliable
         from cloud IPs; up to 100 hot posts (title + body) per subreddit.
      2. Public RSS hot feed per subreddit — no account/registration; works locally,
         often blocked on cloud datacenter IPs.
      3. Zero mentions for every ticker — guarantees the scan never crashes.
    Subreddits are polled once each (not per ticker). Standard library only.
    """
    global _LAST_REDDIT_SOURCE

    # --- Tier 1: authenticated OAuth across all subs ---------------------------
    try:
        token = _reddit_oauth_token()
        if token:
            ua = _get_secret("REDDIT_USER_AGENT", "stockrec-hype/1.0")
            blob = _reddit_collect(
                lambda s: f"https://oauth.reddit.com/r/{s}/hot?limit=100",
                lambda: {"Authorization": f"Bearer {token}", "User-Agent": ua},
                _parse_reddit_json)
            if blob is not None:
                _LAST_REDDIT_SOURCE = "authenticated"
                return _tone_weighted_counts(blob, tickers)
    except Exception:
        pass   # fall through to the unauthenticated RSS path

    # --- Tier 2: unauthenticated public RSS across all subs --------------------
    blob = _reddit_collect(
        lambda s: f"https://www.reddit.com/r/{s}/hot.rss",
        lambda: {"User-Agent": "Mozilla/5.0"},
        _parse_reddit_rss)
    if blob is not None:
        _LAST_REDDIT_SOURCE = "rss"
        return _tone_weighted_counts(blob, tickers)

    # --- Tier 3: safe zero-mention fallback ------------------------------------
    _LAST_REDDIT_SOURCE = "offline"
    return {t: 0 for t in tickers}

# ----------------------------------------------------------------------------
# Pluggable, per-market sentiment sources
# ----------------------------------------------------------------------------
# Each source declares which MARKETS (TICKER_UNIVERSE region keys) it covers and a
# fetch fn (tickers, names) -> {ticker: mention_count}. The orchestrator routes each
# market to the sources that cover it and merges the counts. Reddit handles English
# names; GDELT's multilingual news index reaches Japanese & Chinese coverage Reddit
# never sees. The market routing lives here in code (not in the UI), so the blend
# stays private while the sidebar still lets a user toggle whole sources on/off.
_LAST_GDELT_STATUS = "offline"

def _sentiment_reddit(tickers: list, names: dict) -> dict:
    """Reddit mention counts across several finance subs (English/US retail buzz)."""
    return fetch_reddit_hype(tickers)

def _sentiment_gdelt(tickers: list, names: dict) -> dict:
    """News-volume buzz per company from GDELT's free DOC API (no API key needed).

    Batches the company names into short OR-queries (one request per ~12 names),
    aggregates the returned article titles, and counts each name — the same blob-
    and-count approach as Reddit, but over a 100+ language global news index, so it
    reaches the Japanese and Chinese coverage Reddit lacks. Fully fail-safe: any
    network/parse error returns zero mentions. Title matching is on the English name,
    so native-language-only articles are under-counted (a known, acceptable limit).
    """
    global _LAST_GDELT_STATUS
    counts = {t: 0 for t in tickers}
    items = [(t, names.get(t, t)) for t in tickers if names.get(t, t)]
    ua = _get_secret("REDDIT_USER_AGENT", "stockrec-hype/1.0")
    got_any = False
    try:
        for i in range(0, len(items), 12):
            chunk = items[i:i + 12]
            or_terms = " OR ".join(f'"{nm}"' for _, nm in chunk)
            url = ("https://api.gdeltproject.org/api/v2/doc/doc?query="
                   + urllib.parse.quote(f"({or_terms})")
                   + "&mode=artlist&format=json&timespan=3d&maxrecords=250&sort=hybridrel")
            raw = _reddit_get(url, {"User-Agent": ua})
            try:
                arts = json.loads(raw).get("articles", [])
            except Exception:
                arts = []
            if arts:
                got_any = True
            blob = " ".join(str(a.get("title", "")) for a in arts).upper()
            for tkr, nm in chunk:
                counts[tkr] += len(re.findall(r"\b" + re.escape(nm.upper()) + r"\b", blob))
            time.sleep(0.5)   # GDELT asks for gentle pacing between requests
        _LAST_GDELT_STATUS = "ok" if got_any else "offline"
        return counts
    except Exception:
        _LAST_GDELT_STATUS = "offline"
        return {t: 0 for t in tickers}

SENTIMENT_SOURCES = {
    "reddit": {"label_key": "src_reddit", "markets": {"USA", "Europe"},
               "fn": _sentiment_reddit},
    "gdelt":  {"label_key": "src_gdelt",  "markets": {"USA", "Japan", "Europe", "China"},
               "fn": _sentiment_gdelt},
}
DEFAULT_SOURCES = list(SENTIMENT_SOURCES.keys())

# Human-readable summary of what the last hype scan actually used, for the UI.
_LAST_HYPE_STATUS = ""
_LAST_HYPE_FETCHED_AT = 0.0   # epoch seconds of the last ACTUAL (cache-miss) hype fetch

def _fetch_hype_uncached(universe: dict, enabled: list) -> tuple:
    """Run every enabled source over the markets it covers; merge per-ticker counts.
    Returns (combined, sources_ran). Sets the per-source status globals as a side effect."""
    combined = {t: 0 for ticks in universe.values() for t in ticks}
    sources_ran = []
    for key in enabled:
        src = SENTIMENT_SOURCES.get(key)
        if not src:
            continue
        sub = [t for region, ticks in universe.items() if region in src["markets"] for t in ticks]
        if not sub:
            continue
        names = {t: COMPANY_NAMES.get(t, t) for t in sub}
        try:
            res = src["fn"](sub, names) or {}
        except Exception:
            res = {}
        for t, c in res.items():
            combined[t] = combined.get(t, 0) + float(c or 0)
        sources_ran.append(key)
    return combined, sources_ran

@st.cache_data(ttl=1800, show_spinner=False)
def _hype_payload_cached(universe_key: tuple, enabled_key: tuple) -> dict:
    """Cached real fetch (30-min TTL): repeat scans of the same universe + sources reuse
    this instead of re-hitting Reddit/GDELT. Captures the fetch time and the raw per-source
    status keys so the wrapper can rebuild a localized status string on cache hits too."""
    universe = {region: list(tks) for region, tks in universe_key}
    combined, sources_ran = _fetch_hype_uncached(universe, list(enabled_key))
    return {"counts": combined, "sources_ran": sources_ran,
            "reddit": _LAST_REDDIT_SOURCE, "gdelt": _LAST_GDELT_STATUS,
            "fetched_at": time.time()}

def fetch_hype_signals(universe: dict, enabled_sources: list | None = None) -> dict:
    """Merged per-ticker hype counts ({ticker: combined_count}); analyze_ticker turns that
    into the capped hype bonus. Results are cached for 30 min and stamped with a fetch time
    (shown as 'updated X ago'); each source is independently fail-safe."""
    global _LAST_HYPE_STATUS, _LAST_HYPE_FETCHED_AT, _LAST_REDDIT_SOURCE, _LAST_GDELT_STATUS
    enabled = enabled_sources if enabled_sources is not None else DEFAULT_SOURCES
    universe_key = tuple((region, tuple(ticks)) for region, ticks in sorted(universe.items()))
    payload = _hype_payload_cached(universe_key, tuple(enabled))
    _LAST_HYPE_FETCHED_AT = payload["fetched_at"]
    _LAST_REDDIT_SOURCE, _LAST_GDELT_STATUS = payload["reddit"], payload["gdelt"]
    status_parts = []
    for key in payload["sources_ran"]:
        if key == "reddit":
            status_parts.append(f"{tr('src_reddit')}: {tr('hype_status_' + payload['reddit'])}")
        elif key == "gdelt":
            status_parts.append(f"{tr('src_gdelt')}: {tr('hype_status_' + payload['gdelt'])}")
    _LAST_HYPE_STATUS = (tr("hype_sources_prefix") + " " + " · ".join(status_parts)) if status_parts else ""
    return payload["counts"]




# ----------------------------------------------------------------------------
# Configuration & Global Market Universes
# ----------------------------------------------------------------------------
DB_PATH = "stock_engine.db"
# Simulated audit data lives in its OWN SQLite file, always, whatever the live
# backend is. Reached only via an explicit demo=True argument — never a global mode
# switch — so no scan, maintenance pass or weight update can be pointed at it.
DEMO_DB_PATH = "stock_engine_demo.db"
DEMO_WEIGHT_NOTE = "Demo backfill loop simulation"   # note used by every build
FACTORS = ["momentum", "value", "technical", "hype", "quality", "theme"]

DEFAULT_WEIGHTS = {
    "momentum": 0.20,
    "value": 0.18,
    "technical": 0.18,
    "hype": 0.16,
    "quality": 0.16,
    # Theme (industry-rotation) starts as the smallest factor: it's the newest and
    # the most correlated with momentum, so it must earn a bigger weight through the
    # walk-forward loop rather than being granted one. Old kpi_weights rows lack the
    # column; get_latest_weights substitutes this default and renormalises.
    "theme": 0.12,
}

LEARNING_RATE = 0.04
MIN_WEIGHT = 0.05
EVAL_HORIZON_DAYS = 14

# Legacy walk-forward learner: FROZEN into shadow mode. It still evaluates matured
# picks and records the weights it WOULD set (shadow_weights table), but it no longer
# writes production weights. Reasons: it learns from 6 hand-selected picks with a
# binary 14-calendar-day outcome — the weakest evidence in the app — and momentum
# changed meaning in model v2, so it would now be averaging two definitions. The
# Model Lab (every name, continuous excess returns, 5/20/60 sessions) is the place
# to decide weights. Set True to restore the old behaviour; nothing else changes.
ENABLE_LEGACY_WEIGHT_LEARNING = False
# Outcome sentinels for the recommendations table. NEUTRAL marks a call with no
# directional claim (HOLD): it is stored so the row isn't re-evaluated forever, but
# excluded from accuracy. Values are fixed for backward compatibility with rows
# already written by earlier builds.
OUTCOME_LOSS, OUTCOME_WIN, OUTCOME_NEUTRAL = 0, 1, 2

# Stamped on every observation. Bump whenever a production FACTOR changes meaning:
# rows scored by a different factor definition are a different model and must not be
# pooled with the current one in the Model Lab.
#   v1 — momentum return term = raw 1-month return (+/-13)
#   v2 — momentum return term = 3-month return vs home benchmark (+/-20), rebalanced
#   v3 — Yahoo! JP board poll parsed per five categories in an isolated component
#        (the old whole-page parser mis-read many polls), which changes the hype
#        input — and so the composite — for Japanese names that have a poll
#   v4 — the poll is read only inside its みんなの評価 scope, and one rounding tolerance
#        is shared by parser and scorers: polls totalling 100-102.5% are now scored
#        (the scorer used to skip them while the parser showed them), and pages with no
#        identifiable poll heading no longer contribute. Changes the hype input for the
#        affected Japanese names.
#   v5 — one validity rule shared by parser and scorers (an all-様子見 poll scores
#        neutral 50; impossible displays such as 100%+2% are rejected); scopes cut at
#        HTML structure; the Japan poll is now OFF by default (opt-in, experimental).
#   v6 — the opt-in is actually ENFORCED on every path. v5 only changed the toggle's
#        default: the first-run quick-scan button and run_engine's own default still
#        fetched the board and blended it into hype, and the Sell Scanner fetched and
#        scored it unconditionally. v5 observations from those paths can carry a poll
#        (their retail_sentiment.jp_board has status "ok") although v5 says opt-in, so
#        they are kept apart from v6, where a poll is present only if it was requested.
PRODUCTION_MODEL_VERSION = "composite-v6-jp-opt-in-enforced-everywhere"
DIRECTIONAL_CALLS = ("BUY", "SELL")

BUY_THRESHOLD = 65.0
SELL_THRESHOLD = 45.0

from config import (
    TICKER_UNIVERSE, COMPANY_NAMES, THEMES, BENCHMARKS, TRANSLATIONS,
    DEEP_FINALISTS, DEEP_US_TICKERS, JP_DEEP_TICKERS, CN_DEEP_TICKERS, DEEP_UNIVERSES,
)
# Deep-scan promotion settings (new). getattr-style fallback so an older config.py
# without these blocks still runs — promotions just start empty with the 5/3/2 quota.
# Japanese names for the instrument picker; empty dict on an older config.py (the
# picker then shows English names only).
# Crowd-sentiment sources (pure parsers + approved Stocktwits client). Guarded so a
# deployment that forgot the file degrades to "unavailable" with a visible warning
# instead of crashing the whole app.
try:
    import sentiment_sources as _ss
except ImportError:
    _ss = None

try:
    from config import BENCHMARK_TYPES
except ImportError:            # older config.py: methodology simply reported "unknown"
    BENCHMARK_TYPES = {}
try:
    from config import CONFIG_SCHEMA_VERSION
except ImportError:
    CONFIG_SCHEMA_VERSION = 0
EXPECTED_CONFIG_SCHEMA = 24

try:
    from config import INSTRUMENT_JA
except ImportError:
    INSTRUMENT_JA = {}
try:
    from config import PROMOTED_TICKERS, PROMOTION_QUOTA
except ImportError:
    PROMOTED_TICKERS = {"USA": [], "Japan": [], "Europe": [], "China": []}
    PROMOTION_QUOTA = {"USA": 8, "Japan": 5, "Europe": 5, "China": 3}
# Live-universe + theme-bridge settings (new); fallbacks keep an older config.py running.
try:
    from config import DYNAMIC_UNIVERSE_SPEC, DYNAMIC_ALLOWED_SUFFIXES, THEME_INDUSTRY_KEYWORDS
except ImportError:
    DYNAMIC_UNIVERSE_SPEC, DYNAMIC_ALLOWED_SUFFIXES, THEME_INDUSTRY_KEYWORDS = {}, {}, []
from indicators import (
    compute_rsi, compute_macd, compute_bollinger, compute_hype, clamp, screen_metrics,
    forum_sentiment_score, forum_euphoria_sell_score, theme_strength_score,
    payout_penalty, compute_atr, trade_levels, early_setup, SETUP_STATES,
    EARLY_SETUP_MODEL_VERSION, candidate_signals, cross_sectional_ic,
    relative_return, momentum_score as _momentum_score, MOMENTUM_REL_SESSIONS,
    bar_date, forward_excess, expectations_from_frames,
)
ALL_TICKERS = [ticker for region in TICKER_UNIVERSE.values() for ticker in region]







DEFAULT_BENCHMARK = "SPY"

def benchmark_for(ticker: str) -> str | None:
    """Benchmark symbol for a ticker's LISTING (exchange suffix), or None.

    An unmapped suffix used to fall back to SPY, so 67 European names (.AS .CO .HE
    .MC .MI .OL .ST .SW) priced in EUR/CHF/SEK/DKK/NOK were measured against a USD
    ETF — every 'excess return' carried the currency and the US market with it.
    Unmapped now means unavailable: benchmark-relative numbers stay NULL instead of
    being computed against the wrong market. Local benchmarks should be added to
    config.BENCHMARKS only after the Yahoo symbols are verified.
    An unsuffixed ticker is a US listing (including ADRs) and keeps SPY."""
    suffix = ticker.rsplit(".", 1)[1].upper() if "." in str(ticker) else ""
    return BENCHMARKS.get(suffix)


# ----------------------------------------------------------------------------
# Internationalization (i18n) — English / Japanese
# ----------------------------------------------------------------------------
# The translation helper is named `tr` (not `t`) on purpose: the scan loop uses
# a local variable `t` for the ticker symbol, so a `t()` helper would be shadowed.
LANGUAGES = {"English": "en", "日本語": "ja"}

REGION_NAMES = {
    "en": {"USA": "USA", "Japan": "Japan", "Europe": "Europe", "China": "China"},
    "ja": {"USA": "アメリカ", "Japan": "日本", "Europe": "ヨーロッパ", "China": "中国"},
}


def get_lang() -> str:
    return st.session_state.get("lang", "en")

def tr(key: str, **kwargs) -> str:
    """Look up a UI string for the active language, falling back to English."""
    table = TRANSLATIONS.get(get_lang(), TRANSLATIONS["en"])
    text = table.get(key) or TRANSLATIONS["en"].get(key)
    if text is None:
        # Last-resort humanisation. A missing key means config.py is older than
        # app.py; showing "no csv" is a poor label but "board_no_csv" looks broken.
        # The sidebar schema warning tells the user what actually needs fixing.
        stem = key.split("_", 1)[-1] if "_" in key else key
        text = stem.replace("_", " ").strip().capitalize()
    return text.format(**kwargs) if kwargs else text

def region_name(key: str) -> str:
    """Translate an internal region key (e.g. 'Japan') for display."""
    return REGION_NAMES.get(get_lang(), REGION_NAMES["en"]).get(key, key)

st.set_page_config(
    page_title="Alpha Quant Engine",
    page_icon="📈",
    layout="wide",
    # "auto": expanded on desktop, collapsed on phones. The page NAVIGATION now
    # lives in the sidebar (st.navigation), so hiding it by default on desktop
    # would hide the app's entire structure; on mobile "auto" still collapses it
    # and the first-run hero CTA covers the cold start.
    initial_sidebar_state="auto",
)

# ----------------------------------------------------------------------------
# Styling & UI Engine
# ----------------------------------------------------------------------------
def inject_css(accent: str = "#1B4D8F", card_bg: str = "#FFFFFF") -> None:
    """Design system: 藍 (ai / indigo) & paper.

    Direction notes, so future edits stay coherent:
      * This is a *numbers instrument*, not a consumer dashboard — so the display
        role is carried by tabular monospace figures at size, not by a decorative
        heading face. Digits align down every column; that alignment is the design.
      * Type: IBM Plex Sans (Latin UI) + IBM Plex Mono (all figures), webfonts, and
        the OS Japanese face for kanji/kana. Loading Plex Sans JP as a webfont was
        the purer pairing but the wrong trade on a phone: CJK families run to
        megabytes, and this app is read on mobile, sometimes behind a corporate
        proxy that may block fonts.googleapis.com. Hiragino (iOS/macOS), Noto Sans
        CJK (Android) and Yu Gothic (Windows) are all high-quality humanist gothics
        that pair cleanly with Plex, cost nothing to fetch, and render instantly.
        Net effect: only ~2 small Latin webfonts travel the wire, and if they're
        blocked entirely the design degrades to the system stack, not to nothing.
      * Accent is 藍 indigo (#1B4D8F), a nod to where this tool is used, kept for
        interaction only. Gains/losses use jade/rose so a signal never competes with
        the brand colour for attention.
      * Restraint: hairline rules instead of shadows, 6px radii instead of pills,
        one 120ms colour transition, motion disabled under prefers-reduced-motion.
    """
    st.markdown(
        f"""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap');
        :root {{
            --accent: {accent};
            --accent-deep: #12356A;
            --accent-tint: #EAF0F9;
            --ink: #101A2B;
            --ink-2: #1E2C43;
            --paper: #F6F7F9;
            --surface: {card_bg};
            --rule: #E2E6ED;
            --muted: #67717F;
            --pos: #0F7B5A;
            --neg: #B3283C;
            --warn: #A96A05;
            /* Latin glyphs resolve to Plex; Japanese glyphs aren't in the Latin subset,
               so they fall through to the OS face — Hiragino on iOS/macOS, Noto Sans
               CJK on Android, Yu Gothic/Meiryo on Windows. All three are neutral
               humanist gothics that sit correctly beside Plex, and none of them costs
               a download. */
            --font-ui: 'IBM Plex Sans', -apple-system, BlinkMacSystemFont,
                       'Hiragino Kaku Gothic ProN','Hiragino Sans','Noto Sans CJK JP',
                       'Noto Sans JP','Yu Gothic','Meiryo','Segoe UI', sans-serif;
            --font-num: 'IBM Plex Mono', ui-monospace, SFMono-Regular, Menlo,
                        'Hiragino Kaku Gothic ProN','Noto Sans CJK JP', monospace;
        }}
        html, body, [class*="css"], .stApp {{ font-family: var(--font-ui); color: var(--ink); }}
        .stApp {{ background: var(--paper); }}

        /* Clear Streamlit's fixed top toolbar so content doesn't slide underneath. */
        .block-container,
        [data-testid="stMainBlockContainer"] {{ padding-top: 3.75rem; padding-bottom: 3rem; }}

        h1, h2, h3, h4 {{ font-family: var(--font-ui); letter-spacing: -0.015em; color: var(--ink); }}
        h3 {{ font-size: 1.15rem; font-weight: 600; }}
        h4 {{ font-size: 1rem; font-weight: 600; }}

        /* ---- signature: 株価ボード status strip -------------------------------
           A market board reads left to right in fixed fields. Each cell here is a
           real piece of engine state (universe size, scan depth, holdings, feed),
           so the strip informs rather than decorates. */
        .qc-board {{
            display: flex; flex-wrap: wrap; align-items: stretch;
            background: var(--ink); border-radius: 6px; overflow: hidden;
            border-left: 4px solid var(--accent); margin: 0 0 18px 0;
        }}
        .qc-board-cell {{ padding: 9px 16px; border-right: 1px solid rgba(255,255,255,0.08); }}
        .qc-board-cell:last-child {{ border-right: 0; }}
        .qc-board-k {{
            font-family: var(--font-num); font-size: 0.62rem; font-weight: 500;
            letter-spacing: .14em; text-transform: uppercase; color: #8FA3BF;
        }}
        .qc-board-v {{
            font-family: var(--font-num); font-size: 0.95rem; font-weight: 600;
            color: #FFFFFF; font-variant-numeric: tabular-nums; margin-top: 2px;
        }}
        .qc-board-v.dim {{ color: #6F82A0; }}

        /* ---- cards: instrument panels, not consumer tiles ---- */
        .qc-card {{
            background: var(--surface);
            border: 1px solid var(--rule);
            border-radius: 6px;
            padding: 14px 16px;
            margin-bottom: 12px;
            transition: border-color .12s ease;
        }}
        .qc-card:hover {{ border-color: var(--accent); }}
        .qc-label {{
            font-family: var(--font-num); font-size: 0.66rem; font-weight: 500;
            color: var(--muted); text-transform: uppercase; letter-spacing: .12em;
        }}
        .qc-value {{
            font-family: var(--font-num); font-size: 1.6rem; font-weight: 600;
            font-variant-numeric: tabular-nums; line-height: 1.1; margin-top: 4px;
            color: var(--ink); letter-spacing: -0.02em;
        }}
        .qc-delta {{
            font-family: var(--font-num); font-size: 0.85rem; font-weight: 500;
            font-variant-numeric: tabular-nums; margin-top: 3px;
        }}
        .qc-pos {{ color: var(--pos); }}
        .qc-neg {{ color: var(--neg); }}

        /* ---- signal tags: a rule of colour, not a candy pill ---- */
        .qc-pill {{
            display: inline-block; padding: 3px 10px; border-radius: 3px;
            font-family: var(--font-num); font-weight: 600; font-size: 0.72rem;
            letter-spacing: .08em; text-transform: uppercase;
            border-left: 3px solid currentColor;
        }}
        .qc-buy  {{ background: rgba(15,123,90,0.10);  color: var(--pos); }}
        .qc-hold {{ background: rgba(103,113,127,0.12); color: var(--muted); }}
        .qc-sell {{ background: rgba(179,40,60,0.10);  color: var(--neg); }}
        .qc-ticker {{ font-family: var(--font-num); font-size: 1.1rem; font-weight: 600; letter-spacing: -0.01em; }}
        .qc-sub {{ font-size: 0.8rem; color: var(--muted); }}
        .qc-chip {{
            display: inline-block; padding: 3px 10px; border-radius: 3px;
            font-family: var(--font-num); font-size: 0.72rem; font-weight: 500;
            letter-spacing: .06em; color: var(--muted);
            background: var(--surface); border: 1px solid var(--rule);
            margin-bottom: 8px;
        }}

        /* ---- Streamlit chrome ---- */
        /* The design pins a light ground, but Streamlit's own chrome follows ITS theme
           (.streamlit/config.toml, or the viewer's OS preference when that file isn't
           deployed). Forcing a white sidebar without also forcing the foreground left
           near-white nav text on white — invisible. So ground AND text are set together
           here, and never inherited from Streamlit. */
        [data-testid="stSidebar"] {{ background: #FFFFFF; border-right: 1px solid var(--rule); }}
        [data-testid="stSidebar"], [data-testid="stSidebar"] p, [data-testid="stSidebar"] label,
        [data-testid="stSidebar"] span, [data-testid="stSidebar"] li {{ color: var(--ink); }}
        [data-testid="stSidebarNav"] a, [data-testid="stSidebarNav"] a span,
        [data-testid="stSidebarNavLink"] span, [data-testid="stSidebarNavItems"] span {{
            color: var(--ink) !important; font-family: var(--font-ui);
        }}
        [data-testid="stSidebarNav"] a:hover {{ background: var(--accent-tint); }}
        [data-testid="stSidebarNav"] a[aria-current="page"],
        [data-testid="stSidebarNavLink"][aria-current="page"] {{
            background: var(--accent-tint) !important;
            box-shadow: inset 3px 0 0 var(--accent);
        }}
        [data-testid="stSidebarNav"] a[aria-current="page"] span {{
            color: var(--accent-deep) !important; font-weight: 600;
        }}
        /* Inputs render on Streamlit's theme too — pin them to the light palette so a
           dark-mode viewer doesn't get black controls floating on paper. */
        [data-baseweb="select"] > div, [data-baseweb="input"] > div,
        [data-baseweb="textarea"] > div, [data-baseweb="popover"] [role="listbox"],
        [data-testid="stSidebar"] input, [data-testid="stSidebar"] textarea {{
            background: #FFFFFF !important; color: var(--ink) !important;
            border-color: var(--rule) !important;
        }}
        [data-baseweb="popover"] [role="option"] {{ color: var(--ink) !important; }}
        [data-baseweb="popover"] [role="option"]:hover {{ background: var(--accent-tint) !important; }}

        /* ---- theme-proofing ---------------------------------------------------
           If .streamlit/config.toml isn't deployed, Streamlit follows the VIEWER's
           OS preference — so a phone in dark mode renders black buttons, a black
           expander header and near-white tab labels on top of this light design.
           Every surface Streamlit themes is therefore pinned explicitly below.
           NOTE: st.dataframe is the one exception — it paints on a canvas from
           Streamlit's theme object, which CSS cannot reach, so the config file is
           still required for tables to match. */
        .stButton > button, .stDownloadButton > button,
        [data-testid="baseButton-secondary"], [data-testid="stBaseButton-secondary"] {{
            background: #FFFFFF !important; color: var(--ink) !important;
            border: 1px solid var(--rule) !important;
        }}
        .stButton > button:hover, [data-testid="baseButton-secondary"]:hover {{
            border-color: var(--accent) !important; color: var(--accent-deep) !important;
        }}
        .stButton > button[kind="primary"], [data-testid="baseButton-primary"],
        [data-testid="stBaseButton-primary"] {{
            background: var(--accent) !important; color: #FFFFFF !important;
            border-color: var(--accent) !important;
        }}
        [data-testid="stExpander"] details, [data-testid="stExpander"] summary,
        [data-testid="stExpander"] summary p, [data-testid="stExpander"] summary span {{
            background: var(--surface) !important; color: var(--ink) !important;
        }}
        [data-testid="stExpander"] summary svg {{ fill: var(--ink) !important; }}
        [data-baseweb="tab"], [data-baseweb="tab"] p {{ color: var(--muted) !important; }}
        [data-baseweb="tab"][aria-selected="true"],
        [data-baseweb="tab"][aria-selected="true"] p {{
            color: var(--accent-deep) !important; font-weight: 600;
        }}
        [data-baseweb="tab-highlight"], [data-baseweb="tab-border"] {{ background: var(--accent) !important; }}
        [data-baseweb="tab-list"] {{ background: transparent !important; }}
        /* Multiselect chips (Regions to Scan, Sentiment Sources).
           Streamlit paints these with primaryColor — the indigo from
           .streamlit/config.toml — and that rule beats a light-tint override, which
           left dark text on a saturated fill. So go WITH the indigo fill and force the
           label white instead: consistent whichever rule wins, since the background is
           indigo either way. -webkit-text-fill-color is included because some of
           Streamlit's emotion styles set it directly and it outranks plain `color`.
           Padding/overflow are explicit because baseweb sizes the chip from its own
           font metrics and IBM Plex Sans is wider, which clipped the first character. */
        [data-baseweb="tag"],
        [data-testid="stMultiSelect"] [data-baseweb="tag"],
        [data-testid="stSidebar"] [data-baseweb="tag"] {{
            background-color: var(--accent) !important;
            border: 1px solid var(--accent-deep) !important;
            border-radius: 3px !important;
            padding: 2px 8px !important;
            margin: 2px 4px 2px 0 !important;
            max-width: none !important;
            overflow: visible !important;
        }}
        [data-baseweb="tag"] *,
        [data-testid="stMultiSelect"] [data-baseweb="tag"] *,
        [data-testid="stSidebar"] [data-baseweb="tag"] * {{
            color: #FFFFFF !important;
            -webkit-text-fill-color: #FFFFFF !important;
            fill: #FFFFFF !important;
            background: transparent !important;
            overflow: visible !important;
            text-overflow: clip !important;
            font-family: var(--font-ui);
            font-weight: 500;
        }}
        [data-baseweb="tag"]:hover {{ background-color: var(--accent-deep) !important; }}
        /* Room for chips to wrap instead of clipping. */
        [data-testid="stMultiSelect"] [data-baseweb="select"] > div {{
            min-height: 2.5rem; height: auto !important; padding: 2px 4px !important;
        }}
        [data-testid="stAlert"] {{ color: var(--ink); }}
        [data-testid="stToggle"] label, [data-testid="stCheckbox"] label,
        [data-testid="stRadio"] label, [data-testid="stSlider"] label {{ color: var(--ink) !important; }}
        .stButton > button {{
            font-family: var(--font-ui); font-weight: 600; border-radius: 4px;
            border: 1px solid var(--rule); transition: border-color .12s ease, background .12s ease;
        }}
        .stButton > button:hover {{ border-color: var(--accent); color: var(--accent); }}
        .stButton > button[kind="primary"] {{ background: var(--accent); border-color: var(--accent); }}
        .stButton > button[kind="primary"]:hover {{ background: var(--accent-deep); color: #fff; }}
        /* Figures in tables align only if they are tabular — the whole point of a screener. */
        [data-testid="stDataFrame"] {{ font-family: var(--font-num); font-variant-numeric: tabular-nums; }}
        [data-testid="stMetricValue"] {{ font-family: var(--font-num); font-variant-numeric: tabular-nums; }}
        [data-testid="stCaptionContainer"], .stCaption {{ color: var(--muted); }}
        [data-testid="stExpander"] details {{ border: 1px solid var(--rule); border-radius: 6px; background: var(--surface); }}
        div[data-baseweb="tab-list"] {{ gap: 2px; }}

        @media (max-width: 640px) {{
            .qc-value {{ font-size: 1.35rem; }}
            .qc-ticker {{ font-size: 1rem; }}
            .qc-card {{ padding: 12px 14px; margin-bottom: 10px; }}
            .qc-board-cell {{ padding: 7px 12px; }}
            .block-container {{ padding-left: .6rem; padding-right: .6rem; }}
            /* Streamlit does not stack st.columns on narrow screens by default,
               so the 3- and 4-up card rows get badly squished on a phone.
               Force every column in a row to take the full width and wrap. */
            div[data-testid="stHorizontalBlock"] {{ flex-wrap: wrap; gap: .4rem; }}
            div[data-testid="stHorizontalBlock"] > div[data-testid="column"],
            div[data-testid="stHorizontalBlock"] > div[data-testid="stColumn"] {{
                flex: 1 1 100% !important;
                width: 100% !important;
                min-width: 100% !important;
            }}
        }}
        @media (prefers-reduced-motion: reduce) {{
            * {{ transition: none !important; animation: none !important; }}
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def board_strip(cells: list[tuple[str, str, bool]]) -> str:
    """The signature element: a market-board status strip.

    `cells` is [(label, value, is_live)] — each one a real piece of engine state, so
    the strip is instrumentation rather than ornament. Values that aren't populated
    yet render dimmed instead of being hidden, so the field layout stays constant
    between runs the way a real board does.
    """
    out = []
    for cell in cells:
        label, value, live = cell[0], cell[1], cell[2]
        hint = cell[3] if len(cell) > 3 else ""
        dim = "" if live else " dim"
        title = f' title="{hint}"' if hint else ""
        out.append(f'<div class="qc-board-cell"{title}><div class="qc-board-k">{label}</div>'
                   f'<div class="qc-board-v{dim}">{value}</div></div>')
    return f'<div class="qc-board">{"".join(out)}</div>'


def metric_card(label: str, value: str, delta: str | None = None, positive: bool | None = None) -> str:
    delta_html = ""
    if delta is not None:
        cls = "qc-pos" if positive else "qc-neg" if positive is not None else ""
        arrow = "▲ " if positive else "▼ " if positive is not None else ""
        delta_html = f'<div class="qc-delta {cls}">{arrow}{delta}</div>'
    return f'<div class="qc-card"><div class="qc-label">{label}</div><div class="qc-value">{value}</div>{delta_html}</div>'

def rec_pill(rec: str) -> str:
    cls = {"BUY": "qc-buy", "HOLD": "qc-hold", "SELL": "qc-sell"}.get(rec, "qc-hold")
    label = tr(f"rec_{rec}")
    return f'<span class="qc-pill {cls}">{label}</span>'

# --- None-proofing Parsing Helpers ---
def safe_float(value, default: float = float("nan")) -> float:
    try:
        if value is None: return default
        if isinstance(value, str):
            # Yahoo occasionally returns currency-formatted strings (e.g. "$1,250,000",
            # common in insider-transaction Value fields). Strip $ signs, commas, and
            # surrounding whitespace before casting so the number isn't lost.
            value = value.replace("$", "").replace(",", "").strip()
            if value == "": return default
        f = float(value)
        return default if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError): return default

def fmt_money(v: float) -> str: return "—" if math.isnan(v) else f"${v:,.2f}"
def fmt_pct(v: float) -> str: return "—" if math.isnan(v) else f"{v:+.2f}%"
def fmt_num(v: float, nd: int = 1) -> str: return "—" if math.isnan(v) else f"{v:.{nd}f}"
def fmt_big(v: float) -> str:
    if math.isnan(v): return "—"
    for unit, div in (("T", 1e12), ("B", 1e9), ("M", 1e6)):
        if abs(v) >= div: return f"${v / div:,.2f}{unit}"
    return f"${v:,.0f}"

# ----------------------------------------------------------------------------
# Database layer — dual backend.
#
# Default: local SQLite (zero config, exactly as before). If a DATABASE_URL
# secret/env var is set (e.g. a Supabase Postgres connection string) AND
# psycopg2 is installed, everything persists to Postgres instead — which is
# what survives Streamlit Cloud redeploys (walk-forward weights, mock
# portfolio, promotions, theme history). All call sites are unchanged: the
# adapter speaks the sqlite3 dialect the app already uses ('?' placeholders,
# conn.execute(), rows addressable by name AND position, `with` = commit).
# ----------------------------------------------------------------------------
try:
    import psycopg2                     # optional; only needed for Postgres mode
    import psycopg2.extras
    import psycopg2.pool
except Exception:
    psycopg2 = None


def _db_url() -> str | None:
    return _get_secret("DATABASE_URL")


import contextvars as _cv
# Scoped dialect override used ONLY while creating the demo schema, so the shared
# DDL helpers emit SQLite syntax for the demo file even when live runs on Postgres.
_BACKEND_OVERRIDE = _cv.ContextVar("_BACKEND_OVERRIDE", default=None)


def db_backend() -> str:
    o = _BACKEND_OVERRIDE.get()
    if o:
        return o
    return "postgres" if (psycopg2 is not None and _db_url()) else "sqlite"


def _pg_sql(sql: str) -> str:
    """Translate the app's sqlite dialect to Postgres: '?' params -> '%s'."""
    return sql.replace("?", "%s")


class _PgConn:
    """psycopg2 adapter with the sqlite3-ish surface the app uses.

    - conn.execute()/executemany() directly (no explicit cursor at call sites)
    - '?' placeholders
    - DictCursor rows: addressable by column name AND position, like sqlite3.Row
      (RealDictCursor would break the app's positional access — r[0] etc.)
    - context manager commits on success, rolls back on error, and RELEASES the
      connection back to the shared pool (or closes it, for a non-pooled fallback
      connection) — see _pg_checkout below.
    """
    def __init__(self, raw, pool=None):
        self._raw = raw
        self._pool = pool   # None -> direct connection; close() really closes

    def execute(self, sql: str, params=()):
        cur = self._raw.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cur.execute(_pg_sql(sql), tuple(params))
        return cur

    def executemany(self, sql: str, seq):
        cur = self._raw.cursor(cursor_factory=psycopg2.extras.DictCursor)
        cur.executemany(_pg_sql(sql), [tuple(p) for p in seq])
        return cur

    def cursor(self, *args, **kwargs):
        # pandas.read_sql_query drives the raw DBAPI cursor protocol directly.
        return self._raw.cursor(cursor_factory=psycopg2.extras.DictCursor)

    def commit(self):
        self._raw.commit()

    def close(self):
        """Return the connection to the pool (pooled) or close it (fallback)."""
        if self._pool is not None:
            try:
                self._pool.putconn(self._raw)
            except Exception:
                try: self._raw.close()
                except Exception: pass
        else:
            self._raw.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self._raw.commit()
            else:
                self._raw.rollback()
        finally:
            self.close()
        return False


# --- Postgres connection pool -----------------------------------------------
# Every get_conn() used to open a brand-new TCP+TLS connection to the hosted
# database (100-300ms each to e.g. Supabase) — multiplied by the scan loop's
# per-ticker writes and by concurrent Streamlit sessions. A module-level
# ThreadedConnectionPool amortises that to near-zero, and the SELECT 1 pre-ping
# on checkout transparently replaces connections the server dropped while idle
# (hosted Postgres commonly reaps idle sockets), so callers never see a stale
# one. Every call site is unchanged: _PgConn.close()/__exit__ now *release*
# instead of closing.
_PG_POOL = None
_PG_POOL_LOCK = threading.Lock()


def _pg_pool():
    global _PG_POOL
    if _PG_POOL is None:
        with _PG_POOL_LOCK:
            if _PG_POOL is None:
                _PG_POOL = psycopg2.pool.ThreadedConnectionPool(
                    minconn=1, maxconn=6, dsn=_db_url())
    return _PG_POOL


def _pg_checkout() -> "_PgConn":
    """Checkout with pre-ping: a pooled connection that fails SELECT 1 (dropped by
    the server while idle) is discarded and replaced. If the pool itself is broken
    or exhausted, fall back to one direct connection so the request still succeeds —
    _PgConn knows to really close that one instead of returning it to the pool."""
    try:
        pool = _pg_pool()
    except Exception:
        return _PgConn(psycopg2.connect(_db_url()), pool=None)
    for _ in range(2):
        try:
            raw = pool.getconn()
        except Exception:
            break
        try:
            with raw.cursor() as cur:
                cur.execute("SELECT 1")
            raw.rollback()            # clear the ping's implicit transaction
            return _PgConn(raw, pool=pool)
        except Exception:
            try:
                pool.putconn(raw, close=True)   # stale/dead -> drop from the pool
            except Exception:
                pass
    return _PgConn(psycopg2.connect(_db_url()), pool=None)


def get_conn(demo: bool = False):
    if demo:
        # Demo data: always its own SQLite file, never the live database.
        conn = sqlite3.connect(DEMO_DB_PATH, check_same_thread=False, timeout=10.0)
        conn.row_factory = sqlite3.Row
        return conn
    if db_backend() == "postgres":
        return _pg_checkout()
    # SQLite path — unchanged semantics.
    # check_same_thread=False because Streamlit serves reruns on a pool of threads;
    # timeout gives writers up to 10s to wait out a lock instead of erroring out;
    # WAL journaling lets reads and a writer proceed concurrently, which together
    # prevent the 'database is locked' OperationalError under multi-session load.
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10.0)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
    except sqlite3.Error:
        pass   # some network filesystems reject WAL; fall back to default journaling
    return conn

def _ensure_column(conn, table: str, column: str,
                   decl: str = "REAL DEFAULT 0.0") -> None:
    """Add `column` to `table` if it isn't already present (safe schema migration)."""
    if db_backend() == "postgres":
        # Postgres types: REAL is only 4 bytes there; store doubles like sqlite does.
        conn.execute(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {column} "
                     f"{decl.replace('REAL', 'DOUBLE PRECISION')}")
        return
    existing = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in existing:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")


def _ddl(sql: str) -> str:
    """Translate CREATE TABLE statements for the active backend. The app's DDL is
    written in sqlite dialect; for Postgres swap the auto-id and widen floats."""
    if db_backend() == "postgres":
        return (sql.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "SERIAL PRIMARY KEY")
                   .replace(" REAL", " DOUBLE PRECISION"))
    return sql

def init_db(demo: bool = False) -> None:
    """Create/migrate the schema. demo=True builds the identical schema in the
    separate demo SQLite file (SQLite dialect forced for that call only)."""
    token = _BACKEND_OVERRIDE.set("sqlite") if demo else None
    try:
        _init_schema(demo)
    finally:
        if token is not None:
            _BACKEND_OVERRIDE.reset(token)


def _init_schema(demo: bool) -> None:
    with get_conn(demo=demo) as conn:
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS recommendations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticker TEXT NOT NULL, rec_date TEXT NOT NULL, recommendation TEXT NOT NULL,
                composite REAL NOT NULL, price_at_rec REAL, momentum REAL, value REAL, 
                technical REAL, hype REAL, quality REAL, price_after REAL, outcome INTEGER, eval_date TEXT
            )"""))
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS kpi_weights (
                id INTEGER PRIMARY KEY AUTOINCREMENT, update_date TEXT NOT NULL,
                momentum REAL, value REAL, technical REAL, hype REAL, quality REAL, note TEXT
            )"""))
        # Walk-forward optimisation tables (new). CREATE ... IF NOT EXISTS is
        # inherently non-destructive, so existing data is never touched.
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS mock_portfolio (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL, ticker TEXT NOT NULL,
                recommendation_price REAL, reason TEXT, kpi_snapshot TEXT,
                evaluated INTEGER DEFAULT 0
            )"""))
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS system_weights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL, factor_name TEXT NOT NULL, current_weight REAL
            )"""))
        # Deep-scan winners promoted into the main scan universe. NOTE: on Streamlit
        # Cloud this file-backed table is wiped on restart/redeploy — the persistent
        # layer is PROMOTED_TICKERS in config.py (the app offers a paste-able snippet).
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS promoted_tickers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                region TEXT NOT NULL, ticker TEXT NOT NULL, name TEXT,
                composite REAL, promoted_at TEXT NOT NULL
            )"""))
        # Live screener names merged into each market's deep-scan universe (rotates
        # on every "Refresh universe" click; curated lists remain the quality floor).
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS dynamic_universe (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                region TEXT NOT NULL, ticker TEXT NOT NULL,
                rank INTEGER, fetched_at TEXT NOT NULL
            )"""))
        # Per-theme aggregates recorded once per FULL scan (quick scans skipped) so
        # the Themes tab can show momentum deltas vs the previous scan. Local-only
        # persistence: on Streamlit Cloud this resets at every redeploy.
        # V2.1 observation ledger. The existing learning loop trains on 6 picks per
        # scan (top-3 momentum + top-3 dividend), which is a selected, momentum-biased
        # sample: it can only learn "among names already chosen for momentum, what
        # worked". This table records EVERY scored name with its factor snapshot, then
        # measures realised excess return vs its own benchmark at 5/20/60 TRADING days.
        # It is measurement only — nothing here feeds scoring, thresholds or the
        # walk-forward optimiser, so the current engine's behaviour is unchanged and
        # the two can be compared later on real out-of-sample data.
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS observations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id TEXT NOT NULL, obs_date TEXT NOT NULL, ticker TEXT NOT NULL,
                region TEXT, benchmark TEXT, price REAL, composite REAL,
                recommendation TEXT, rank_pct REAL, factors TEXT,
                x5 REAL, x20 REAL, x60 REAL, r5 REAL, r20 REAL, r60 REAL,
                last_eval TEXT
            )"""))
        # Early Setup columns — additive migration, safe on an existing ledger.
        for _c, _t in (("setup_score", "REAL"), ("setup_state", "TEXT"),
                       ("setup_components", "TEXT"), ("ret_1m", "REAL"),
                       ("setup_quality", "TEXT"), ("setup_metrics", "TEXT"),
                       ("setup_model_version", "TEXT"),
                       ("setup_is_new", "INTEGER DEFAULT 0"),
                       ("setup_state_changed", "INTEGER DEFAULT 0"),
                       ("setup_previous_state", "TEXT"),
                       ("candidates", "TEXT"),
                       ("model_version", "TEXT"), ("weights_snapshot", "TEXT"),
                       ("benchmark_type", "TEXT"), ("sector", "TEXT"),
                       ("industry", "TEXT"), ("market_cap", "REAL"),
                       ("scan_type", "TEXT"), ("expectations", "TEXT"),
                       ("retail_sentiment", "TEXT"), ("scored_at", "TEXT")):
            _ensure_column(conn, "observations", _c, _t)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_obs_scan ON observations(scan_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_obs_ticker ON observations(ticker, obs_date)")

        # Symbol health: consecutive bulk-download failures per ticker. A single 404
        # from Yahoo means nothing (large, obviously-listed names like MMC or FI fail
        # under load), so a symbol is only skipped after repeated consecutive misses —
        # and one success resets it. This self-heals a curated list instead of
        # requiring someone to judge "delisted?" from a one-off error.
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS symbol_health (
                symbol TEXT PRIMARY KEY,
                fails INTEGER NOT NULL DEFAULT 0,
                last_fail TEXT, last_ok TEXT
            )"""))
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS theme_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                snapshot TEXT NOT NULL, theme TEXT NOT NULL,
                momentum REAL, hype REAL, composite REAL,
                n INTEGER, cover INTEGER, created_at TEXT NOT NULL
            )"""))
        # Full scan-result snapshots (JSON payload, history frames stripped) so the
        # last scan survives a page refresh / new session instead of living only in
        # st.session_state. Pruned to the newest few rows on every save.
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS scan_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL, is_quick INTEGER DEFAULT 1,
                n_results INTEGER, payload TEXT
            )"""))
        # --- Safe migration for pre-existing stock_engine.db files ---
        # Databases created before the "quality" factor existed are missing the
        # column. Add it (defaulting old rows to 0.0) only when absent, so this is
        # a no-op on fresh installs and never errors on an upgrade.
        _ensure_column(conn, "recommendations", "quality")
        _ensure_column(conn, "kpi_weights", "quality")
        # Theme (industry-rotation) factor — sixth KPI, added the same safe way.
        _ensure_column(conn, "recommendations", "theme")
        # Trade reference levels recorded AT recommendation time, so the audit can
        # later judge them (did price reach target before stop?). REAL, NaN-tolerant.
        for col in ("entry_lo", "entry_hi", "target_level", "stop_level"):
            _ensure_column(conn, "recommendations", col)
        _ensure_column(conn, "kpi_weights", "theme")
        # Bookkeeping flag so each logged pick feeds the walk-forward loop once.
        _ensure_column(conn, "mock_portfolio", "evaluated", "INTEGER DEFAULT 0")
        # Company name stored alongside the ticker for a friendlier audit table.
        _ensure_column(conn, "mock_portfolio", "name", "TEXT")
        # As-of date of each pick (its last price bar); timestamp stays for audit.
        _ensure_column(conn, "mock_portfolio", "price_date", "TEXT")
        # How a legacy outcome was judged: 'excess' (vs benchmark) or 'absolute'
        # (benchmark unavailable). NULL = written by an older build, basis unknown.
        _ensure_column(conn, "recommendations", "outcome_basis", "TEXT")
        # Append-only observation log (NOT the existing scan_snapshots table, which
        # restores the last scan on reopen). observations is a DAILY CONVENIENCE VIEW (one row per
        # ticker per price date, replaced on a rescan — what movers/NEW flags read);
        # this table keeps EVERY scan's full record and is never updated or deleted.
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS observation_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id TEXT NOT NULL, scored_at TEXT NOT NULL, price_date TEXT,
                ticker TEXT NOT NULL, region TEXT, composite REAL, recommendation TEXT,
                factors TEXT, weights_snapshot TEXT, model_version TEXT,
                setup_model_version TEXT, inputs TEXT
            )"""))
        conn.execute("CREATE INDEX IF NOT EXISTS idx_obssnap_ticker "
                     "ON observation_snapshots(ticker, price_date)")
        # Shadow log for the frozen legacy optimiser: what it WOULD have set.
        conn.execute(_ddl("""
            CREATE TABLE IF NOT EXISTS shadow_weights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL, n_picks INTEGER,
                proposed TEXT, active TEXT, note TEXT
            )"""))
        # Indexes for the hot queries: per-day replace in save_recommendation,
        # the pending-outcome sweep, and the walk-forward's evaluated=0 select.
        # CREATE INDEX IF NOT EXISTS is valid on both sqlite and Postgres.
        conn.execute("CREATE INDEX IF NOT EXISTS idx_reco_ticker_date ON recommendations(ticker, rec_date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_reco_date_outcome ON recommendations(rec_date, outcome)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_mock_evaluated ON mock_portfolio(evaluated)")
        conn.commit()
    # demo=demo: this check used to hit the LIVE database even when initialising the
    # demo file — creating a live database and failing on its missing tables.
    if get_weight_history(demo=demo).empty:
        save_weights(DEFAULT_WEIGHTS, note="initial defaults", demo=demo)

def get_latest_weights() -> dict[str, float]:
    with get_conn() as conn:
        row = conn.execute("SELECT momentum, value, technical, hype, quality, theme FROM kpi_weights ORDER BY id DESC LIMIT 1").fetchone()
    if row is None: return dict(DEFAULT_WEIGHTS)
    raw = {f: safe_float(row[f], DEFAULT_WEIGHTS[f]) for f in FACTORS}
    # A pre-migration weight row carries quality=0.0 (the ALTER TABLE default). The
    # auto-tuner floors every genuine weight at MIN_WEIGHT, so any value <= 0 is a
    # migration artifact: substitute the default and renormalise so the active
    # weights still sum to 1.0 (clean rows already do, making this a no-op for them).
    raw = {f: (w if w > 0 else DEFAULT_WEIGHTS[f]) for f, w in raw.items()}
    total = sum(raw.values()) or 1.0
    return {f: raw[f] / total for f in FACTORS}

def save_weights(weights: dict[str, float], note: str = "", demo: bool = False) -> None:
    ts = datetime.now().isoformat(timespec="seconds")
    with get_conn(demo=demo) as conn:
        conn.execute(
            "INSERT INTO kpi_weights (update_date, momentum, value, technical, hype, quality, theme, note) VALUES (?,?,?,?,?,?,?,?)",
            (ts, weights["momentum"], weights["value"], weights["technical"], weights["hype"], weights["quality"], weights["theme"], note),
        )
        # Mirror each factor into the long-format system_weights ledger (one row per
        # factor per change) so the walk-forward audit can track them individually.
        conn.executemany(
            "INSERT INTO system_weights (timestamp, factor_name, current_weight) VALUES (?,?,?)",
            [(ts, f, float(weights[f])) for f in FACTORS],
        )
        conn.commit()

def get_weight_history(demo: bool = False) -> pd.DataFrame:
    with get_conn(demo=demo) as conn:
        df = pd.read_sql_query("SELECT update_date, momentum, value, technical, hype, quality, theme, note FROM kpi_weights ORDER BY id ASC", conn)
    if not df.empty: df["update_date"] = pd.to_datetime(df["update_date"], errors="coerce")
    return df

def save_recommendation(rec: dict) -> None:
    """Persist one recommendation per ticker per day.

    FIX: the analysis dict produced by analyze_ticker stores the price under
    "price" (not "price_at_rec") and stores the full hype breakdown dict under
    "hype" (the numeric score is "hype_score"). Reading rec["price_at_rec"] or
    binding the hype *dict* into a REAL column raised on every ticker and sent
    them all to the "failed" list. We map both robustly here.
    """
    # rec_date is the AS-OF date of the score (last price bar), not the scan date: the
    # legacy evaluator counts its horizon from here, so a Friday close must not be
    # labelled Sunday. Falls back to today for callers that predate price_date.
    today = rec.get("price_date") or date.today().isoformat()

    # Accept either the analysis dict (key "price") or a pre-built record.
    price_val = safe_float(rec.get("price_at_rec", rec.get("price")))

    # Pull the numeric hype score, never the breakdown dict.
    hype_val = rec.get("hype_score", rec.get("hype", 0.0))
    if isinstance(hype_val, dict):
        hype_val = safe_float(hype_val.get("score", 0.0), 0.0)
    else:
        hype_val = safe_float(hype_val, 0.0)

    quality_val = safe_float(rec.get("quality"))

    with get_conn() as conn:
        conn.execute(
            "DELETE FROM recommendations WHERE ticker=? AND rec_date=? AND outcome IS NULL",
            (rec["ticker"], today),
        )
        conn.execute(
            "INSERT INTO recommendations (ticker, rec_date, recommendation, composite, price_at_rec, momentum, value, technical, hype, quality, theme, entry_lo, entry_hi, target_level, stop_level) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (rec["ticker"], today, rec["recommendation"], float(rec["composite"]),
             price_val, safe_float(rec["momentum"]), safe_float(rec["value"]),
             safe_float(rec["technical"]), hype_val, quality_val,
             safe_float(rec.get("theme"), 50.0),
             safe_float(rec.get("entry_lo")), safe_float(rec.get("entry_hi")),
             safe_float(rec.get("target_level")), safe_float(rec.get("stop_level"))),
        )
        conn.commit()

def get_recommendations(demo: bool = False) -> pd.DataFrame:
    with get_conn(demo=demo) as conn:
        df = pd.read_sql_query("SELECT * FROM recommendations ORDER BY rec_date DESC, id DESC", conn)
    if not df.empty: df["rec_date"] = pd.to_datetime(df["rec_date"], errors="coerce")
    return df

# ----------------------------------------------------------------------------
# Deep-scan promotions — a small rotating layer of deep-scan winners that rides
# along with the standard TICKER_UNIVERSE on every main scan (quota: PROMOTION_QUOTA,
# CN 2). Two layers, merged: the SQLite table (written by the Deep Scan tab's
# Promote button; ephemeral on Streamlit Cloud) takes priority, then the
# PROMOTED_TICKERS block in config.py (the persistent, hand-pasted layer). Names
# already anywhere in the base universe are dropped, and each region is capped to
# its quota — so the total scan is at most base + 10.
# ----------------------------------------------------------------------------
_BASE_UNIVERSE_SET = {t for ticks in TICKER_UNIVERSE.values() for t in ticks}

def get_promoted_universe() -> dict[str, list[str]]:
    db_layer: dict[str, list[str]] = {}
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT region, ticker FROM promoted_tickers ORDER BY id ASC").fetchall()
        for r in rows:
            db_layer.setdefault(r["region"], []).append(r["ticker"])
    except Exception:
        pass   # a missing/locked DB must never break universe assembly
    out: dict[str, list[str]] = {}
    for region, quota in PROMOTION_QUOTA.items():
        merged, seen = [], set()
        for t in db_layer.get(region, []) + list(PROMOTED_TICKERS.get(region, [])):
            if t and t not in seen and t not in _BASE_UNIVERSE_SET:
                merged.append(t); seen.add(t)
            if len(merged) >= quota:
                break
        if merged:
            out[region] = merged
    return out

def save_promotions(region: str, picks: list[tuple[str, str, float]]) -> None:
    """Replace `region`'s DB promotion layer with `picks` [(ticker, name, composite)]."""
    ts = datetime.now().isoformat(timespec="seconds")
    with get_conn() as conn:
        conn.execute("DELETE FROM promoted_tickers WHERE region=?", (region,))
        conn.executemany(
            "INSERT INTO promoted_tickers (region, ticker, name, composite, promoted_at) VALUES (?,?,?,?,?)",
            [(region, t, n, safe_float(c, 0.0), ts) for t, n, c in picks],
        )
        conn.commit()

def clear_promotions() -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM promoted_tickers")
        conn.commit()

def effective_universe() -> dict[str, list[str]]:
    """Base TICKER_UNIVERSE plus the promoted deep-scan layer, per region, deduped."""
    promoted = get_promoted_universe()
    out = {}
    for region, ticks in TICKER_UNIVERSE.items():
        extra = [t for t in promoted.get(region, []) if t not in ticks]
        out[region] = list(ticks) + extra
    return out

def promotions_config_snippet() -> str:
    """Ready-to-paste config.py block reflecting the CURRENT merged promotions, so a
    Streamlit Cloud user can persist them locally before a redeploy wipes the DB."""
    promoted = get_promoted_universe()
    lines = ["PROMOTED_TICKERS = {"]
    for region in PROMOTION_QUOTA:
        ticks = ", ".join(f'"{t}"' for t in promoted.get(region, []))
        lines.append(f'    "{region}": [{ticks}],')
    lines.append("}")
    return "\n".join(lines)

# ----------------------------------------------------------------------------
# LIVE deep-universe layer — Yahoo screener (top market cap + biggest movers)
# merged with the hand-curated deep lists, so the funnel's INPUT rotates with the
# market instead of being frozen at the knowledge cutoff. Curated lists are the
# quality floor and always remain; the screener adds churn: new listings, names
# that grew into the cap floor, and the day's genuine movers. Fully fail-safe —
# the screener is an unofficial endpoint and is often blocked on cloud IPs, in
# which case the deep scan simply runs on the curated list as before.
# ----------------------------------------------------------------------------
def refresh_dynamic_universe(region: str) -> list[str]:
    """Query Yahoo's screener for `region`. Two pulls per Yahoo region code:
    top-N by market cap (stability, data quality) and top movers above the same
    cap floor (discovery). Returns deduped symbols filtered to the market's
    expected listing suffixes; [] on any failure. Never raises."""
    spec = DYNAMIC_UNIVERSE_SPEC.get(region)
    if not spec or yf is None or not hasattr(yf, "screen") or not hasattr(yf, "EquityQuery"):
        return []
    allowed = DYNAMIC_ALLOWED_SUFFIXES.get(region, {""})
    symbols, seen = [], set()

    def _take(resp) -> None:
        for q in (resp or {}).get("quotes", []):
            sym = str(q.get("symbol") or "").upper().strip()
            if not sym or sym in seen or "=" in sym or "^" in sym:
                continue
            if q.get("quoteType") not in (None, "EQUITY"):
                continue
            suffix = "." + sym.rsplit(".", 1)[1] if "." in sym else ""
            if suffix not in allowed:
                continue
            seen.add(sym)
            symbols.append(sym)

    for code in spec["regions"]:
        base = yf.EquityQuery("and", [
            yf.EquityQuery("eq", ["region", code]),
            yf.EquityQuery("gt", ["intradaymarketcap", spec["min_cap"]]),
        ])
        try:   # largest names first: keeps data quality high and the list current
            _take(yf.screen(base, sortField="intradaymarketcap", sortAsc=False,
                            size=spec["top_cap"]))
        except Exception as e:
            logger.warning("screener market-cap pull failed for %s/%s: %s", region, code, e)
        try:   # movers overlay: today's biggest gainers above the same cap floor
            _take(yf.screen(base, sortField="percentchange", sortAsc=False,
                            size=spec["movers"]))
        except Exception as e:
            logger.warning("screener movers pull failed for %s/%s: %s", region, code, e)
    return symbols

def save_dynamic_universe(region: str, tickers: list[str]) -> None:
    ts = datetime.now().isoformat(timespec="seconds")
    with get_conn() as conn:
        conn.execute("DELETE FROM dynamic_universe WHERE region=?", (region,))
        conn.executemany(
            "INSERT INTO dynamic_universe (region, ticker, rank, fetched_at) VALUES (?,?,?,?)",
            [(region, t, i, ts) for i, t in enumerate(tickers)],
        )
        conn.commit()

def get_dynamic_universe(region: str) -> tuple[list[str], str | None]:
    """This market's stored screener names and when they were fetched (ISO), if any."""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT ticker, fetched_at FROM dynamic_universe WHERE region=? ORDER BY rank ASC",
                (region,)).fetchall()
    except Exception:
        return [], None
    if not rows:
        return [], None
    return [r["ticker"] for r in rows], rows[0]["fetched_at"]

SYMBOL_SKIP_AFTER = 3   # consecutive failed downloads before a symbol is parked


def record_symbol_results(ok: list, failed: list) -> None:
    """Reset the failure counter for symbols that returned data; increment it for
    those that didn't. Fail-safe: health tracking must never break a scan."""
    now = datetime.now().isoformat(timespec="seconds")
    try:
        with get_conn() as conn:
            for t in ok:
                conn.execute(
                    "INSERT INTO symbol_health (symbol, fails, last_ok) VALUES (?,0,?) "
                    "ON CONFLICT(symbol) DO UPDATE SET fails = 0, last_ok = ?",
                    (t, now, now))
            for t in failed:
                conn.execute(
                    "INSERT INTO symbol_health (symbol, fails, last_fail) VALUES (?,1,?) "
                    "ON CONFLICT(symbol) DO UPDATE SET fails = symbol_health.fails + 1, "
                    "last_fail = ?", (t, now, now))
    except Exception as e:
        logger.warning("symbol health write skipped: %s", e)


def skipped_symbols(threshold: int = SYMBOL_SKIP_AFTER) -> dict:
    """{symbol: consecutive_failures} for symbols at or past the strike limit."""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT symbol, fails FROM symbol_health WHERE fails >= ?",
                (threshold,)).fetchall()
        return {r[0]: int(r[1]) for r in rows}
    except Exception as e:
        logger.warning("symbol health read skipped: %s", e)
        return {}


def clear_symbol_health(symbol: str | None = None) -> None:
    """Give a parked symbol (or all of them) another chance."""
    try:
        with get_conn() as conn:
            if symbol:
                conn.execute("DELETE FROM symbol_health WHERE symbol = ?", (symbol,))
            else:
                conn.execute("DELETE FROM symbol_health")
    except Exception as e:
        logger.warning("symbol health clear skipped: %s", e)


def deep_universe_for(region: str) -> tuple[list[str], int]:
    """Curated deep list + live screener names (deduped). Returns (tickers, n_live)."""
    curated = list(DEEP_UNIVERSES.get(region, []))
    dyn, _ = get_dynamic_universe(region)
    cur_set = set(curated)
    extra = [t for t in dyn if t not in cur_set]
    return curated + extra, len(extra)

def match_theme(region: str, sector: str | None, industry: str | None) -> str | None:
    """Classify a stock into one of the THEMES baskets from its Yahoo sector/industry
    (captured for free during stage-2 fundamentals). First keyword match wins,
    specific industries before catch-alls; China + internet routes to China Internet.
    Returns None when nothing fits — not every stock belongs to a theme."""
    blob = f"{sector or ''} {industry or ''}".lower().strip()
    if not blob:
        return None
    if region == "China" and any(k in blob for k in ("internet", "e-commerce", "online")):
        return "China Internet"
    for theme, kws in THEME_INDUSTRY_KEYWORDS:
        if any(k in blob for k in kws):
            return theme
    return None

# ----------------------------------------------------------------------------
# Quantitative Math & Indicators
# ----------------------------------------------------------------------------
@st.cache_data(ttl=600, show_spinner=False)
def _stooq_symbol(ticker: str) -> str | None:
    """Map a US ticker to its Stooq symbol (AAPL -> aapl.us). None for suffixed/non-US
    tickers — Stooq is our US-only, keyless price fallback."""
    return None if "." in ticker else ticker.lower() + ".us"


def _period_to_days(period: str) -> int | None:
    m = re.match(r"(\d+)\s*(d|wk|mo|y)?", str(period).strip().lower())
    if not m:
        return None
    n, unit = int(m.group(1)), (m.group(2) or "d")
    return {"d": 1, "wk": 7, "mo": 30, "y": 365}.get(unit, 1) * n


def fetch_history_stooq(ticker: str, period: str = "8mo") -> "pd.DataFrame | None":
    """Free, keyless EOD price history from Stooq, used as a fallback when yfinance is
    throttled (US tickers only). Returns a yfinance-shaped frame (Date index, OHLCV with
    a 'Close' column) trimmed to `period`, or None. Never raises."""
    sym = _stooq_symbol(ticker)
    if sym is None:
        return None
    try:
        raw = _reddit_get(f"https://stooq.com/q/d/l/?s={sym}&i=d", {"User-Agent": "Mozilla/5.0"})
    except Exception:
        return None
    lines = raw.strip().splitlines()
    if not lines or not lines[0].lower().startswith("date"):
        return None   # '<no data>', error page, or a block — degrade quietly
    recs = []
    for line in lines[1:]:
        p = line.split(",")
        if len(p) < 5:
            continue
        try:
            d = pd.to_datetime(p[0])
            o, h, l, c = float(p[1]), float(p[2]), float(p[3]), float(p[4])
        except Exception:
            continue
        v = float(p[5]) if len(p) > 5 and p[5] not in ("", "N/D") else float("nan")
        recs.append((d, o, h, l, c, v))
    if not recs:
        return None
    df = (pd.DataFrame(recs, columns=["Date", "Open", "High", "Low", "Close", "Volume"])
          .set_index("Date").sort_index())
    days = _period_to_days(period)
    if days:
        df = df[df.index >= (df.index.max() - pd.Timedelta(days=days))]
    return df if not df.empty else None


@st.cache_data(ttl=1800, show_spinner=False)
def fetch_history(ticker: str, period: str = "8mo") -> pd.DataFrame:
    """Fetch OHLCV with retry/backoff so a throttled burst doesn't wipe a scan.

    Cached 30 min per (ticker, period): repeat scans, the Deep-Dive lazy refetch,
    and fallback paths reuse the frame instead of re-hitting Yahoo. RAISES
    RuntimeError when nothing comes back after the retries. @st.cache_data
    never caches an exception, so a transient throttle is retried next call instead
    of being frozen as a permanent None for the whole TTL. Callers that loop over
    many tickers wrap this in try/except and skip the offending name.
    """
    if yf is None:
        raise RuntimeError("yfinance unavailable")
    last_err = None
    for attempt in range(3):
        try:
            df = _ticker(ticker).history(period=period, auto_adjust=True)
            if df is not None and not df.empty and "Close" in df.columns:
                return df.dropna(subset=["Close"])
        except Exception as e:
            last_err = e
        time.sleep(1.2 * (attempt + 1))   # back off, then retry
    # yfinance exhausted -> try the free Stooq fallback (US tickers) before giving up,
    # so a Yahoo throttle degrades to EOD data instead of dropping the name entirely.
    stq = fetch_history_stooq(ticker, period)
    if stq is not None and not stq.empty and "Close" in stq.columns:
        return stq.dropna(subset=["Close"])
    raise RuntimeError(f"no price history for {ticker} after retries") from last_err

@st.cache_data(ttl=1800, show_spinner=False)
def _fmp_fundamentals(ticker: str) -> dict:
    """Optional secondary fundamentals from Financial Modeling Prep, used only when
    yfinance fails or returns empty (its `.info` is the flakiest source in the app).
    Enabled by setting FMP_API_KEY (st.secrets or env); otherwise a no-op. Free-tier
    coverage is US-focused, so suffixed/non-US tickers are skipped. Fail-safe -> {}.
    Values are normalized to the app's conventions: roe as a fraction, div_yield as a
    percent. short_pct isn't available from these endpoints, so it stays NaN."""
    key = _get_secret("FMP_API_KEY")
    if not key or "." in ticker:
        return {}
    base = "https://financialmodelingprep.com/api/v3"
    hdr = {"User-Agent": "Mozilla/5.0"}
    out = {"pe": float("nan"), "div_yield": float("nan"), "market_cap": float("nan"),
           "roe": float("nan"), "short_pct": float("nan"), "name": ticker,
           "sector": "", "industry": ""}
    got = False
    try:
        prof = json.loads(_reddit_get(f"{base}/profile/{ticker}?apikey={key}", hdr))
        if isinstance(prof, list) and prof:
            p = prof[0]
            out["market_cap"] = safe_float(p.get("mktCap"))
            out["pe"] = safe_float(p.get("pe"))
            out["name"] = str(p.get("companyName") or ticker)
            out["sector"] = str(p.get("sector") or "")
            out["industry"] = str(p.get("industry") or "")
            got = True
    except Exception as e:
        logger.warning("FMP profile fallback failed for %s: %s", ticker, e)
    try:
        rat = json.loads(_reddit_get(f"{base}/ratios-ttm/{ticker}?apikey={key}", hdr))
        if isinstance(rat, list) and rat:
            r = rat[0]
            pe = r.get("peRatioTTM", r.get("priceEarningsRatioTTM"))
            if pe is not None and math.isnan(out["pe"]):
                out["pe"] = safe_float(pe)
            out["roe"] = safe_float(r.get("returnOnEquityTTM", r.get("roeTTM")))   # fraction
            out["payout"] = safe_float(r.get("payoutRatioTTM"))
            dy = r.get("dividendYieldTTM")
            if dy is not None:
                out["div_yield"] = safe_float(dy) * 100.0   # FMP fraction -> app percent
            got = True
    except Exception as e:
        logger.warning("FMP ratios fallback failed for %s: %s", ticker, e)
    return out if got else {}


@st.cache_data(ttl=1800, show_spinner=False)
def fetch_fundamentals(ticker: str) -> dict:
    out = {"pe": float("nan"), "div_yield": float("nan"), "market_cap": float("nan"),
           "roe": float("nan"), "short_pct": float("nan"), "payout": float("nan"),
           "name": ticker, "sector": "", "industry": ""}
    if yf is None: return out
    # Distinguish a transient failure (rate-limit / network) from a reachable ticker
    # that simply lacks some fields. On the former we RAISE — @st.cache_data never
    # caches an exception, so the broken state isn't frozen for the whole TTL and the
    # next scan retries. Field-level gaps stay as NaN and cache normally.
    try:
        time.sleep(0.15)   # pace the un-bulkable .info endpoint; cache misses only
        info = _ticker(ticker).info
    except Exception as e:
        fb = _fmp_fundamentals(ticker)   # secondary source kicks in only on failure
        if fb:
            logger.info("fundamentals for %s served by FMP fallback (yfinance error)", ticker)
            return fb
        raise RuntimeError(f"fundamentals fetch failed for {ticker} (likely rate-limited)") from e
    if not info:
        fb = _fmp_fundamentals(ticker)
        if fb:
            logger.info("fundamentals for %s served by FMP fallback (empty yfinance)", ticker)
            return fb
        raise RuntimeError(f"empty fundamentals for {ticker} (likely rate-limited)")
    out["pe"] = safe_float(info.get("trailingPE"))
    out["market_cap"] = safe_float(info.get("marketCap"))
    out["name"] = str(info.get("shortName") or info.get("longName") or ticker)
    out["div_yield"] = resolve_div_yield(info)
    # New fundamentals for the quality factor and short-squeeze modifier. safe_float
    # keeps these as NaN when yfinance omits them, so downstream scoring never breaks.
    out["roe"] = safe_float(info.get("returnOnEquity"))
    out["short_pct"] = safe_float(info.get("shortPercentOfFloat"))
    # Dividend coverage (dividends/earnings, fraction). Flaky field: NaN when absent,
    # and payout_penalty treats NaN/<=0 as "no signal" so it can never punish a gap.
    out["payout"] = safe_float(info.get("payoutRatio"))
    # Sector/industry ride along for free from the same .info call — they feed the
    # Deep Scan <-> Themes bridge (match_theme) at zero extra API cost.
    out["sector"] = str(info.get("sector") or "")
    out["industry"] = str(info.get("industry") or "")
    return out

def resolve_div_yield(info: dict) -> float:
    """Return an annual dividend yield in PERCENT, or NaN.

    yfinance's `dividendYield` field is inconsistent across versions — sometimes a
    fraction (0.004), sometimes already a percent (0.4) — which can scale a real
    ~0.4% yield up to 15%+. The unambiguous route is dividend-rate / price, so we
    compute that first and only fall back to the raw field, then cap obviously
    broken values (equity yields above ~25% are virtually always a data error).
    """
    price = safe_float(info.get("currentPrice") or info.get("regularMarketPrice") or info.get("previousClose"))
    rate = safe_float(info.get("dividendRate") or info.get("trailingAnnualDividendRate"))

    dy = float("nan")
    if not math.isnan(rate) and not math.isnan(price) and price > 0:
        dy = rate / price * 100.0
    else:
        raw = safe_float(info.get("dividendYield"))
        if not math.isnan(raw):
            dy = raw if raw > 1 else raw * 100.0   # normalize fraction vs percent

    if math.isnan(dy) or dy < 0 or dy > 25:
        return float("nan")
    return dy


def _jp_poll_tuple(d: dict) -> tuple | None:
    """(buy%, sell%, neutral%-or-None) from a validated board record, else None.
    The neutral share travels with the poll because the scorers need it: an all-様子見
    poll is a real, neutral poll, not 'no votes'."""
    if not d or d.get("status") != "ok":
        return None
    n = d.get("neutral_pct")
    return (float(d["buy_pct"]), float(d["sell_pct"]), None if n is None else float(n))


def _parse_jp_forum(html: str) -> tuple | None:
    """(buy%, sell%, neutral%) for the scoring contract, or None.

    Delegates to sentiment_sources.parse_jp_board, which isolates the poll component
    and parses all five categories. The previous whole-page regex could bind one
    percentage to two labels (31%買 売67% -> 67/67), read 強く買いたい as 買いたい
    (10/21/2/30/37 -> 10/30 for a 67%-sell poll) and dropped decimals (-> 0/0).
    buy = strong buy + buy; sell = sell + strong sell; neutral kept in the detail."""
    if _ss is None or not html:
        return None
    return _jp_poll_tuple(_ss.parse_jp_board(html))


@st.cache_data(ttl=1800, show_spinner=False)
def _fetch_jp_board_cached(ticker: str) -> dict:
    """Fetch + parse one board page. RAISES on a network failure so st.cache_data never
    freezes a transient error for 30 minutes; a page that parses to 'unavailable' or
    'parse_error' IS cached, because retrying it would just re-read the same page.
    fetched_at is set here, so a cache hit keeps the ORIGINAL retrieval time."""
    url = f"https://finance.yahoo.co.jp/quote/{ticker}/forum"
    html = _reddit_get(url, {"User-Agent": "Mozilla/5.0", "Accept-Language": "ja"})
    time.sleep(0.25)   # only on cache miss; be polite to the page
    d = _ss.parse_jp_board(html)
    d.update(source_url=url, ticker=ticker, provider_asof=None,
             fetched_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    return d


def fetch_jp_forum_detail(ticker: str) -> dict:
    """Full Yahoo! JP board record (status, five categories, provenance). Never invents
    a value: unavailable / parse_error / ambiguous / network_error carry no numbers."""
    base = {"source": "yahoo_jp_board", "ticker": ticker, "buy_pct": None,
            "neutral_pct": None, "sell_pct": None, "categories": {},
            "parser_version": getattr(_ss, "JP_PARSER_VERSION", None)}
    if not ticker.endswith(".T"):
        return dict(base, status="unavailable", reason="not_a_tokyo_listing")
    if _ss is None:
        return dict(base, status="unavailable", reason="sentiment_sources_module_missing")
    try:
        return _fetch_jp_board_cached(ticker)
    except Exception as e:
        logger.warning("JP forum fetch failed for %s: %s", ticker, e)
        return dict(base, status="network_error", reason=type(e).__name__)


def fetch_jp_forum_rating(ticker: str) -> tuple[float, float] | None:
    """みんなの評価 poll as (buy%, sell%) for the existing scoring formula, or None.
    Fail-safe: anything but a validated poll returns None, and hype falls back to the
    volume signal alone exactly as before. Personal-use access to an unofficial page;
    stops on blocking rather than bypassing it."""
    return _jp_poll_tuple(fetch_jp_forum_detail(ticker))


def _benchmark_close(ticker: str) -> pd.Series | None:
    """Home-benchmark closes for `ticker`, via the session history cache — so this is a
    cache hit whenever run_engine already downloaded the benchmark in its bulk call."""
    b = benchmark_for(ticker)
    if not b:
        return None                      # unmapped listing: no benchmark, not SPY
    try:
        bh = get_histories([b], period="1y").get(b)
        return bh["Close"] if bh is not None and "Close" in bh.columns else None
    except Exception as e:
        logger.warning("benchmark history unavailable for %s: %s", ticker, e)
        return None


def analyze_ticker(ticker: str, region: str, hype_mentions: float = 0.0,
                   jp_forum: tuple | None = None,
                   hist: pd.DataFrame | None = None,
                   bench_close: pd.Series | None = None) -> dict | None:
    # `hist` lets bulk callers (run_engine / run_deep_scan) hand in the frame from
    # ONE yf.download for the whole universe instead of paying a per-ticker request;
    # names the bulk call missed fall back to the per-ticker fetch (retry + Stooq).
    if hist is None:
        hist = fetch_history(ticker)
    if hist is None or len(hist) < 60: return None
    close, volume = hist["Close"], hist.get("Volume", pd.Series(dtype=float))
    funds = fetch_fundamentals(ticker)

    price = safe_float(close.iloc[-1])
    sma20 = safe_float(close.rolling(20).mean().iloc[-1])
    sma50 = safe_float(close.rolling(50).mean().iloc[-1])
    # Trade reference levels (entry/target/stop). ATR needs High/Low; some fallback
    # frames may lack them -> NaN ATR -> trade_levels returns None -> panel hidden.
    atr = (compute_atr(hist["High"], hist["Low"], close)
           if "High" in hist.columns and "Low" in hist.columns else float("nan"))
    high_52w = safe_float(close.iloc[-252:].max())
    levels = trade_levels(safe_float(close.iloc[-1]), sma20, sma50, atr, high_52w)
    rsi = safe_float(compute_rsi(close).iloc[-1])
    macd_line, signal_line, hist_macd = compute_macd(close)
    _, bb_up, bb_lo, bb_pct = compute_bollinger(close)
    # 1-month return = 21 TRADING days back, i.e. iloc[-22] relative to the last
    # bar (iloc[-21] was only 20 days back — a subtle off-by-one).
    ret_1m = safe_float((price / close.iloc[-22] - 1) * 100) if len(close) >= 22 else float("nan")
    hype = compute_hype(volume)

    # Scoring Engine Logic
    # Momentum is now MARKET-RELATIVE: the return term is the 3-month return minus the
    # home benchmark's (see indicators.momentum_score for the full rationale).
    if bench_close is None:
        bench_close = _benchmark_close(ticker)
    rel_ret_3m = relative_return(close, bench_close, sessions=MOMENTUM_REL_SESSIONS)
    momentum_score = _momentum_score(price, sma50, safe_float(hist_macd.iloc[-1]), rel_ret_3m)
    momentum_basis = "relative" if not math.isnan(rel_ret_3m) else "no_benchmark"

    pe = funds["pe"]
    value_score = 50.0 if math.isnan(pe) or pe <= 0 else clamp(100 - (pe - 10) * 2.0)
    if not math.isnan(funds["div_yield"]): value_score = clamp(value_score + min(funds["div_yield"] * 3, 10))
    # Dividend-coverage guard: an uncovered payout is the yield-trap profile the two
    # lines above otherwise REWARD (falling price -> higher yield, lower P/E). The
    # penalty (0-20 pts, indicators.payout_penalty) only fires above 80% payout.
    value_score = clamp(value_score - payout_penalty(funds["payout"]))

    rsi_safe = rsi if not math.isnan(rsi) else 50.0
    tech = 50.0 - abs(rsi_safe - 50) * 0.6 + (15 if 45 <= rsi_safe <= 65 else 0)
    pct_b = safe_float(bb_pct.iloc[-1])
    technical_score = clamp(tech + (15 if (not math.isnan(pct_b) and 0.2 <= pct_b <= 0.8) else -10))

    # Quality factor — rewards return-on-equity (profitability). A missing ROE is
    # treated as neutral (50) rather than penalised.
    roe = funds["roe"]
    quality_score = 50.0 if math.isnan(roe) else clamp(50 + (roe * 200))

    # Social & news buzz — a live retail/news-sentiment kicker combining every
    # enabled source for this market (Reddit, GDELT news, …). Each mention adds 10
    # points to the hype score (capped at +35), then the whole score is re-clamped
    # to 0-100. Zero mentions (or a failed fetch) leave hype untouched.
    if hype_mentions > 0:
        hype["score"] = clamp(hype["score"] + min(35, hype_mentions * 10))

    # Japan-native sentiment: Yahoo!掲示板 みんなの評価 poll, blended 50/50 into the
    # hype score when available. This gives Japanese names a real sentiment signal
    # (Reddit/GDELT are English-centric); the transform (net bullishness, damped)
    # is forum_sentiment_score in indicators.py. Fail-safe: no poll -> volume-only.
    if jp_forum is not None:
        fs = forum_sentiment_score(jp_forum[0], jp_forum[1],
                                   jp_forum[2] if len(jp_forum) > 2 else None)
        if fs is not None:
            hype["score"] = clamp(0.5 * hype["score"] + 0.5 * fs)

    # Short-squeeze modifier — a heavily-shorted name (>10% of float) that is also
    # printing sustained volume breakouts can squeeze violently, so we boost its
    # hype score by +30 (capped at 100). The boost flows into hype_score below.
    short_pct = funds["short_pct"]
    if not math.isnan(short_pct) and short_pct > 0.10 and hype["sustained"]:
        hype["score"] = clamp(hype["score"] + 30.0)

    return {
        "ticker": ticker, "region": region, "name": funds["name"], "price": price,
        "sma20": sma20, "sma50": sma50, "rsi": rsi, "macd_hist": safe_float(hist_macd.iloc[-1]),
        "bb_pct": pct_b, "ret_1m": ret_1m, "pe": pe, "div_yield": funds["div_yield"],
        "rel_ret_3m": rel_ret_3m, "momentum_basis": momentum_basis,
        # The as-of date of every number above: the date of the last price bar.
        # Distinct from the scan timestamp — a weekend scan scores Friday.
        "price_date": bar_date(hist.index),
        "payout": funds["payout"], "atr": atr,
        "entry_lo": (levels["entry_lo"] if levels else float("nan")),
        "entry_hi": (levels["entry_hi"] if levels else float("nan")),
        "target_level": (levels["target"] if levels else float("nan")),
        "stop_level": (levels["stop"] if levels else float("nan")),
        "market_cap": funds["market_cap"], "roe": roe, "short_pct": short_pct,
        "sector": funds.get("sector", ""), "industry": funds.get("industry", ""),
        "hype": hype, "momentum": momentum_score, "value": value_score,
        "technical": technical_score, "quality": quality_score,
        # Theme (industry-rotation) KPI: neutral until the caller's cross-sectional
        # second pass fills it in (run_engine / run_deep_scan) — the score depends on
        # the OTHER scanned members of the basket, which a per-ticker function can't
        # see. Neutral 50 contributes weight*50 to the composite, i.e. no tilt.
        "theme": 50.0, "theme_match": None,
        "hype_score": hype["score"], "hype_mentions": hype_mentions,
        "jp_bull": (jp_forum[0] if jp_forum else float("nan")),
        # Keep ONLY the Close column of the history frame in the result dict: the
        # sole post-scan consumer is the Deep-Dive price chart (Close + SMAs derived
        # from Close). Storing the full 7-column OHLCV frame per ticker kept ~85%
        # dead weight alive in st.session_state for the whole session — multiplied
        # by the universe size and by every concurrent user, a real contributor to
        # Streamlit Cloud's memory limit (which kills the app until a reboot).
        "jp_bear": (jp_forum[1] if jp_forum else float("nan")), "history": hist[["Close"]]
    }

def score_with_weights(analysis: dict, weights: dict[str, float]) -> dict:
    composite = sum(weights[f] * analysis[f if f != "hype" else "hype_score"] for f in FACTORS)
    rec = "BUY" if composite >= BUY_THRESHOLD else "SELL" if composite < SELL_THRESHOLD else "HOLD"
    return {"composite": float(composite), "recommendation": rec}

# ----------------------------------------------------------------------------
# Sell-Signal Scanner
# ----------------------------------------------------------------------------
# A separate, ticker-driven view that surfaces *bearish* indicators. Each KPI
# returns a 0-100 sub-score where HIGHER = stronger sell pressure; the composite
# is a weighted average over whichever KPIs actually returned data (so a symbol
# with no analyst/insider coverage isn't unfairly scored on missing fields).
SELL_HIGH = 65.0          # composite >= this  -> "elevated" sell pressure
SELL_LOW = 45.0           # composite <  this  -> "low" sell pressure
SELL_LOOKBACK_DAYS = 180  # window for analyst rating changes & insider filings

SELL_KPI_WEIGHTS = {
    "analyst": 0.20,      # consensus rating (1 strong buy .. 5 strong sell)
    "downgrades": 0.18,   # recent analyst rating changes (hold->sell etc.)
    "target": 0.15,       # price vs mean analyst price target
    "insider": 0.17,      # net insider selling
    "technical": 0.15,    # trend breakdown (moving averages, MACD)
    "momentum": 0.10,     # recent price momentum
    "short": 0.05,        # short interest as bearish positioning
    "forum": 0.05,        # Yahoo!掲示板 euphoria (JP only; asymmetric, skipped elsewhere)
}
_SELL_GRADES = ("sell", "underperform", "reduce", "underweight", "negative", "strong sell")

@st.cache_data(ttl=1800, show_spinner=False)
def fetch_analyst_signals(ticker: str) -> dict:
    """Analyst consensus, mean price target, and recent rating changes."""
    out = {"rec_mean": float("nan"), "rec_key": "", "num_analysts": float("nan"),
           "target_mean": float("nan"), "currency": "", "changes": []}
    if yf is None:
        return out
    tk = _ticker(ticker)
    # RAISE on a failed/empty .info so a rate-limited response isn't cached for the
    # whole TTL (see fetch_fundamentals). A reachable name with no analyst coverage
    # returns a populated info dict but NaN fields — that's legitimate and caches.
    try:
        time.sleep(0.2)    # pace the per-ticker endpoint; runs on cache misses only
        info = tk.info
    except Exception as e:
        raise RuntimeError(f"analyst fetch failed for {ticker} (likely rate-limited)") from e
    if not info:
        raise RuntimeError(f"empty analyst info for {ticker} (likely rate-limited)")
    out["rec_mean"] = safe_float(info.get("recommendationMean"))
    out["rec_key"] = str(info.get("recommendationKey") or "")
    out["num_analysts"] = safe_float(info.get("numberOfAnalystOpinions"))
    out["target_mean"] = safe_float(info.get("targetMeanPrice"))
    out["currency"] = str(info.get("currency") or "")
    # Rating-change history is optional and frequently empty (esp. non-US); its
    # absence is not a fetch failure, so we swallow errors here rather than raise.
    try:
        ud = tk.upgrades_downgrades
        if ud is not None and not ud.empty:
            ud = ud.reset_index()
            date_col = ud.columns[0]
            parsed = pd.to_datetime(ud[date_col], errors="coerce", utc=True)
            ud[date_col] = parsed.dt.tz_convert(None)
            cutoff = pd.Timestamp(date.today() - timedelta(days=SELL_LOOKBACK_DAYS))
            recent = ud[ud[date_col] >= cutoff].sort_values(date_col, ascending=False)
            for _, row in recent.head(12).iterrows():
                d = row[date_col]
                out["changes"].append({
                    "date": d.date().isoformat() if pd.notna(d) else "",
                    "firm": str(row.get("Firm", "")),
                    "from": str(row.get("FromGrade", "")),
                    "to": str(row.get("ToGrade", "")),
                    "action": str(row.get("Action", "")),
                })
    except Exception:
        pass
    return out

@st.cache_data(ttl=1800, show_spinner=False)
def fetch_insider_activity(ticker: str) -> dict:
    """Recent insider transactions, split into buy vs sell value/counts."""
    out = {"buy_value": 0.0, "sell_value": 0.0, "n_buys": 0, "n_sells": 0,
           "rows": [], "available": False}
    if yf is None:
        return out
    # RAISE when the underlying call throws (transient / rate-limit) so the failure
    # isn't cached. A successful call that returns an EMPTY frame is a legitimate
    # 'no insider transactions' result for this name and is cached as such.
    try:
        time.sleep(0.2)    # pace the per-ticker endpoint; runs on cache misses only
        it = _ticker(ticker).insider_transactions
    except Exception as e:
        raise RuntimeError(f"insider fetch failed for {ticker} (likely rate-limited)") from e
    if it is None or it.empty:
        return out

    cols = list(it.columns)
    date_col = next((c for c in ("Start Date", "Date", "startDate") if c in cols), None)

    def classify(row) -> str:
        txt = ""
        for c in ("Transaction", "Text"):
            if c in cols and pd.notna(row.get(c)):
                txt = str(row.get(c)).lower(); break
        if any(k in txt for k in ("sale", "sell", "sold", "dispos")):
            return "sell"
        if any(k in txt for k in ("buy", "purchase", "acqui")):
            return "buy"
        return "other"

    for _, row in it.iterrows():
        kind = classify(row)
        val = safe_float(row.get("Value"), 0.0)
        val = 0.0 if math.isnan(val) else abs(val)
        if kind == "sell":
            out["sell_value"] += val; out["n_sells"] += 1
        elif kind == "buy":
            out["buy_value"] += val; out["n_buys"] += 1
        if len(out["rows"]) < 12:
            out["rows"].append({
                "date": str(row.get(date_col)) if date_col else "",
                "insider": str(row.get("Insider", "")),
                "transaction": str(row.get("Transaction") if "Transaction" in cols else row.get("Text", "")),
                "shares": safe_float(row.get("Shares"), float("nan")),
                "value": val,
            })
    out["available"] = (out["n_buys"] + out["n_sells"]) > 0
    return out

def analyze_sell_signals(ticker: str, hist: pd.DataFrame | None = None) -> dict | None:
    """Compose every bearish KPI into a single sell-pressure profile for one ticker.

    `hist` lets a bulk caller pass in a pre-fetched 1y price history (from a single
    yf.download for the whole portfolio) so we don't make a per-ticker history
    request here. When it's None we fetch individually, as the single-ticker path does.
    """
    ticker = (ticker or "").strip().upper()
    if not ticker:
        return None
    if hist is None:
        hist = fetch_history(ticker, period="1y")   # 1y so SMA200 is available (cached)
    if hist is None or len(hist) < 60:
        return None

    # Per-ticker endpoints below are cached; each paces itself on cache misses only.
    funds = fetch_fundamentals(ticker)
    analyst = fetch_analyst_signals(ticker)
    insider = fetch_insider_activity(ticker)

    close = hist["Close"]
    price = safe_float(close.iloc[-1])
    sma50 = safe_float(close.rolling(50).mean().iloc[-1])
    sma200 = safe_float(close.rolling(200).mean().iloc[-1]) if len(close) >= 200 else float("nan")
    _, _, macd_hist = compute_macd(close)
    macd_h = safe_float(macd_hist.iloc[-1])
    ret_1m = safe_float((price / close.iloc[-22] - 1) * 100) if len(close) >= 22 else float("nan")
    ret_3m = safe_float((price / close.iloc[-64] - 1) * 100) if len(close) >= 64 else float("nan")

    signals: list[tuple[str, float | None, str]] = []

    # 1) Analyst consensus — 1 (strong buy) .. 5 (strong sell)
    rm = analyst["rec_mean"]
    if not math.isnan(rm) and 1.0 <= rm <= 5.0:
        sc = clamp((rm - 1.0) / 4.0 * 100.0)
        key = analyst["rec_key"].replace("_", " ") or "n/a"
        n = "" if math.isnan(analyst["num_analysts"]) else f", {int(analyst['num_analysts'])} analysts"
        signals.append(("analyst", sc, f"Consensus: {key} (mean {rm:.2f}{n})"))
    else:
        signals.append(("analyst", None, "No analyst consensus available"))

    # 2) Recent rating changes / downgrades (the 'hold -> sell' indicator)
    changes = analyst["changes"]
    if changes:
        downs = sum(1 for c in changes if c["action"].lower() == "down")
        ups = sum(1 for c in changes if c["action"].lower() == "up")
        to_sell = sum(1 for c in changes if any(g in c["to"].lower() for g in _SELL_GRADES))
        sc = clamp(45 + 18 * downs - 15 * ups + (22 if to_sell else 0))
        detail = f"{downs} downgrade(s), {ups} upgrade(s) in {SELL_LOOKBACK_DAYS // 30}mo"
        if to_sell:
            detail += f"; {to_sell} cut to a sell-type rating"
        signals.append(("downgrades", sc, detail))
    else:
        signals.append(("downgrades", None, "No recent rating changes on file"))

    # 3) Price vs mean analyst target (price above target => implied downside)
    tgt = analyst["target_mean"]
    if not math.isnan(tgt) and tgt > 0 and not math.isnan(price) and price > 0:
        upside = (tgt / price - 1.0) * 100.0
        sc = clamp(50.0 - upside * 1.5)
        signals.append(("target", sc, f"Mean target {tgt:,.2f} vs price {price:,.2f} ({upside:+.1f}% implied)"))
    else:
        signals.append(("target", None, "No price target available"))

    # 4) Insider selling
    if insider["available"]:
        sv, bv = insider["sell_value"], insider["buy_value"]
        if (sv + bv) > 0:
            ratio = sv / (sv + bv)
        else:
            ratio = insider["n_sells"] / max(1, insider["n_sells"] + insider["n_buys"])
        sc = clamp(ratio * 100.0)
        signals.append(("insider", sc, f"{insider['n_sells']} sells vs {insider['n_buys']} buys in recent filings"))
    else:
        signals.append(("insider", None, "No insider transactions reported"))

    # 5) Technical breakdown
    tech, notes = 50.0, []
    if not math.isnan(sma50) and not math.isnan(price):
        if price < sma50: tech += 15; notes.append("below SMA50")
        else: tech -= 8
    if not math.isnan(sma200) and not math.isnan(price):
        if price < sma200: tech += 15; notes.append("below SMA200")
        else: tech -= 8
    if not math.isnan(sma50) and not math.isnan(sma200) and sma50 < sma200:
        tech += 10; notes.append("death cross (SMA50<SMA200)")
    if not math.isnan(macd_h):
        if macd_h < 0: tech += 12; notes.append("bearish MACD")
        else: tech -= 6
    signals.append(("technical", clamp(tech), ", ".join(notes) if notes else "trend intact / no breakdown"))

    # 6) Momentum trend (negative returns raise sell pressure)
    mb = 50.0
    if not math.isnan(ret_1m): mb -= ret_1m * 1.3
    if not math.isnan(ret_3m): mb -= ret_3m * 0.6
    signals.append(("momentum", clamp(mb), f"1M {fmt_pct(ret_1m)}, 3M {fmt_pct(ret_3m)}"))

    # 7) Short interest — only BEARISH when momentum is also negative. A heavily
    # shorted name that is RISING may be squeezing (the exact condition the buy
    # engine in analyze_ticker treats as BULLISH), so to avoid scoring the same
    # fact as both bullish and bearish we ignore short interest here unless the
    # 1-month momentum is negative.
    sp = funds["short_pct"]
    if math.isnan(sp):
        signals.append(("short", None, "Short interest not reported"))
    elif not math.isnan(ret_1m) and ret_1m < 0:
        signals.append(("short", clamp(40 + sp * 200),
                        f"{sp * 100:.1f}% of float short, with negative 1M momentum ({fmt_pct(ret_1m)})"))
    else:
        signals.append(("short", None,
                        f"{sp * 100:.1f}% short ignored — 1M momentum not negative (possible squeeze)"))

    # 8) Yahoo!掲示板 euphoria (Japan only). ASYMMETRIC and contrarian-aware:
    # only lopsided retail *bullishness* on a .T name adds sell pressure (the retail-top
    # pattern); a bearish or balanced board is neutral, never a sell push. Skipped
    # (None) for non-Japanese names and whenever no usable poll is available, so it
    # never dilutes a US/EU/CN composite.
    if ticker.endswith(".T") and st.session_state.get("_jp_forum_on", JP_FORUM_DEFAULT_ON):
        poll = fetch_jp_forum_rating(ticker)
        es = (forum_euphoria_sell_score(poll[0], poll[1], poll[2] if len(poll) > 2 else None)
              if poll else None)
        if es is None:
            signals.append(("forum", None, "No Yahoo!掲示板 poll available"))
        else:
            signals.append(("forum", es,
                f"Yahoo!掲示板 買いたい {poll[0]:.0f}% / 売りたい {poll[1]:.0f}% "
                + ("(euphoric — possible retail top)" if es > 50 else "(not euphoric — neutral)")))
    else:
        signals.append(("forum", None, "Japan board poll disabled or not applicable"))

    # Composite over only the KPIs that returned a score
    num = sum(SELL_KPI_WEIGHTS[k] * s for k, s, _ in signals if s is not None)
    den = sum(SELL_KPI_WEIGHTS[k] for k, s, _ in signals if s is not None)
    composite = (num / den) if den > 0 else float("nan")
    if math.isnan(composite):
        verdict = "low"
    else:
        verdict = "high" if composite >= SELL_HIGH else "mixed" if composite >= SELL_LOW else "low"

    return {
        "ticker": ticker, "name": funds["name"], "price": price,
        "currency": analyst["currency"], "composite": composite, "verdict": verdict,
        "signals": signals, "changes": changes, "insider": insider,
    }

# ----------------------------------------------------------------------------
# Backtesting / Evaluation Systems
# ----------------------------------------------------------------------------
# NOTE: the OLD recommendations-based gradient (evaluate_pending +
# update_weights_from_outcomes) was removed deliberately. It wrote the same
# kpi_weights as walk_forward_update, so the two loops fought each other and muddied
# the optimisation. walk_forward_update — driven by the curated mock_portfolio KPI
# snapshots — is now the SINGLE learning loop. evaluate_outcomes_only() below still
# resolves recommendation win/lose for the audit accuracy panel, but it carries NO
# gradient and never touches kpi_weights, so it can't reignite that conflict.

def _close_on_or_after(h: pd.DataFrame | None, when) -> float:
    """First close on or after `when`, compared on pure DATES (both sides normalized)
    so we align to the right end-of-day bar and never grab an intraday/unclosed price
    through a timezone mismatch. Shared by the optimiser and the outcome evaluator."""
    if h is None or h.empty:
        return float("nan")
    idx = pd.to_datetime(h.index)
    try:
        idx = idx.tz_localize(None)       # strip tz on a tz-aware index
    except (TypeError, AttributeError):
        pass                              # already tz-naive
    dates = idx.normalize()               # 00:00 -> date-level granularity
    when_ts = pd.Timestamp(when).normalize()
    sub = h[dates >= when_ts]
    return safe_float(sub["Close"].iloc[0]) if not sub.empty else float("nan")

def directional_outcome(recommendation: str, excess: float) -> int:
    """Win/loss for a directional call, from its excess (or absolute) return.

    A BUY is right when the name outperforms; a SELL is right when it UNDERPERFORMS.
    Scoring both the same way — as an earlier build did — silently inverted every
    bearish call in the accuracy stat. HOLD makes no directional claim and never
    reaches here; it is stored as OUTCOME_NEUTRAL and excluded from accuracy.
    """
    rec = str(recommendation or "").upper()
    if rec == "BUY":
        return OUTCOME_WIN if excess > 0 else OUTCOME_LOSS
    if rec == "SELL":
        return OUTCOME_WIN if excess < 0 else OUTCOME_LOSS
    return OUTCOME_NEUTRAL


def evaluate_outcomes_only() -> int:
    """Resolve the forward OUTCOME of matured recommendations for the Systems Audit
    accuracy / win-rate panel — WITHOUT any weight update. This intentionally has no
    gradient: walk_forward_update() is the single learning loop; this only fills
    win/lose so the audit reflects live picks rather than only seeded history.

    Win logic mirrors the optimiser exactly: the pick's dividend-inclusive TOTAL
    return (both endpoints read from one fresh auto_adjusted series) must beat its
    HOME-market index over the same [rec_date, rec_date+horizon] window.
    """
    df = get_recommendations()
    if df.empty:
        return 0
    cutoff = date.today() - timedelta(days=EVAL_HORIZON_DAYS)
    # Evaluate directional calls only. HOLD is neutral, so mark it as excluded (2)
    # rather than forcing it into a win/loss label or re-fetching it forever.
    hold_ids = df.loc[df["outcome"].isna() & (df["recommendation"] == "HOLD"), "id"].tolist()
    if hold_ids:
        with get_conn() as conn:
            conn.executemany(
                f"UPDATE recommendations SET outcome={OUTCOME_NEUTRAL}, eval_date=? WHERE id=?",
                [(date.today().isoformat(), int(i)) for i in hold_ids],
            )
    pending = df[(df["outcome"].isna())
                 & (df["recommendation"].isin(DIRECTIONAL_CALLS))
                 & (df["rec_date"].dt.date <= cutoff)]
    if pending.empty:
        return 0

    # Batch the price fetches, same pattern as walk_forward_update: one bulk
    # download for the pending tickers and their benchmarks, per-ticker fallback.
    pend_syms = list(dict.fromkeys(pending["ticker"].tolist()))
    bench_syms = sorted({b for b in (benchmark_for(t) for t in pend_syms) if b})
    bulk = get_histories(pend_syms + bench_syms, period="1y")

    bench_cache: dict[str, pd.DataFrame | None] = {s: bulk[s] for s in bench_syms if s in bulk}
    def bench_hist(sym: str | None) -> pd.DataFrame | None:
        if not sym:
            return None                  # unmapped listing: no benchmark
        if sym not in bench_cache:
            try:
                bench_cache[sym] = fetch_history(sym, period="1y")
            except Exception:
                bench_cache[sym] = None   # missing benchmark -> absolute-return fallback
        return bench_cache[sym]

    evaluated = 0
    with get_conn() as conn:
        for _, row in pending.iterrows():
            hist = bulk.get(row["ticker"])
            if hist is None:
                try:
                    hist = fetch_history(row["ticker"], period="1y")
                except Exception:
                    continue   # transient fetch failure -> skip this name, keep the batch alive
            rec_dt = row["rec_date"]
            target = rec_dt + timedelta(days=EVAL_HORIZON_DAYS)
            price_then = _close_on_or_after(hist, rec_dt)
            price_after = _close_on_or_after(hist, target)
            if math.isnan(price_after) or math.isnan(price_then) or price_then <= 0:
                continue
            stock_ret = price_after / price_then - 1.0

            bh = bench_hist(benchmark_for(row["ticker"]))
            b_then = _close_on_or_after(bh, rec_dt)
            b_after = _close_on_or_after(bh, target)
            if not math.isnan(b_then) and not math.isnan(b_after) and b_then > 0:
                excess = stock_ret - (b_after / b_then - 1.0)
                # BUY wins on positive excess return; SELL wins on negative excess return.
                win = directional_outcome(row["recommendation"], excess)
            else:
                # No usable benchmark: scored on ABSOLUTE return and LABELLED so, so it
                # is never counted as benchmark-relative accuracy.
                win = directional_outcome(row["recommendation"], stock_ret)
            basis = "excess" if (not math.isnan(b_then) and not math.isnan(b_after)
                                 and b_then > 0) else "absolute"
            conn.execute(
                "UPDATE recommendations SET price_after=?, outcome=?, eval_date=?, "
                "outcome_basis=? WHERE id=?",
                (price_after, win, date.today().isoformat(), basis, int(row["id"])),
            )
            evaluated += 1
        conn.commit()
    return evaluated

# ----------------------------------------------------------------------------
# Walk-Forward Optimisation: mock portfolio + factor-attribution feedback loop
# ----------------------------------------------------------------------------
OBS_HORIZONS = (5, 20, 60)   # trading days; different signals have different half-lives


def _close_after_sessions(hist, start, sessions: int) -> tuple:
    """(price_at_start, price_after_N_trading_sessions). Uses the index position, so
    'N days' means N actual sessions, not calendar days across weekends/holidays.
    Returns NaN for the second element when the horizon hasn't matured yet."""
    if hist is None or getattr(hist, "empty", True) or "Close" not in hist.columns:
        return (float("nan"), float("nan"))
    idx = hist.index
    try:
        pos = int(idx.searchsorted(pd.Timestamp(start)))
    except Exception:
        return (float("nan"), float("nan"))
    if pos >= len(idx):
        return (float("nan"), float("nan"))
    p0 = safe_float(hist["Close"].iloc[pos])
    tgt = pos + sessions
    p1 = safe_float(hist["Close"].iloc[tgt]) if tgt < len(idx) else float("nan")
    return (p0, p1)


def attach_early_setups(results: list[dict],
                        histories: dict | None = None) -> int:
    """Compute the measurement-only Early Setup score for a finished scan.

    Runs as a post-pass so analyze_ticker and the scoring path stay untouched. The
    only extra network cost is the handful of benchmark histories (one per region),
    fetched once and shared, for the relative-strength component.
    NOTHING here feeds the composite, the thresholds or the optimiser.
    """
    if not results:
        return 0
    # The result dict keeps ONLY Close (a deliberate Streamlit-Cloud memory fix), so
    # volume must come from the caller's full OHLCV frame. Without it the accumulation
    # component sat permanently at neutral 50 and vol_expanding was always False,
    # making CONFIRMED unreachable on live scans — the unit tests missed this because
    # they pass volume directly to the pure function.
    histories = histories or {}
    benches = sorted({b for b in (benchmark_for(r["ticker"]) for r in results
                                if r.get("ticker")) if b})
    try:
        bhist = get_histories(benches, period="1y")
    except Exception as e:
        logger.warning("benchmark history for early setup unavailable: %s", e)
        bhist = {}
    previous: dict = {}
    try:
        tickers = [r["ticker"] for r in results if r.get("ticker")]
        if tickers:
            marks = ",".join("?" for _ in tickers)
            with get_conn() as conn:
                prior = conn.execute(
                    f"SELECT ticker, setup_state, obs_date FROM observations "
                    f"WHERE ticker IN ({marks}) AND setup_state IS NOT NULL "
                    "AND setup_state <> '' ORDER BY obs_date DESC, id DESC",
                    tuple(tickers)).fetchall()
            # "Previous" = the latest observation strictly BEFORE this result's own
            # price date. Observations are dated by price bar, so excluding only
            # today's calendar date let a rescan of the SAME bar (every weekend scan,
            # every European-morning US scan) compare against itself and clear NEW.
            asof = {r["ticker"]: (r.get("price_date") or date.today().isoformat())
                    for r in results if r.get("ticker")}
            for t, state, d in prior:
                if t not in previous and str(d) < asof.get(t, ""):
                    previous[t] = state
    except Exception as e:
        logger.warning("prior setup-state lookup skipped: %s", e)

    n = 0
    for r in results:
        # Prefer the caller's full frame (has Volume); fall back to the Close-only
        # result frame for restored snapshots and older callers.
        hist = histories.get(r.get("ticker"))
        if hist is None:
            hist = r.get("history")
        if hist is None or getattr(hist, "empty", True) or "Close" not in hist.columns:
            continue
        bh = bhist.get(benchmark_for(r["ticker"]))
        try:
            # revisions was a dead input — never passed, so it sat at a constant 50.
            # US names now feed it the expectations score; elsewhere it stays neutral
            # and data_quality["revision_available"] says so.
            _rev = safe_float((r.get("expectations") or {}).get("expectations_score"))
            out = early_setup(hist["Close"],
                              hist["Volume"] if "Volume" in hist.columns else None,
                              revision_score=None if math.isnan(_rev) else _rev,
                              bench_close=(bh["Close"] if bh is not None
                                           and "Close" in getattr(bh, "columns", []) else None))
        except Exception as e:
            logger.warning("early setup failed for %s: %s", r.get("ticker"), e)
            continue
        if out:
            r["setup_score"] = out["score"]
            r["setup_state"] = out["state"]
            r["setup_components"] = out["components"]
            r["setup_trigger"] = out.get("trigger")
            r["setup_invalidation"] = out.get("invalidation")
            r["setup_metrics"] = {
                "distance_to_trigger_pct": out.get("distance_to_trigger_pct"),
                "distance_to_invalidation_pct": out.get("distance_to_invalidation_pct"),
                "risk_range_pct": out.get("risk_range_pct"),
            }
            r["setup_data_quality"] = out.get("data_quality") or {}
            r["setup_model_version"] = out.get("model_version", EARLY_SETUP_MODEL_VERSION)
            prev = previous.get(r["ticker"])
            active_states = ("EARLY WATCH", "SETUP STRENGTHENING", "CONFIRMED")
            r["setup_previous_state"] = prev
            r["setup_is_new"] = bool(out["state"] in active_states
                                     and prev not in active_states)
            r["setup_state_changed"] = bool(prev is not None and prev != out["state"])
            n += 1
    return n


# Column order of each observation row tuple built in record_observations. One list
# drives the INSERT and the by-name snapshot mapping, so the two cannot drift.
_OBS_INSERT_COLS = (
    "scan_id", "obs_date", "ticker", "region", "benchmark", "price", "composite",
    "recommendation", "rank_pct", "factors", "setup_score", "setup_state",
    "setup_components", "ret_1m", "setup_quality", "setup_metrics",
    "setup_model_version", "setup_is_new", "setup_state_changed",
    "setup_previous_state", "candidates", "model_version", "weights_snapshot",
    "benchmark_type", "sector", "industry", "market_cap", "scan_type",
    "expectations", "retail_sentiment", "scored_at")


def record_observations(results: list[dict], scan_type: str = "unknown") -> int:
    """Log EVERY scored name from this scan with its factor snapshot. One row per
    stock per scan (~100/scan; a daily habit is ~25k rows/year, trivial for SQLite
    or Postgres). Deduped per ticker per calendar day so reruns don't inflate it."""
    if not results:
        return 0
    ranked = sorted(results, key=lambda r: safe_float(r.get("composite"), float("-inf")),
                    reverse=True)
    n = len(ranked)
    scan_id = datetime.now().isoformat(timespec="seconds")   # scan timestamp (audit)
    # When the computation happened (UTC) — distinct from price_date, the bar it used.
    scored_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    today = date.today().isoformat()                          # fallback only
    # The exact weights that produced these composites. Weights move over time, so
    # without this a stored composite could not be reproduced later.
    try:
        weights_json = json.dumps({k: round(float(v), 6)
                                   for k, v in get_latest_weights().items()})
    except Exception:
        weights_json = "{}"
    rows = []
    for i, r in enumerate(ranked):
        rows.append((
            scan_id, (r.get("price_date") or today), r["ticker"], r.get("region", ""),
            benchmark_for(r["ticker"]),
            safe_float(r.get("price")), safe_float(r.get("composite")),
            str(r.get("recommendation", "")), round((n - i) / n * 100.0, 2),
            json.dumps({f: safe_float(r.get("hype_score" if f == "hype" else f))
                        for f in FACTORS}),
            safe_float(r.get("setup_score")), str(r.get("setup_state") or ""),
            json.dumps(r.get("setup_components") or {}), safe_float(r.get("ret_1m")),
            json.dumps(r.get("setup_data_quality") or {}),
            json.dumps(r.get("setup_metrics") or {}),
            str(r.get("setup_model_version") or ""),
            1 if r.get("setup_is_new") else 0,
            1 if r.get("setup_state_changed") else 0,
            str(r.get("setup_previous_state") or ""),
            json.dumps(r.get("candidates") or {}),
            PRODUCTION_MODEL_VERSION,
            # the weights that PRODUCED this composite; re-reading "current" weights at
            # write time could record a vector the score was never computed with
            (json.dumps({k: float(v) for k, v in r["weights_snapshot"].items()})
             if r.get("weights_snapshot") else weights_json),
            (BENCHMARK_TYPES.get(benchmark_for(r["ticker"]), "unknown")
             if benchmark_for(r["ticker"]) else "unavailable"),
            str(r.get("sector") or ""), str(r.get("industry") or ""),
            safe_float(r.get("market_cap")), scan_type,
            json.dumps(r.get("expectations") or {}),
            json.dumps({"jp_board": r.get("jp_board"), "stocktwits": r.get("stocktwits")},
                       default=str),
            scored_at,
        ))
    try:
        with get_conn() as conn:
            # Replace only tickers present in this scan. Deleting the whole day used
            # to erase observations from an earlier regional scan on the same date.
            conn.executemany(
                "DELETE FROM observations WHERE obs_date = ? AND ticker = ?",
                [(row[1], row[2]) for row in rows],
            )
            conn.executemany(
                f"INSERT INTO observations ({', '.join(_OBS_INSERT_COLS)}) "
                f"VALUES ({','.join('?' * len(_OBS_INSERT_COLS))})", rows)
            conn.executemany(
                "INSERT INTO observation_snapshots (scan_id, scored_at, price_date, ticker, region, "
                "composite, recommendation, factors, weights_snapshot, model_version, "
                "setup_model_version, inputs) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                [(d["scan_id"], scored_at, d["obs_date"], d["ticker"], d["region"],
                  d["composite"], d["recommendation"], d["factors"],
                  d["weights_snapshot"], d["model_version"], d["setup_model_version"],
                  json.dumps({"expectations": d["expectations"],
                              "retail_sentiment": d["retail_sentiment"]}))
                 # mapped BY NAME from the column list above, never by position
                 for d in (dict(zip(_OBS_INSERT_COLS, row)) for row in rows)])
    except Exception as e:
        logger.warning("observation write skipped: %s", e)
        return 0
    return len(rows)


def evaluate_observations(limit_tickers: int = 120) -> int:
    """Fill realised returns for matured observations: stock return AND benchmark
    return over the same window, stored as CONTINUOUS excess return per horizon —
    not the binary win/loss the old loop uses, so magnitude survives."""
    try:
        with get_conn() as conn:
            # Rows that can never fill — a delisted name, or a benchmark with no data
            # for that window — would otherwise sit at the head of this queue forever
            # and starve newer observations out of the per-run request budget. This is
            # sharper now that ANY missing horizon selects a row. 60 sessions is ~84
            # calendar days, so anything still incomplete after 200 days is abandoned
            # rather than retried indefinitely. Cutoff computed in Python because
            # SQLite and Postgres spell date arithmetic differently.
            stale_before = (date.today() - timedelta(days=200)).isoformat()
            pending = conn.execute(
                "SELECT id, ticker, obs_date, benchmark, x5, x20, x60 FROM observations "
                "WHERE (x5 IS NULL OR x20 IS NULL OR x60 IS NULL) AND obs_date >= ? "
                "ORDER BY obs_date ASC, ticker ASC", (stale_before,)).fetchall()
    except Exception as e:
        logger.warning("observation read skipped: %s", e)
        return 0
    if not pending:
        return 0
    rows = [dict(zip(("id", "ticker", "obs_date", "benchmark", "x5", "x20", "x60"), p))
            for p in pending]
    # Deterministic batching prevents an arbitrary set order from starving the same
    # pending names indefinitely when the ledger grows beyond the request cap.
    selected_tickers = list(dict.fromkeys(r["ticker"] for r in rows))[:limit_tickers]
    selected = set(selected_tickers)
    benchmarks = {r["benchmark"] for r in rows
                  if r["ticker"] in selected and r["benchmark"]}
    hists = get_histories(sorted(selected | benchmarks), period="1y")
    updated = 0
    try:
        with get_conn() as conn:
            for r in rows:
                if r["ticker"] not in selected:
                    continue
                h = hists.get(r["ticker"])
                bh = hists.get(r["benchmark"])
                if h is None:
                    continue
                vals, changed = {}, False
                for horizon in OBS_HORIZONS:
                    key = f"x{horizon}"
                    if r.get(key) is not None:
                        continue
                    # Both legs on the SAME market sessions, entry never moved forward
                    # (see indicators.forward_excess). Missing/stale benchmark -> NULL.
                    sr, _br, xr = forward_excess(
                        h["Close"], bh["Close"] if bh is not None and "Close" in bh.columns
                        else None, r["obs_date"], horizon)
                    if math.isnan(xr):
                        continue          # not matured, or no usable benchmark -> NULL
                    vals[f"r{horizon}"] = sr
                    vals[key] = xr
                    changed = True
                if changed:
                    sets = ", ".join(f"{k} = ?" for k in vals) + ", last_eval = ?"
                    conn.execute(f"UPDATE observations SET {sets} WHERE id = ?",
                                 (*vals.values(), date.today().isoformat(), r["id"]))
                    updated += 1
    except Exception as e:
        logger.warning("observation evaluation skipped: %s", e)
    return updated


def setup_buckets(horizon: int = 20, modest_only: bool = False,
                  modest_band: float = 5.0,
                  model_version: str = EARLY_SETUP_MODEL_VERSION) -> pd.DataFrame:
    """Realised forward excess return by EARLY SETUP bucket.

    `modest_only` restricts to names whose prior 1-month return was within
    +/-modest_band%. That is the honest test of a pre-breakout signal: among stocks
    that have NOT already moved, does a high setup score still precede excess
    return? If the edge only appears once a name has run, the detector is just
    measuring momentum the composite already captures.
    """
    col = f"x{horizon}"
    try:
        with get_conn() as conn:
            df = pd.read_sql_query(
                f"SELECT setup_score, setup_state, composite, ret_1m, {col} AS excess "
                f"FROM observations WHERE {col} IS NOT NULL AND setup_score IS NOT NULL "
                "AND setup_model_version = ?", conn, params=(model_version,))
    except Exception as e:
        logger.warning("setup bucket read skipped: %s", e)
        return pd.DataFrame()
    if df.empty:
        return pd.DataFrame()
    if modest_only:
        df = df[df["ret_1m"].abs() <= modest_band]
        if df.empty:
            return pd.DataFrame()
    edges = [0, 40, 52, 60, 70, 101]
    labels = ["<40", "40-51", "52-59 (watch)", "60-69 (strengthening)", "70+"]
    df["bucket"] = pd.cut(df["setup_score"], bins=edges, labels=labels, right=False)
    out = (df.groupby("bucket", observed=False)["excess"]
             .agg(["count", "mean", "median",
                   ("positive_rate", lambda s: 100.0 * (s > 0).mean())]).reset_index())
    return out[out["count"] > 0]


def setup_state_performance(horizon: int = 20,
                            model_version: str = EARLY_SETUP_MODEL_VERSION) -> pd.DataFrame:
    """Forward excess return grouped by setup STATE — the check that the state
    ladder is ordered sensibly (SETUP FAILED should not out-earn CONFIRMED)."""
    col = f"x{horizon}"
    try:
        with get_conn() as conn:
            df = pd.read_sql_query(
                f"SELECT setup_state, {col} AS excess FROM observations "
                f"WHERE {col} IS NOT NULL AND setup_state IS NOT NULL "
                f"AND setup_state <> '' AND setup_model_version = ?",
                conn, params=(model_version,))
    except Exception as e:
        logger.warning("setup state read skipped: %s", e)
        return pd.DataFrame()
    if df.empty:
        return pd.DataFrame()
    out = (df.groupby("setup_state")["excess"]
             .agg(["count", "mean", "median"]).reset_index())
    order = {s: i for i, s in enumerate(SETUP_STATES)}
    out["_o"] = out["setup_state"].map(lambda s: order.get(s, 99))
    return out.sort_values("_o").drop(columns="_o")


IC_MIN_DATES = 10    # scan dates with matured outcomes before an IC is shown as readable


COHORT_MIN_NAMES = 10     # a (date, region) cohort needs this many names for quintiles


def composite_summary(horizon: int = 20) -> dict | None:
    """Headline evidence for the composite at one horizon (current model only).

    Quintiles are formed WITHIN each (scan date, region) cohort, then each cohort's
    top-minus-bottom spread is averaged with equal weight per cohort. Pooling all
    dates together (the previous version) let market regime pose as skill: in a
    period when every name scored high and every name rose, the pooled top quintile
    "beat" the bottom without any stock selection at all. Cohorts with fewer than
    COHORT_MIN_NAMES names, or fewer than five distinct scores (ties are never split
    arbitrarily), are excluded and counted.

    Note: daily 20/60-session outcomes overlap, so cohorts are NOT independent
    samples; no confidence interval is claimed from this table.
    """
    col = f"x{horizon}"
    try:
        with get_conn() as conn:
            df = pd.read_sql_query(
                f"SELECT obs_date, region, composite, {col} AS excess FROM observations "
                f"WHERE {col} IS NOT NULL AND composite IS NOT NULL AND model_version = ?",
                conn, params=(PRODUCTION_MODEL_VERSION,))
    except Exception as e:
        logger.warning("composite summary read skipped: %s", e)
        return None
    df = df.dropna(subset=["composite", "excess"])
    if len(df) < 50:
        return {"n": int(len(df))}
    df["region"] = df["region"].fillna("")
    cohorts, excluded = [], 0
    for (_d, _rg), g in df.groupby(["obs_date", "region"]):
        if len(g) < COHORT_MIN_NAMES or g["composite"].nunique() < 5:
            excluded += 1
            continue
        q = pd.qcut(g["composite"], 5, labels=False, duplicates="drop")
        if q.nunique() != 5:
            excluded += 1
            continue
        top, bot = g.loc[q == 4, "excess"], g.loc[q == 0, "excess"]
        cohorts.append({"top": float(top.mean()), "bot": float(bot.mean()),
                        "pos": float((top > 0).mean() * 100.0)})
    ic_tab = cross_sectional_ic(df, ["composite"], "excess")
    out = {"n": int(len(df)), "cohorts": len(cohorts), "excluded_cohorts": excluded,
           "ic": float(ic_tab["mean_ic"].iloc[0]) if not ic_tab.empty else float("nan"),
           "ic_dates": int(ic_tab["n_dates"].iloc[0]) if not ic_tab.empty else 0,
           "median": float(df["excess"].median())}
    if not cohorts:
        return out                       # rows exist but no cohort qualifies
    c = pd.DataFrame(cohorts)
    out.update(top_q=float(c["top"].mean()), bottom_q=float(c["bot"].mean()),
               spread=float((c["top"] - c["bot"]).mean()),
               top_positive_rate=float(c["pos"].mean()))
    return out


def region_breakdown(horizon: int = 20) -> pd.DataFrame:
    """Realised excess return per region (current model). Worth seeing separately
    because benchmark methodology differs by region, so a region's number is only
    comparable with itself over time, not with the others."""
    col = f"x{horizon}"
    try:
        with get_conn() as conn:
            df = pd.read_sql_query(
                f"SELECT region, {col} AS excess FROM observations "
                f"WHERE {col} IS NOT NULL AND model_version = ?", conn,
                params=(PRODUCTION_MODEL_VERSION,))
    except Exception as e:
        logger.warning("region breakdown read skipped: %s", e)
        return pd.DataFrame()
    if df.empty:
        return pd.DataFrame()
    return (df.groupby("region")["excess"]
              .agg(["count", "mean", "median"]).reset_index()
              .sort_values("count", ascending=False))


def benchmark_mix() -> dict:
    """{benchmark_type: count} over current-model observations — used to flag that
    excess returns against price indices and against a total-return ETF are not
    strictly comparable."""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT benchmark_type, COUNT(*) FROM observations WHERE model_version = ? "
                "GROUP BY benchmark_type", (PRODUCTION_MODEL_VERSION,)).fetchall()
        return {str(k or "unknown"): int(v) for k, v in rows}
    except Exception as e:
        logger.warning("benchmark mix read skipped: %s", e)
        return {}


# Translation keys for every CANDIDATE signal the ledger can hold. A candidate key
# missing here is caught by a test that runs attach_candidate_signals and checks every
# key it produced.
SIGNAL_LABEL_KEYS = {
    "mom_long_skip1m": "ic_cand_mom_long", "rel_ret_1m": "ic_cand_rel_1m",
    "abs_ret_1m": "ic_cand_abs_1m", "expectations_score": "ic_cand_expect",
    "eps_revision_score": "ic_cand_eps_rev", "eps_trend_score": "ic_cand_eps_trend",
    "forward_growth_score": "ic_cand_fwd_growth",
    "earnings_surprise_score": "ic_cand_surprise",
    "stocktwits_score": "ic_cand_st_score", "stocktwits_attention": "ic_cand_st_attention",
}


def signal_kind(sig: str) -> str:
    """'production' only for the six scored factors; everything else is a candidate."""
    return "production" if sig in FACTORS else "candidate"


def signal_label(sig: str) -> str:
    if sig in FACTORS:
        return tr(f"factor_{sig}")
    return tr(SIGNAL_LABEL_KEYS[sig]) if sig in SIGNAL_LABEL_KEYS else str(sig)


def ic_display_frame(ic: pd.DataFrame) -> pd.DataFrame:
    """Localised signal names and kind for the IC table. Kind and label come from
    signal_kind()/signal_label(): anything that is not a production factor is a
    candidate, so a newly added candidate key can no longer fall through to the
    "production" label (the Stocktwits keys did exactly that)."""
    out = ic.copy()
    out["kind"] = out["signal"].map(
        lambda x: tr("ic_kind_candidate") if signal_kind(x) == "candidate"
        else tr("ic_kind_production"))
    out["signal"] = out["signal"].map(signal_label)
    return out


def factor_ic_report(horizon: int = 20) -> tuple[pd.DataFrame, int]:
    """Cross-sectional Information Coefficient for each production factor and each
    candidate signal against realised excess return. Returns (table, n_dates).

    This is the missing piece for any honest model change: the composite-bucket view
    says whether the blend works, this says WHICH ingredient works. Read-only.
    """
    col = f"x{horizon}"
    try:
        with get_conn() as conn:
            df = pd.read_sql_query(
                f"SELECT obs_date, factors, candidates, {col} AS target FROM observations "
                f"WHERE {col} IS NOT NULL AND model_version = ?", conn,
                params=(PRODUCTION_MODEL_VERSION,))
    except Exception as e:
        logger.warning("IC read skipped: %s", e)
        return pd.DataFrame(), 0
    if df.empty:
        return pd.DataFrame(), 0
    def _load(txt):
        try:
            return json.loads(txt or "{}")
        except Exception:
            return {}
    fac = pd.DataFrame([_load(t) for t in df["factors"]], index=df.index)
    cand = pd.DataFrame([_load(t) for t in df["candidates"]], index=df.index)
    wide = pd.concat([df[["obs_date", "target"]], fac, cand], axis=1)
    signals = [c for c in list(fac.columns) + list(cand.columns) if c in wide.columns]
    table = cross_sectional_ic(wide, signals, "target")
    return table, int(wide["obs_date"].nunique())


def previous_composites(tickers: list, asof: dict | None = None) -> dict:
    """{ticker: (composite, obs_date)} from the latest observation strictly BEFORE
    each ticker's own as-of (price) date.

    `asof` maps ticker -> the price date of the CURRENT result. Observations are dated
    by price bar, so comparing against "before today" would, on any scan whose last
    bar predates today (weekends; US names scanned before the US open), pick up this
    very scan's own row and report a change of zero for every name.
    """
    if not tickers:
        return {}
    asof = asof or {}
    try:
        marks = ",".join("?" for _ in tickers)
        with get_conn() as conn:
            rows = conn.execute(
                f"SELECT ticker, composite, obs_date FROM observations WHERE ticker IN ({marks}) "
                "AND composite IS NOT NULL ORDER BY obs_date DESC, id DESC",
                tuple(tickers)).fetchall()
    except Exception as e:
        logger.warning("previous composite lookup skipped: %s", e)
        return {}
    today = date.today().isoformat()
    out: dict = {}
    for t, comp, d in rows:
        if t not in out and str(d) < (asof.get(t) or today):
            out[t] = (safe_float(comp), d)
    return out


def observation_buckets(horizon: int = 20) -> pd.DataFrame:
    """Mean realised excess return by composite-score bucket — the honest version of
    'does a high score mean anything?'. Descriptive statistics on matured
    observations; NOT a forecast and deliberately not converted into a probability
    until there is enough out-of-sample history to calibrate one."""
    col = f"x{horizon}"
    try:
        with get_conn() as conn:
            df = pd.read_sql_query(
                f"SELECT composite, {col} AS excess FROM observations "
                f"WHERE {col} IS NOT NULL AND model_version = ?", conn,
                params=(PRODUCTION_MODEL_VERSION,))
    except Exception as e:
        logger.warning("bucket read skipped: %s", e)
        return pd.DataFrame()
    if df.empty:
        return pd.DataFrame()
    edges = [0, 50, 60, 70, 80, 90, 101]
    labels = ["<50", "50-59", "60-69", "70-79", "80-89", "90+"]
    df["bucket"] = pd.cut(df["composite"], bins=edges, labels=labels, right=False)
    out = (df.groupby("bucket", observed=False)["excess"]
             .agg(["count", "mean", "median"]).reset_index())
    out = out[out["count"] > 0]
    return out


def save_mock_portfolio(results: list[dict]) -> None:
    """Log today's Top-3 Growth and Top-3 Dividend picks with a full KPI snapshot.

    Growth = highest 1-month momentum; Dividend = highest composite among names
    yielding >= 1.5%. Idempotent per day: re-running a scan the same day refreshes
    the entry for a given ticker+reason rather than duplicating it.
    """
    if not results:
        return

    def _val(r, k, d=float("nan")):
        return safe_float(r.get(k), d)

    growth = sorted(
        [r for r in results if not math.isnan(_val(r, "ret_1m"))],
        key=lambda r: _val(r, "ret_1m"), reverse=True,
    )[:3]
    dividend = sorted(
        [r for r in results if not math.isnan(_val(r, "div_yield")) and r["div_yield"] >= 1.5],
        key=lambda r: _val(r, "composite", 0.0), reverse=True,
    )[:3]
    picks = [(r, "Top Growth") for r in growth] + [(r, "Top Dividend") for r in dividend]

    today = date.today().isoformat()
    ts = datetime.now().isoformat(timespec="seconds")
    with get_conn() as conn:
        for r, reason in picks:
            snapshot = json.dumps({
                "momentum": round(_val(r, "momentum", 0.0), 2),
                "value": round(_val(r, "value", 0.0), 2),
                "technical": round(_val(r, "technical", 0.0), 2),
                "hype": round(_val(r, "hype_score", 0.0), 2),
                "quality": round(_val(r, "quality", 0.0), 2),
                "theme": round(_val(r, "theme", 50.0), 2),
                "composite": round(_val(r, "composite", 0.0), 2),
            })
            conn.execute(
                "DELETE FROM mock_portfolio WHERE ticker=? AND reason=? AND "
                "(price_date=? OR (price_date IS NULL AND date(timestamp)=?))",
                (r["ticker"], reason, r.get("price_date") or today, today),
            )
            conn.execute(
                "INSERT INTO mock_portfolio (timestamp, ticker, recommendation_price, reason, kpi_snapshot, evaluated, name, price_date) VALUES (?,?,?,?,?,0,?,?)",
                (ts, r["ticker"], _val(r, "price"), reason, snapshot,
                 str(r.get("name") or r["ticker"]), r.get("price_date") or today),
            )
        conn.commit()

def get_mock_portfolio() -> pd.DataFrame:
    with get_conn() as conn:
        return pd.read_sql_query(
            "SELECT timestamp, ticker, name, recommendation_price, reason, price_date "
            "FROM mock_portfolio ORDER BY id DESC", conn
        )

# ----------------------------------------------------------------------------
# Scan snapshots — persist the last scan so a refresh / new session restores it
# instead of greeting a returning user with the empty state. The price history
# frames are STRIPPED before serialising (they're the bulk of the memory and
# aren't JSON-serialisable); the Deep-Dive page lazily refetches the one frame
# it needs. Everything else in an analysis dict round-trips through json.
# ----------------------------------------------------------------------------
_SCAN_SNAPSHOT_KEEP = 5   # newest rows retained; older ones pruned on save


def _json_safe(o):
    """json.dumps default hook: numpy scalars sneak into analysis dicts (np.mean,
    Series.iloc) and json refuses them — coerce to plain Python."""
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return str(o)


def save_scan_snapshot(results: list[dict], is_quick: bool) -> None:
    """Persist one scan's results (sans history frames). Never raises — snapshot
    persistence must not be able to sink an otherwise-successful scan."""
    try:
        payload = json.dumps(
            [{k: v for k, v in r.items() if k != "history"} for r in results],
            default=_json_safe)
        ts = datetime.now().isoformat(timespec="seconds")
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO scan_snapshots (created_at, is_quick, n_results, payload) VALUES (?,?,?,?)",
                (ts, 1 if is_quick else 0, len(results), payload))
            # Prune: keep only the newest N snapshots (valid on sqlite AND Postgres).
            conn.execute(
                "DELETE FROM scan_snapshots WHERE id NOT IN "
                "(SELECT id FROM scan_snapshots ORDER BY id DESC LIMIT ?)",
                (_SCAN_SNAPSHOT_KEEP,))
            conn.commit()
    except Exception as e:
        logger.warning("scan snapshot save failed: %s", e)


def load_latest_scan_snapshot() -> tuple[list[dict], str, bool] | None:
    """(results, created_at_iso, is_quick) of the newest snapshot, or None.
    Restored dicts have no 'history' key — consumers must treat it as optional."""
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT created_at, is_quick, payload FROM scan_snapshots ORDER BY id DESC LIMIT 1"
            ).fetchone()
        if row is None:
            return None
        results = json.loads(row["payload"] or "[]")
        if not isinstance(results, list) or not results:
            return None
        return results, str(row["created_at"]), bool(row["is_quick"])
    except Exception as e:
        logger.warning("scan snapshot load failed: %s", e)
        return None


def _bulk_history(tickers: list, period: str = "1y") -> dict:
    """Fetch history for many tickers in ONE yf.download, returned as
    {ticker: DataFrame} so a bulk scan reuses it instead of one request per name.

    Tickers with no usable Close series (delisted, or fewer than 60 rows) are
    omitted, so the caller falls back to an individual fetch for those. Never raises.
    """
    out: dict[str, pd.DataFrame] = {}
    uniq = list(dict.fromkeys(t for t in tickers if t))
    if yf is None or not uniq:
        return out
    try:
        kwargs = dict(period=period, progress=False, threads=False,
                      group_by="ticker", auto_adjust=True)
        try:
            data = yf.download(uniq, session=_YF_SESSION, **kwargs)   # reuse SSL-aware session
        except TypeError:
            data = yf.download(uniq, **kwargs)                        # older yfinance: no session kwarg
    except Exception:
        return out
    if data is None or len(data) == 0:
        return out
    try:
        if isinstance(data.columns, pd.MultiIndex):
            # group_by="ticker" -> column level 0 = ticker, level 1 = field.
            available = set(data.columns.get_level_values(0))
            for t in uniq:
                if t not in available:
                    continue
                frame = data[t]
                if "Close" in frame.columns:
                    sub = frame.dropna(subset=["Close"])
                    if len(sub) >= 60:
                        out[t] = sub
        elif "Close" in data.columns and len(uniq) == 1:
            sub = data.dropna(subset=["Close"])     # single ticker -> flat columns
            if len(sub) >= 60:
                out[uniq[0]] = sub
    except Exception:
        return out
    return out

_HIST_CACHE_TTL = 1800   # seconds a per-ticker frame stays fresh in the session cache

def get_histories(tickers: list, period: str = "1y") -> dict:
    """Session-level history cache in front of _bulk_history.

    Every bulk consumer (quick scan, deep scan, sell scanner, walk-forward and
    maturity updates) goes through here, so a ticker's frame is downloaded ONCE
    per session per TTL and shared across features — previously each feature paid
    its own full bulk download even for overlapping names (benchmarks, promoted
    tickers, portfolio names that were just scanned). Only the tickers that are
    missing or stale are fetched, in a single yf.download. Returns
    {ticker: DataFrame} like _bulk_history; missing names are simply absent so
    callers' per-ticker fallbacks keep working unchanged.
    """
    cache = st.session_state.setdefault("_hist_cache", {})   # {(t, period): (df, ts)}
    now = time.time()
    # Prune expired entries first: without this, frames for tickers that are never
    # requested again (rotated screener names, one-off portfolio symbols) would sit
    # in session memory for the lifetime of the session.
    for k in [k for k, (_, ts) in cache.items() if now - ts > _HIST_CACHE_TTL]:
        del cache[k]
    missing = [t for t in dict.fromkeys(t for t in tickers if t)
               if (t, period) not in cache or now - cache[(t, period)][1] > _HIST_CACHE_TTL]
    if missing:
        for t, df in _bulk_history(missing, period).items():
            cache[(t, period)] = (df, now)
    return {t: cache[(t, period)][0] for t in tickers if (t, period) in cache}

def clear_market_data_caches() -> None:
    """Escape hatch for the 30-min data TTLs: wipe the session history cache and
    the per-ticker market-data fetchers so the NEXT scan re-hits Yahoo and picks
    up sudden intraday price action instead of serving cached frames.

    Deliberately surgical — sentiment caches (Reddit/GDELT hype, JP forum) are
    left alone: they aren't price data, and re-hitting those courtesy-throttled
    endpoints early would be both slow and impolite."""
    st.session_state.pop("_hist_cache", None)          # shared bulk-history frames
    for fn in (fetch_history, fetch_fundamentals, fetch_analyst_signals,
               fetch_insider_activity, _bulk_latest_close):
        try:
            fn.clear()                                 # per-function st.cache_data wipe
        except Exception:
            pass   # decorator absent (e.g. hot-reload edge) -> nothing cached anyway

@st.cache_data(ttl=300, show_spinner=False)
def _bulk_latest_close(tickers: tuple) -> dict:
    """Most-recent close for many tickers in ONE bulk yf.download request.

    Cached 5 min per ticker tuple: on the audit tab any widget interaction reruns
    the whole script, and while "update prices" is ticked that used to refire the
    full bulk download every rerun. Callers pass a TUPLE (hashable cache key).

    Fetching prices one ticker at a time hammered Yahoo and tripped its IP rate
    limiter (crashing the app on Streamlit Cloud). A single `yf.download(...)` for
    the whole list fixes that. Returns {ticker: close} with NaN for anything that
    didn't come back, and never raises.

    Uses a 5-day window and takes each ticker's LAST NON-NaN close (not the single
    most-recent row) — a mixed US/European batch otherwise leaves the off-calendar
    market (e.g. MC.PA, ASML) NaN on the last row, which showed up as a blank
    "Current Price". Any symbol the bulk request drops entirely gets a bounded
    single-ticker fallback.
    """
    out = {t: float("nan") for t in tickers}
    uniq = list(dict.fromkeys(tickers))
    if yf is None or not uniq:
        return out
    kwargs = dict(period="5d", progress=False, threads=False, auto_adjust=True)
    data = None
    for attempt in range(2):                  # one retry: Yahoo throttles request bursts
        try:
            try:
                data = yf.download(uniq, session=_YF_SESSION, **kwargs)   # SSL-aware session
            except TypeError:
                data = yf.download(uniq, **kwargs)                        # older yfinance: no session kwarg
        except Exception:
            data = None
        if data is not None and len(data):
            break
        if attempt == 0:
            time.sleep(1.0)                   # brief pause, then one more attempt
    if data is not None and len(data):
        try:
            if isinstance(data.columns, pd.MultiIndex):
                close = data["Close"]                 # columns = tickers
                for t in uniq:
                    if t in close.columns:
                        col = close[t].dropna()       # last VALID close for THIS ticker,
                        if not col.empty:             # not the global last row
                            out[t] = safe_float(col.iloc[-1])
            else:
                series = data["Close"].dropna()       # single-ticker frame: flat columns
                if not series.empty and len(uniq) == 1:
                    out[uniq[0]] = safe_float(series.iloc[-1])
        except Exception:
            pass
    # Per-ticker fallback for anything still unresolved (yfinance can silently omit
    # symbols from a mixed-exchange batch). Bounded to the misses, so it can't
    # reintroduce a full per-ticker fetch storm.
    for t in [t for t in uniq if math.isnan(out[t])]:
        try:
            s = fetch_history(t, period="5d")["Close"].dropna()   # has retry/backoff
            if not s.empty:
                out[t] = safe_float(s.iloc[-1])
        except Exception:
            pass
    return out

def _pick_asof(row) -> "pd.Timestamp":
    """A mock pick's as-of date: its stored price_date (the bar actually scored), or
    the scan timestamp for rows written before price_date existed (explicit legacy
    fallback). Dating by scan timestamp alone mis-dates weekend / pre-open picks."""
    pd_ = None
    try:
        pd_ = row["price_date"]
    except (KeyError, IndexError):
        pd_ = None
    return pd.to_datetime(pd_ if pd_ else row["timestamp"], errors="coerce")


def walk_forward_update() -> int:
    """Walk-forward optimiser driven by the mock_portfolio KPI snapshots.

    For each logged pick that has matured (>= EVAL_HORIZON_DAYS old) and hasn't yet
    been scored, compute its benchmark-relative forward return, then attribute that
    outcome to the KPI profile it was picked on: factors that scored highly on
    winners get nudged UP, factors that scored highly on losers get nudged DOWN
    (so e.g. Value rises if value-heavy picks are beating their market). The new
    weights are persisted via save_weights — meaning they drive scoring through
    score_with_weights AND land in the system_weights ledger. Each pick is flagged
    evaluated so it contributes exactly once. Returns the count newly evaluated.
    """
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, timestamp, ticker, recommendation_price, kpi_snapshot, price_date "
            "FROM mock_portfolio WHERE evaluated=0"
        ).fetchall()
    if not rows:
        return 0

    cutoff = date.today() - timedelta(days=EVAL_HORIZON_DAYS)

    # Batch the price fetches: ONE bulk download covering every matured ticker plus
    # its benchmark, instead of a per-ticker fetch (with 3-retry backoff) inside the
    # loop. Bulk misses fall back to the per-ticker path below.
    matured_syms: list[str] = []
    for row in rows:
        _dt = _pick_asof(row)
        if not pd.isna(_dt) and _dt.date() <= cutoff:
            matured_syms.append(row["ticker"])
    bench_syms = sorted({b for b in (benchmark_for(t) for t in matured_syms) if b})
    bulk = get_histories(list(dict.fromkeys(matured_syms)) + bench_syms, period="1y")

    bench_cache: dict[str, pd.DataFrame | None] = {s: bulk[s] for s in bench_syms if s in bulk}
    def bench_hist(sym: str | None) -> pd.DataFrame | None:
        if not sym:
            return None                  # unmapped listing: no benchmark
        if sym not in bench_cache:
            try:
                bench_cache[sym] = fetch_history(sym, period="1y")
            except Exception:
                bench_cache[sym] = None   # missing benchmark -> absolute-return fallback
        return bench_cache[sym]

    grad = {f: 0.0 for f in FACTORS}
    evaluated_ids, n = [], 0
    for row in rows:
        rec_dt = _pick_asof(row)
        if pd.isna(rec_dt) or rec_dt.date() > cutoff:
            continue   # not matured yet — leave unflagged so it's re-checked later
        try:
            snap = json.loads(row["kpi_snapshot"] or "{}")
        except Exception:
            snap = {}
        hist = bulk.get(row["ticker"])
        if hist is None:
            try:
                hist = fetch_history(row["ticker"], period="1y")
            except Exception:
                continue   # transient fetch failure -> skip this name, keep the batch alive
        target = rec_dt + timedelta(days=EVAL_HORIZON_DAYS)
        # Fix 5 — derive BOTH endpoints from the SAME freshly-fetched, dividend-
        # adjusted series (fetch_history uses auto_adjust=True, which folds dividends
        # into the close). That makes stock_ret a proper TOTAL return, so Value /
        # Dividend picks get credit for payouts. Re-deriving the entry price here
        # (rather than using the stored recommendation_price) also keeps both ends on
        # one adjustment baseline — adding a separate dividend-yield term on top would
        # double-count, since the series is already adjusted.
        price_then = _close_on_or_after(hist, rec_dt)
        price_after = _close_on_or_after(hist, target)
        if math.isnan(price_after) or math.isnan(price_then) or price_then <= 0:
            continue
        stock_ret = price_after / price_then - 1.0

        bh = bench_hist(benchmark_for(row["ticker"]))
        b_then = _close_on_or_after(bh, rec_dt)
        b_after = _close_on_or_after(bh, target)
        if not math.isnan(b_then) and not math.isnan(b_after) and b_then > 0:
            win = stock_ret > (b_after / b_then - 1.0)   # beat its home market
        else:
            win = stock_ret > 0                          # fallback: absolute return
        direction = 1.0 if win else -1.0
        for f in FACTORS:
            grad[f] += direction * (safe_float(snap.get(f), 50.0) / 100.0 - 0.5)
        evaluated_ids.append(int(row["id"]))
        n += 1

    if n == 0:
        return 0

    weights = get_latest_weights()
    new = {f: max(MIN_WEIGHT, weights[f] + LEARNING_RATE * grad[f] / n) for f in FACTORS}
    total = sum(new.values())
    new = {f: new[f] / total for f in FACTORS}
    if ENABLE_LEGACY_WEIGHT_LEARNING:
        save_weights(new, note=f"Walk-forward update on {n} matured mock-portfolio pick(s)")
    else:
        # Shadow mode: record the proposal next to the weights actually in force, so
        # the two can be compared later without the legacy loop moving production.
        try:
            with get_conn() as conn:
                conn.execute(
                    "INSERT INTO shadow_weights (created_at, n_picks, proposed, active, note) "
                    "VALUES (?,?,?,?,?)",
                    (datetime.now().isoformat(timespec="seconds"), int(n),
                     json.dumps({k: round(v, 6) for k, v in new.items()}),
                     json.dumps({k: round(float(v), 6) for k, v in weights.items()}),
                     "legacy walk-forward (shadow)"))
        except Exception as e:
            logger.warning("shadow weight log skipped: %s", e)

    with get_conn() as conn:
        conn.executemany("UPDATE mock_portfolio SET evaluated=1 WHERE id=?", [(i,) for i in evaluated_ids])
        conn.commit()
    return n

def seed_demo_history() -> None:
    """Populate the SEPARATE demo database with a simulated audit trail.

    Writes nothing to the live database: earlier builds inserted these rows into the
    live recommendations table and called save_weights() five times on it, so one
    click made synthetic weights the active production weights — even with the
    legacy learner frozen. Idempotent: reseeding replaces the demo data.
    """
    init_db(demo=True)
    rng = np.random.default_rng(42)
    with get_conn(demo=True) as conn:
        for tbl in ("recommendations", "kpi_weights", "system_weights"):
            conn.execute(f"DELETE FROM {tbl}")
        for i in range(40):
            d = (date.today() - timedelta(days=80 - i * 2)).isoformat()
            t = ALL_TICKERS[i % len(ALL_TICKERS)]
            scores = {f: float(rng.uniform(40, 85)) for f in FACTORS}
            comp = float(np.mean(list(scores.values())))
            win = int(rng.random() < 0.62)
            price = float(rng.uniform(100, 300))
            rec = "BUY" if comp > 60 else "HOLD"
            # HOLD carries no directional claim, so it is seeded NEUTRAL.
            outcome = win if rec in DIRECTIONAL_CALLS else OUTCOME_NEUTRAL
            conn.execute(
                "INSERT INTO recommendations (ticker, rec_date, recommendation, composite, price_at_rec, momentum, value, technical, hype, quality, theme, price_after, outcome, eval_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (t, d, rec, comp, price, scores["momentum"], scores["value"], scores["technical"], scores["hype"], scores["quality"], scores["theme"], price * (1.06 if win else 0.94), outcome, d)
            )
        conn.commit()
    w = dict(DEFAULT_WEIGHTS)
    save_weights(dict(DEFAULT_WEIGHTS), note="demo: initial defaults", demo=True)
    for k in range(5):
        w["momentum"] = min(0.45, w["momentum"] + 0.02)
        w["value"] = max(MIN_WEIGHT, w["value"] - 0.01)
        tot = sum(w.values())
        save_weights({f: w[f] / tot for f in FACTORS}, note=DEMO_WEIGHT_NOTE, demo=True)


def clear_demo_data() -> None:
    """Delete the demo database file. Live data is never touched."""
    try:
        if os.path.exists(DEMO_DB_PATH):
            os.remove(DEMO_DB_PATH)
    except OSError as e:
        logger.warning("could not remove demo database: %s", e)


def live_demo_contamination() -> dict:
    """How much demo data an OLDER build wrote into the LIVE database.

    Weight rows are identifiable exactly (the demo note never changed). Seeded
    recommendation rows are NOT reliably distinguishable from real ones, so they
    are only counted under a narrow fingerprint and reported, never deleted."""
    out = {"weight_rows": 0, "active_weights_are_demo": False, "suspect_recommendations": 0}
    try:
        with get_conn() as conn:
            out["weight_rows"] = int(conn.execute(
                "SELECT COUNT(*) FROM kpi_weights WHERE note = ?",
                (DEMO_WEIGHT_NOTE,)).fetchone()[0])
            last = conn.execute("SELECT note FROM kpi_weights ORDER BY id DESC LIMIT 1").fetchone()
            out["active_weights_are_demo"] = bool(last and last[0] == DEMO_WEIGHT_NOTE)
            # fingerprint of the old seeder: evaluated on its own rec date at exactly +/-6%
            out["suspect_recommendations"] = int(conn.execute(
                "SELECT COUNT(*) FROM recommendations WHERE eval_date = rec_date "
                "AND price_at_rec > 0 AND (ABS(price_after / price_at_rec - 1.06) < 1e-9 "
                "OR ABS(price_after / price_at_rec - 0.94) < 1e-9)").fetchone()[0])
    except Exception as e:
        logger.warning("demo contamination check skipped: %s", e)
    return out


# Yahoo! JP board poll: OFF by default. Its page parser is structural and has not been
# verified against Yahoo's live page, yet when on it feeds the production hype score.
# Users opt in from the sidebar; flip this only once a live-page fixture is verified.
JP_FORUM_DEFAULT_ON = False

ENABLE_EXPECTATIONS = True   # US analyst-expectation measurement; set False to skip


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_expectations(ticker: str) -> dict:
    """Analyst-expectation scores for one US ticker, cached a day (estimates move
    slowly). The four estimate views share a SINGLE earnings-trend fetch cached on
    the Ticker object; earnings history is a second request. Two per name per day.

    Raises on a network failure so st.cache_data does not freeze the failure for 24h;
    a name with genuinely no analyst coverage returns a valid all-NaN result instead.
    """
    tk = _ticker(ticker)
    frames = {}
    for key, meth in (("eps_revisions", "get_eps_revisions"), ("eps_trend", "get_eps_trend"),
                      ("earnings_estimate", "get_earnings_estimate"),
                      ("revenue_estimate", "get_revenue_estimate"),
                      # separate request (earningsHistory module) — the one extra call
                      ("earnings_history", "get_earnings_history")):
        fn = getattr(tk, meth, None)
        if fn is None:
            continue                      # older yfinance: that view is unavailable
        frames[key] = fn()
    out = expectations_from_frames(**frames)
    # retrieval time, set inside the cached function so a cache hit keeps the
    # ORIGINAL time; the provider gives no as-of date for these estimates
    out["fetched_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    out["provider_asof"] = None
    return out


def attach_expectations(results: list[dict]) -> int:
    """MEASUREMENT ONLY: record analyst expectations next to US results.

    Nothing here changes a composite, a call or a weight. The scores flow into the
    Model Lab's factor table as candidates, so whether expectations actually forecast
    excess returns is decided on evidence before they get any production weight.
    """
    if not ENABLE_EXPECTATIONS or not results:
        return 0
    n = 0
    for r in results:
        t = str(r.get("ticker") or "")
        if not t or "." in t or t.startswith("^"):
            continue                      # US listings only: coverage elsewhere is thin
        try:
            r["expectations"] = fetch_expectations(t)
            n += 1
        except Exception as e:
            logger.warning("expectations unavailable for %s: %s", t, e)
    return n


# ---------------------------------------------------------------------------
# Stocktwits — approved API only, MEASUREMENT ONLY
# ---------------------------------------------------------------------------
ENABLE_STOCKTWITS = True            # still makes NO request unless credentials exist
STOCKTWITS_WINDOW = "24h"           # exact window; never silently substituted
STOCKTWITS_MAX_REQUESTS_PER_SCAN = 60
STOCKTWITS_CIRCUIT_MINUTES = 30     # proposed policy, not a provider entitlement
# Hyphenated US share classes are mapped EXPLICITLY; no general rewrite rule.
STOCKTWITS_SYMBOL_MAP = {"BRK-B": "BRK.B", "BF-B": "BF.B"}
_ST_TRANSIENT = {"network_error", "rate_limited", "unauthorized", "forbidden", "http_error"}


def stocktwits_symbol(ticker: str) -> str | None:
    """Stocktwits symbol for a US LISTING, else None.

    Routing is by listing identity, not company region: an unsuffixed ticker is a US
    listing — for an ADR such as BABA that is the ADR's OWN sentiment, which is
    accurate. A local foreign listing (SHEL.L, 7203.T) is never mapped to its ADR:
    that would attach another instrument's crowd to it. Hyphenated share classes
    only through STOCKTWITS_SYMBOL_MAP."""
    t = str(ticker or "").strip().upper()
    if t in STOCKTWITS_SYMBOL_MAP:
        return STOCKTWITS_SYMBOL_MAP[t]
    if not t or t.startswith("^") or "." in t or "-" in t or "=" in t:
        return None
    return t


def _stocktwits_credentials() -> tuple[str | None, str | None]:
    """Approved-API credentials from Streamlit secrets or the environment only —
    never config.py, source control, logs or exports."""
    return (_get_secret("STOCKTWITS_API_USERNAME"), _get_secret("STOCKTWITS_API_PASSWORD"))


class _StocktwitsTransient(Exception):
    """Carries a transient-failure record out of the cached function uncached."""
    def __init__(self, record: dict):
        super().__init__(record.get("status"))
        self.record = record


@st.cache_data(ttl=1800, show_spinner=False)
def _fetch_stocktwits_cached(symbol: str, window: str, _user: str, _password: str) -> dict:
    """30-minute cache (proposed policy). Credentials are underscore-prefixed so
    Streamlit never hashes them into the cache key. A transient failure RAISES, so it
    is never cached as if it were data; a cache hit keeps the ORIGINAL fetched_at."""
    rec = _ss.fetch_stocktwits_approved(symbol, _user, _password, window=window)
    if rec.get("status") in _ST_TRANSIENT:
        raise _StocktwitsTransient(rec)
    return rec


def _stocktwits_circuit_open() -> bool:
    c = st.session_state.get("_stocktwits_circuit")
    if not c:
        return False
    try:
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(c["at"])).total_seconds()
    except Exception:
        return False
    return age < STOCKTWITS_CIRCUIT_MINUTES * 60


def fetch_stocktwits(symbol: str) -> dict:
    """One Stocktwits record. No credentials -> no request. 401/403/429 open a circuit
    breaker for STOCKTWITS_CIRCUIT_MINUTES so a bad key or rate limit is not hammered."""
    base = {"source": "stocktwits", "symbol": symbol, "window": STOCKTWITS_WINDOW,
            "metric_type": "provider_normalized_sentiment", "score": None, "label": None,
            "message_volume_score": None, "buy_pct": None, "sell_pct": None,
            "provider_asof": None, "fetched_at": None,
            "parser_version": getattr(_ss, "STOCKTWITS_PARSER_VERSION", None)}
    if _ss is None:
        return dict(base, status="unavailable", reason="sentiment_sources_module_missing")
    user, pw = _stocktwits_credentials()
    if not user or not pw:
        return dict(base, status="not_configured")
    if _stocktwits_circuit_open():
        return dict(base, status="circuit_open",
                    reason=st.session_state["_stocktwits_circuit"].get("status"))
    try:
        return _fetch_stocktwits_cached(symbol, STOCKTWITS_WINDOW, user, pw)
    except _StocktwitsTransient as t:
        rec = t.record
        if rec.get("status") in ("unauthorized", "forbidden", "rate_limited"):
            st.session_state["_stocktwits_circuit"] = {
                "status": rec["status"],
                "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        return rec
    except Exception as e:
        logger.warning("stocktwits fetch failed for %s: %s", symbol, type(e).__name__)
        return dict(base, status="network_error")


def attach_retail_sentiment(results: list[dict]) -> int:
    """MEASUREMENT ONLY: attach Stocktwits records to US-listed results.

    Never touches the composite, the call, the factor weights or Early Setup's
    revisions input. A normalised score of 34 is not 34% buy and is stored exactly as
    the provider supplied it. Bounded per scan; requests only with credentials."""
    if not ENABLE_STOCKTWITS or not results:
        return 0
    budget, n = STOCKTWITS_MAX_REQUESTS_PER_SCAN, 0
    for r in results:
        sym = stocktwits_symbol(r.get("ticker", ""))
        if sym is None:
            continue
        if budget <= 0:
            r["stocktwits"] = {"source": "stocktwits", "symbol": sym,
                               "status": "budget_exhausted", "score": None}
            continue
        rec = fetch_stocktwits(sym)
        if rec.get("status") not in ("not_configured", "circuit_open"):
            budget -= 1
        r["stocktwits"] = rec
        n += 1
    return n


def attach_candidate_signals(results: list[dict], histories: dict | None = None) -> int:
    """Record alternative signals next to the production factors (measurement only).

    Nothing here changes a score, a call or a weight. It exists so the Model Lab can
    compare, on your own data, whether e.g. long-horizon momentum forecasts better
    than the 1-month return the production momentum factor currently uses — evidence
    to base a later model change on, instead of changing the model on theory.
    """
    if not results:
        return 0
    histories = histories or {}
    benches = sorted({b for b in (benchmark_for(r["ticker"]) for r in results
                                if r.get("ticker")) if b})
    try:
        bhist = get_histories(benches, period="1y")   # cached: same call early setup makes
    except Exception as e:
        logger.warning("benchmark history for candidate signals unavailable: %s", e)
        bhist = {}
    n = 0
    for r in results:
        hist = histories.get(r.get("ticker"))
        if hist is None:
            hist = r.get("history")
        if hist is None or getattr(hist, "empty", True) or "Close" not in hist.columns:
            continue
        bh = bhist.get(benchmark_for(r["ticker"]))
        try:
            cands = candidate_signals(
                hist["Close"], bh["Close"] if bh is not None and "Close" in bh.columns else None)
            exp = r.get("expectations") or {}
            for k in ("expectations_score", "eps_revision_score", "eps_trend_score",
                      "forward_growth_score", "earnings_surprise_score"):
                if k in exp:
                    cands[k] = exp[k]
            stw = r.get("stocktwits") or {}
            if stw.get("status") == "ok" and stw.get("score") is not None:
                # missing data is ABSENT from candidates, never a neutral 50
                cands["stocktwits_score"] = float(stw["score"])
                if stw.get("message_volume_score") is not None:
                    cands["stocktwits_attention"] = float(stw["message_volume_score"])
            r["candidates"] = cands
            n += 1
        except Exception as e:
            logger.warning("candidate signals failed for %s: %s", r.get("ticker"), e)
    return n


def _run_post_scan_tasks(results: list[dict], scan_histories: dict,
                         scan_type: str = "unknown") -> None:
    """Three unrelated post-scan jobs, independently guarded.

    Ordering is load-bearing: attach_early_setups() must precede
    record_observations(), because the ledger persists setup_score, setup_state
    and setup_components. A failure in any one must not suppress the others —
    they previously shared a single try/except, so a mock-portfolio error also
    cost that day's observation rows.
    """
    try:
        save_mock_portfolio(results)
    except Exception as e:
        logger.warning("mock portfolio save failed: %s", e)
    try:
        attach_expectations(results)          # before setups & candidates: both read it
    except Exception as e:
        logger.warning("expectations attachment failed: %s", e)
    try:
        attach_retail_sentiment(results)      # Stocktwits: context/candidate only
    except Exception as e:
        logger.warning("retail sentiment attachment failed: %s", e)
    try:
        attach_early_setups(results, histories=scan_histories)
    except Exception as e:
        logger.warning("early setup attachment failed: %s", e)
    try:
        attach_candidate_signals(results, histories=scan_histories)
    except Exception as e:
        logger.warning("candidate signal attachment failed: %s", e)
    try:
        record_observations(results, scan_type=scan_type)
    except Exception as e:
        logger.warning("observation recording failed: %s", e)


def run_engine(limit_per_region: int | None = None,
               regions: list | None = None,
               sources: list | None = None,
               use_jp_forum: bool = JP_FORUM_DEFAULT_ON) -> tuple[list[dict], list[str]]:
    weights = get_latest_weights()
    results, failed = [], []

    # Only scan the regions the user selected (defaults to all). On a quick scan,
    # also cap to the first N tickers per region — fewer requests means a faster
    # run and a much lower chance of Yahoo rate-limiting the server's IP.
    # Promoted deep-scan names (PROMOTION_QUOTA per market) ride along AFTER the cap,
    # so even a quick scan always covers the current promotion layer.
    selected = regions if regions else list(TICKER_UNIVERSE.keys())
    promoted_map = get_promoted_universe()
    promoted_set = {t for ticks in promoted_map.values() for t in ticks}
    universe = {}
    for region, ticks in TICKER_UNIVERSE.items():
        if region not in selected:
            continue
        base = ticks[:limit_per_region] if limit_per_region else list(ticks)
        extra = [t for t in promoted_map.get(region, []) if t not in base]
        universe[region] = base + extra

    # Pull sentiment buzz ONCE for the whole scan, routing each market to the
    # enabled sources (Reddit for English names, GDELT news for JP/CN, etc.), then
    # feed each ticker its own combined count. Fully fail-safe: a blocked source
    # contributes zeros, so the scan proceeds with hype unaffected.
    hype_counts = fetch_hype_signals(universe, sources)

    # ONE bulk price download for the whole scan (the deep scan already worked this
    # way; the main scan previously paid a per-ticker fetch with retry/backoff plus
    # a fixed 0.4s sleep per name — most of a quick scan's wall clock). Anything the
    # bulk request misses (delisted, exchange quirk) transparently falls back to the
    # per-ticker path inside analyze_ticker. Fundamentals (.info) remain per-ticker —
    # Yahoo has no bulk endpoint for those — pacing lives inside the cached fetchers.
    # period="1y" (was 8mo) deliberately matches the deep scan / sell scanner /
    # walk-forward period, so get_histories serves ALL of them from one download;
    # analyze_ticker only reads tail slices, so the longer frame changes nothing.
    all_symbols = [t for ticks in universe.values() for t in ticks]
    # Benchmarks ride in the same single download (a handful of index symbols), so
    # relative momentum costs no extra request.
    _benches = sorted({b for b in (benchmark_for(t) for t in all_symbols) if b})
    bulk = get_histories(all_symbols + [b for b in _benches if b not in all_symbols],
                         period="1y")
    # Scan-local map of the FULL OHLCV frames actually used. Seeded from the bulk
    # download and extended below with any per-ticker recovery, so Early Setup sees
    # volume for recovered names too. Deliberately local: never persisted, never put
    # in session_state — result["history"] stays Close-only for the memory reason
    # documented in analyze_ticker.
    scan_histories: dict = dict(bulk)

    progress = st.progress(0.0, text=tr("scanning"))

    total_symbols = sum(len(ticks) for ticks in universe.values())
    current_index = 0

    analyses: list[dict] = []
    for region, tickers in universe.items():
        for t in tickers:
            try:
                # Full board record kept for persistence/display; the (buy, sell)
                # tuple feeds the unchanged scoring formula only when status == ok.
                jp_detail = (fetch_jp_forum_detail(t)
                             if (use_jp_forum and region == "Japan") else None)
                jp_rating = _jp_poll_tuple(jp_detail) if jp_detail else None
                # A bulk miss is recovered here rather than inside analyze_ticker, so
                # the recovered frame lands in scan_histories with its Volume intact.
                # fetch_history is @st.cache_data, so this is the same single call
                # analyze_ticker would otherwise make — not an extra download.
                frame = bulk.get(t)
                if frame is None or getattr(frame, "empty", False):
                    try:
                        # period must match the bulk call: a recovered ticker
                        # otherwise gets a shorter frame than a bulked one, which
                        # changes the 252-session 52w-high window in early_setup.
                        frame = fetch_history(t, period="1y")
                    except Exception as e:
                        logger.warning("history recovery failed for %s: %s", t, e)
                        frame = None
                if frame is not None:
                    scan_histories[t] = frame
                _bf = bulk.get(benchmark_for(t))
                analysis = analyze_ticker(t, region, hype_counts.get(t, 0),
                                          jp_forum=jp_rating, hist=frame,
                                          bench_close=(_bf["Close"] if _bf is not None
                                                       and "Close" in _bf.columns else None))
                if analysis is None:
                    failed.append(f"{t} (no data)")
                else:
                    if jp_detail is not None:
                        analysis["jp_board"] = jp_detail
                    analysis["jp_forum_enabled"] = bool(use_jp_forum and region == "Japan")
                    analysis["promoted"] = t in promoted_set
                    if analysis["promoted"]:
                        # Star the display name so promoted ride-alongs are
                        # recognisable in every tab without new columns.
                        analysis["name"] = f"⭐ {analysis.get('name') or t}"
                    analyses.append(analysis)
            except Exception as e:
                # Surface the real reason instead of silently swallowing it.
                failed.append(f"{t} ({type(e).__name__})")
            current_index += 1
            # Pacing now lives INSIDE the cached fetchers (fetch_fundamentals /
            # fetch_history), so it only fires on actual network calls — a repeat
            # scan within the TTL runs at full speed instead of sleeping per name.
            progress.progress(current_index / total_symbols, text=tr("processing", ticker=t, region=region_name(region)))
    progress.empty()

    # ---- Theme (industry-rotation) KPI: cross-sectional second pass ----
    # A ticker's theme score is the damped average MOMENTUM of the *other* scanned
    # members of its basket (theme_strength_score in indicators.py), so it must be
    # computed after every name has been analysed. Uses the sector/industry strings
    # stage-2 fundamentals fetched anyway — zero extra API calls. Themeless names
    # keep the neutral 50 set by analyze_ticker.
    theme_members: dict[str, list[dict]] = {}
    for a in analyses:
        a["theme_match"] = match_theme(a["region"], a.get("sector"), a.get("industry"))
        if a["theme_match"]:
            theme_members.setdefault(a["theme_match"], []).append(a)
    for a in analyses:
        peers = [p["momentum"] for p in theme_members.get(a.get("theme_match"), []) if p is not a]
        a["theme"] = theme_strength_score(peers)
        a.update(score_with_weights(a, weights))
        # the EXACT weights behind this composite, for persistence and display
        a["weights_snapshot"] = dict(weights)
        a["production_model_version"] = PRODUCTION_MODEL_VERSION
        save_recommendation(a)
        results.append(a)

    results.sort(key=lambda r: r["composite"], reverse=True)
    # Log today's curated Top-3 Growth / Top-3 Dividend picks for the walk-forward
    # loop, persist the scan snapshot (survives refresh/new session), and stamp the
    # scan time for the freshness chip. All wrapped/fail-safe so bookkeeping can
    # never sink an otherwise-successful scan.
    _run_post_scan_tasks(results, scan_histories,
                         scan_type="quick" if limit_per_region else "full")
    save_scan_snapshot(results, is_quick=limit_per_region is not None)
    st.session_state["scan_ts"] = time.time()
    st.session_state["restored_scan"] = False
    return results, failed

# ----------------------------------------------------------------------------
# Layout Tab Renderers
# ----------------------------------------------------------------------------
def render_daily_top_3(results: list[dict]) -> None:
    st.subheader(tr("top3_header"))
    if not results:
        st.info(tr("need_scan_sidebar"))
        return
    # One read for the whole page: the previous scan's composite per name, so every
    # card and the movers table can say what CHANGED — a score of 72 means more
    # when you know it was 61 last time.
    prev = previous_composites([r["ticker"] for r in results if r.get("ticker")],
                               asof={r["ticker"]: r.get("price_date")
                                     for r in results if r.get("ticker")})
    top_3 = results[:3]
    c1, c2, c3 = st.columns(3)
    for i, col in enumerate([c1, c2, c3]):
        if i < len(top_3):
            r = top_3[i]
            comp = safe_float(r.get("composite"))
            p = prev.get(r["ticker"])
            if p and not math.isnan(p[0]) and not math.isnan(comp):
                delta = f"{comp - p[0]:+.1f} {tr('delta_vs_last')}"
                positive = comp >= p[0]
            else:
                delta = f"{tr('price_label')}: {fmt_money(r['price'])}"
                positive = comp >= BUY_THRESHOLD
            col.markdown(metric_card(f"{r['ticker']} · {region_name(r['region'])}",
                                     f"{comp:.1f}/100 {tr('score_suffix')}",
                                     delta, positive=positive), unsafe_allow_html=True)
            div_txt = f"{r['div_yield']:.2f}%" if not math.isnan(r['div_yield']) else "—"
            col.markdown(
                f"**{tr('company_profile')}:** {r['name']} <br>"
                f"**{tr('price_label')}:** {fmt_money(r['price'])} <br>"
                f"**{tr('trend_return_1m')}:** {fmt_pct(r['ret_1m'])} <br>"
                f"**{tr('pe_ratio')}:** {fmt_num(r['pe'], 1)} &nbsp;·&nbsp; **{tr('dividend_yield')}:** {div_txt}",
                unsafe_allow_html=True,
            )

    # --- What changed since the last scan ----------------------------------
    moves = []
    for r in results:
        p = prev.get(r.get("ticker"))
        comp = safe_float(r.get("composite"))
        if p and not math.isnan(p[0]) and not math.isnan(comp):
            moves.append({"r": r, "delta": comp - p[0], "was": p[0], "since": p[1],
                          "call_changed": False})
    if not moves:
        st.caption(tr("movers_none"))
        return
    st.markdown(f"#### {tr('movers_header')}")
    st.caption(tr("movers_intro", since=max(m["since"] for m in moves)))
    moves.sort(key=lambda m: m["delta"], reverse=True)
    risers = [m for m in moves if m["delta"] > 0][:5]
    fallers = [m for m in reversed(moves) if m["delta"] < 0][:5]

    def _table(items):
        return pd.DataFrame([{
            tr("col_ticker"): m["r"]["ticker"],
            tr("col_company"): m["r"].get("name", m["r"]["ticker"]),
            tr("col_region"): region_name(m["r"].get("region", "")),
            tr("movers_col_was"): m["was"],
            tr("col_overall_score"): safe_float(m["r"].get("composite")),
            tr("movers_col_change"): m["delta"],
            tr("why_call"): str(m["r"].get("recommendation", "—")),
        } for m in items])
    fmt = {tr("movers_col_was"): "{:.1f}", tr("col_overall_score"): "{:.1f}",
           tr("movers_col_change"): "{:+.1f}"}
    mc1, mc2 = st.columns(2)
    with mc1:
        st.markdown(f"**{tr('movers_up')}**")
        if risers:
            st.dataframe(_table(risers).style.format(fmt, na_rep="—"),
                         width="stretch", hide_index=True)
        else:
            st.caption("—")
    with mc2:
        st.markdown(f"**{tr('movers_down')}**")
        if fallers:
            st.dataframe(_table(fallers).style.format(fmt, na_rep="—"),
                         width="stretch", hide_index=True)
        else:
            st.caption("—")
    st.caption(tr("movers_note"))


# --- US Conviction tab (US-only; SEC EDGAR fundamentals) -------------------------
# Deliberately isolated: it blends each US name's existing scan composite with SEC
# growth/quality OUTSIDE the global factor model, so this US-only data never enters
# FACTORS, DEFAULT_WEIGHTS, or the walk-forward gradient.
US_CONVICTION_WEIGHTS = {"composite": 0.5, "growth": 0.3, "quality": 0.2}

@st.cache_data(ttl=86400, show_spinner=False)
def _sec_fundamentals_cached(ticker: str) -> dict:
    """SEC fundamentals for one US ticker, cached a day (filings are quarterly). Raises
    on a transient fetch failure so the broken state isn't frozen for the whole TTL."""
    ua = _get_secret("SEC_USER_AGENT", "stockrec-research/1.0 (set SEC_USER_AGENT to your email)")
    return sec_research.sec_fundamentals(ticker, ua=ua)

# 13F superinvestor conviction layer (Phase 2): each manager that NEWLY BOUGHT the name
# this quarter (added it quarter-over-quarter) adds a few
# points, capped — so this quarterly, ~45-day-lagged signal tilts the ranking rather than
# dominating the SEC-fundamentals core.
SUPERINVESTOR_PT = 4.0
SUPERINVESTOR_CAP = 3

@st.cache_data(ttl=86400, show_spinner=False)
def _superinvestor_counts_cached(tickers: tuple) -> dict:
    """How many tracked superinvestors hold each US ticker (latest 13F-HR), cached a day.
    Raises on a total outage so an all-zero result isn't frozen for the whole TTL."""
    ua = _get_secret("SEC_USER_AGENT", "stockrec-research/1.0 (set SEC_USER_AGENT to your email)")
    return sec_research.superinvestor_counts(list(tickers), ua=ua)

def _blend_conviction(comp: float, growth: float, quality: float) -> float:
    """Weighted, NaN-aware blend. If SEC scores are missing, it renormalises onto the
    scan composite alone, so a name still ranks (just without the SEC tilt)."""
    num = den = 0.0
    for key, val in (("composite", comp), ("growth", growth), ("quality", quality)):
        if val is not None and not math.isnan(val):
            num += US_CONVICTION_WEIGHTS[key] * val
            den += US_CONVICTION_WEIGHTS[key]
    return num / den if den > 0 else float("nan")

def render_us_conviction(results: list[dict]) -> None:
    st.subheader(tr("us_header"))
    if sec_research is None:
        st.warning(tr("us_module_missing"))
        return
    us = [r for r in results if r.get("region") == "USA"]
    if not us:
        st.info(tr("need_scan_sidebar"))
        return

    us_tickers = sorted({r["ticker"] for r in us})
    rows = []
    with st.spinner(tr("us_spinner")):
        try:
            sci = _superinvestor_counts_cached(tuple(us_tickers))
        except Exception:
            sci = {}   # 13F unavailable this run -> no conviction bonus, no crash
        for r in us:
            comp = safe_float(r.get("composite"), float("nan"))
            g = q = rev_cagr = rev_yoy = eps_yoy = float("nan")
            try:
                f = _sec_fundamentals_cached(r["ticker"])
                g, q = f["growth_score"], f["quality_score"]
                rev_cagr, rev_yoy, eps_yoy = f["rev_cagr_3y"], f["rev_yoy"], f["earnings_yoy"]
            except Exception:
                pass   # SEC unavailable for this name -> rank on the composite alone
            base = _blend_conviction(comp, g, q)
            n_si = int(sci.get(r["ticker"], 0) or 0)
            conv = base if math.isnan(base) else clamp(base + SUPERINVESTOR_PT * min(n_si, SUPERINVESTOR_CAP))
            rows.append({
                "ticker": r["ticker"], "name": r.get("name", r["ticker"]),
                "conviction": conv, "composite": comp, "n_si": n_si,
                "growth": g, "quality": q, "rev_cagr": rev_cagr, "eps_yoy": eps_yoy,
                "price": safe_float(r.get("price"), float("nan")),
            })
    rows.sort(key=lambda x: x["conviction"] if not math.isnan(x["conviction"]) else float("-inf"),
              reverse=True)

    c1, c2, c3 = st.columns(3)
    for i, col in enumerate([c1, c2, c3]):
        if i < len(rows):
            x = rows[i]
            conv = "—" if math.isnan(x["conviction"]) else f"{x['conviction']:.1f}/100"
            cagr = "—" if math.isnan(x["rev_cagr"]) else fmt_pct(x["rev_cagr"] * 100.0)
            si = f"<br>⭐ {tr('us_held_by', n=x['n_si'])}" if x["n_si"] > 0 else ""
            col.markdown(metric_card(x["ticker"], f"{conv} {tr('us_conviction_suffix')}",
                                     f"{tr('price_label')}: {fmt_money(x['price'])}",
                                     positive=(not math.isnan(x["conviction"]) and x["conviction"] >= BUY_THRESHOLD)),
                         unsafe_allow_html=True)
            col.markdown(
                f"**{tr('company_profile')}:** {x['name']} <br>"
                f"**{tr('col_sec_growth')}:** {fmt_num(x['growth'], 0)} &nbsp;·&nbsp; "
                f"**{tr('col_sec_quality')}:** {fmt_num(x['quality'], 0)} <br>"
                f"**{tr('col_rev_cagr')}:** {cagr}{si}",
                unsafe_allow_html=True,
            )

    def _r(v, nd=1):
        return float("nan") if math.isnan(v) else round(v, nd)
    table = pd.DataFrame([{
        tr("col_ticker"): x["ticker"], tr("col_company"): x["name"],
        tr("col_us_conviction"): _r(x["conviction"]), tr("col_overall_score"): _r(x["composite"]),
        tr("col_sec_growth"): _r(x["growth"], 0), tr("col_sec_quality"): _r(x["quality"], 0),
        tr("col_rev_cagr"): _r(x["rev_cagr"] * 100.0), tr("col_eps_yoy"): _r(x["eps_yoy"] * 100.0),
        tr("col_superinvestors"): x["n_si"],
    } for x in rows])
    st.dataframe(table, width="stretch", hide_index=True)
    st.caption(tr("us_caption"))

def render_category_views(results: list[dict]) -> None:
    if not results:
        st.info(tr("need_run_engine"))
        return

    v1, v2 = st.tabs([tr("subtab_growth"), tr("subtab_dividend")])
    df = pd.DataFrame(results)

    with v1:
        st.markdown(f"### {tr('growth_header_text')}")
        growth_df = df.sort_values(by="ret_1m", ascending=False).head(5).copy()
        growth_df["region"] = growth_df["region"].map(region_name)
        st.dataframe(growth_df[["ticker", "name", "region", "price", "ret_1m", "composite"]].rename(columns={"ticker": tr("col_ticker"), "name": tr("col_company"), "region": tr("col_region"), "price": tr("col_price"), "ret_1m": tr("col_momentum_1m"), "composite": tr("col_overall_score")}), width="stretch", hide_index=True)

    with v2:
        st.markdown(f"### {tr('dividend_header_text')}")
        div_df = df[df["div_yield"] >= 1.5].sort_values(by="composite", ascending=False).head(5).copy()
        if not div_df.empty:
            div_df["region"] = div_df["region"].map(region_name)
            # Coverage column: yield alone can't distinguish a healthy payer from a
            # yield trap (payout > earnings), so show what fraction of earnings the
            # dividend consumes, flagged above 100%. NaN -> "—" (field is flaky).
            div_df["payout_disp"] = (div_df["payout"].map(_payout_disp)
                                     if "payout" in div_df.columns else "—")
            st.dataframe(div_df[["ticker", "name", "region", "price", "div_yield", "payout_disp", "composite"]].rename(columns={"ticker": tr("col_ticker"), "name": tr("col_company"), "region": tr("col_region"), "price": tr("col_price"), "div_yield": tr("col_dividend_return"), "payout_disp": tr("col_payout"), "composite": tr("col_overall_score")}), width="stretch", hide_index=True)
            st.caption(tr("payout_note"))
        else:
            st.info(tr("no_dividend_match"))

def render_global_sectors(results: list[dict]) -> None:
    if not results:
        st.info(tr("need_activate"))
        return
    region_keys = list(TICKER_UNIVERSE.keys())
    target_region = st.selectbox(tr("select_region"), region_keys, format_func=region_name)
    regional_filtered = [r for r in results if r["region"] == target_region]

    # One sortable, selectable table instead of a card row per ticker (38 US names
    # made a very long scroll with no sorting). ProgressColumn gives an instant
    # visual ranking; clicking a row opens a detail card below AND preselects the
    # name in the Deep-Dive tab (row order == regional_filtered order, so the
    # selection index maps straight back to the analysis dict).
    df = pd.DataFrame([{
        "ticker": r["ticker"],
        "name": str(r.get("name", r["ticker"])),
        "call": tr(f"rec_{r['recommendation']}") if r.get("recommendation") in ("BUY", "HOLD", "SELL")
                else str(r.get("recommendation", "—")),
        "composite": safe_float(r.get("composite")),
        "price": safe_float(r.get("price")),
        "hype": safe_float(r.get("hype_score")),
        "ret1m": safe_float(r.get("ret_1m")),
    } for r in regional_filtered])
    event = st.dataframe(
        df,
        column_config={
            "ticker": st.column_config.TextColumn(tr("col_ticker"), width="small"),
            "name": st.column_config.TextColumn(tr("col_company")),
            "call": st.column_config.TextColumn(tr("why_call"), width="small"),
            "composite": st.column_config.ProgressColumn(
                tr("card_system_rating"), min_value=0, max_value=100, format="%.1f"),
            "price": st.column_config.NumberColumn(tr("card_trading_close"), format="%.2f"),
            "hype": st.column_config.ProgressColumn(
                tr("card_sustained_hype"), min_value=0, max_value=100, format="%.0f"),
            "ret1m": st.column_config.NumberColumn(tr("evi_ret_1m"), format="%+.1f%%"),
        },
        hide_index=True, width="stretch",
        on_select="rerun", selection_mode="single-row",
        key=f"regional_table_{target_region}",
    )
    sel_rows = []
    try:
        sel_rows = list(event.selection.rows)   # DataframeState from on_select
    except Exception:
        sel_rows = []
    if not sel_rows:
        st.caption(tr("row_select_prompt"))
        return

    r = regional_filtered[sel_rows[0]]
    # Hand the pick to the Deep-Dive tab: its selectbox is keyed "deep_dive_pick",
    # and this tab renders BEFORE it in the same rerun, so the state lands in time.
    st.session_state["deep_dive_pick"] = r["ticker"]

    cols = st.columns([2, 1, 1, 1])
    cols[0].markdown(
        f'<div class="qc-card"><span class="qc-ticker">{r["ticker"]}</span> '
        f'{rec_pill(r["recommendation"])}<br><span class="qc-sub">{r["name"]}</span></div>',
        unsafe_allow_html=True)
    cols[1].markdown(metric_card(tr("card_system_rating"), f"{r['composite']:.1f}"), unsafe_allow_html=True)
    cols[2].markdown(metric_card(tr("card_trading_close"), fmt_money(r["price"])), unsafe_allow_html=True)
    cols[3].markdown(metric_card(tr("card_sustained_hype"), f"{r['hype_score']:.0f}",
                     tr("breakout") if r["hype"]["sustained"] else tr("flat"),
                     positive=r["hype"]["sustained"]), unsafe_allow_html=True)
    # Real navigation, not just preselection: the Deep-Dive page is registered in
    # _PAGES by _build_navigation (runs before any page renders). The pick was
    # already stored under the Deep-Dive selectbox's key above, so the landing
    # page opens straight on this name. Fallback caption if navigation isn't up
    # (e.g. bare-mode tests).
    if st.button(tr("open_deep_dive_btn", ticker=r["ticker"]), type="primary",
                 key=f"open_dd_{target_region}"):
        page = _PAGES.get("deep_dive")
        if page is not None:
            st.switch_page(page)
    st.caption(tr("row_selected_hint", ticker=r["ticker"]))

def _ago(epoch: float) -> str:
    """Compact 'time since' label, e.g. '<1m', '12m', '2h 5m', '3d 4h'. Unit suffixes
    only, so the surrounding 'updated … ago' phrasing handles localization."""
    mins = max(0, int(time.time() - epoch)) // 60
    if mins < 1:
        return "<1m"
    if mins < 60:
        return f"{mins}m"
    if mins < 60 * 48:
        return f"{mins // 60}h {mins % 60}m"
    return f"{mins // 1440}d {(mins % 1440) // 60}h"   # restored snapshots can be days old


def _pick_breakdown(r: dict, weights: dict) -> pd.DataFrame:
    """Per-factor score, weight and weighted contribution to the composite.
    contribution = weight * factor_score, and the contributions sum to the composite —
    so this is an exact decomposition of *why* the name scored what it did."""
    rows = []
    for f in FACTORS:
        score = safe_float(r.get("hype_score" if f == "hype" else f), float("nan"))
        w = float(weights.get(f, 0.0))
        rows.append({"factor": f, "score": score, "weight": w, "contribution": w * score})
    return pd.DataFrame(rows)


def _rel3m_disp(r: dict) -> str:
    """3-month return vs benchmark, or an explicit reason when it couldn't be measured."""
    v = safe_float(r.get("rel_ret_3m"))
    if math.isnan(v):
        return tr("evi_rel_3m_na")
    return f"{v:+.1f}%"


def _payout_disp(p: float) -> str:
    """Payout ratio display: '65%', '112% ⚠' above 100%, '—' when unknown."""
    if math.isnan(p) or p <= 0:
        return "—"
    return f"{p * 100:.0f}%" + (" ⚠" if p > 1.0 else "")


def _evidence_rows(r: dict) -> list:
    """The actual KPI numbers behind each factor, as (factor, metric, value) rows."""
    fm, fv, ft, fh, fq = (tr("factor_momentum"), tr("factor_value"), tr("factor_technical"),
                          tr("factor_hype"), tr("factor_quality"))
    fth = tr("factor_theme")
    def _f(x): return safe_float(x, float("nan"))
    price, sma50 = _f(r.get("price")), _f(r.get("sma50"))
    vs50 = "—" if (math.isnan(price) or math.isnan(sma50) or sma50 == 0) else f"{(price / sma50 - 1) * 100:+.1f}%"
    macd = _f(r.get("macd_hist"))
    macd_s = "—" if math.isnan(macd) else (tr("evi_bullish") if macd > 0 else tr("evi_bearish"))
    pe, div, rsi, bbp = _f(r.get("pe")), _f(r.get("div_yield")), _f(r.get("rsi")), _f(r.get("bb_pct"))
    roe, shortp = _f(r.get("roe")), _f(r.get("short_pct"))
    ret1m = _f(r.get("ret_1m"))
    jp_bull, jp_bear = _f(r.get("jp_bull")), _f(r.get("jp_bear"))
    rows = [
        # The market-relative return is what now drives momentum, so it leads; the raw
        # 1-month return stays as context but no longer feeds the factor.
        (fm, tr("evi_rel_3m"),   _rel3m_disp(r)),
        (fm, tr("evi_vs_sma50"), vs50),
        (fm, tr("evi_macd"),     macd_s),
        (fm, tr("evi_ret_1m_ctx"), "—" if math.isnan(ret1m) else f"{ret1m:+.1f}%"),
        (fv, tr("evi_pe"),       "—" if (math.isnan(pe) or pe <= 0) else f"{pe:,.1f}"),
        (fv, tr("evi_div"),      "—" if math.isnan(div) else f"{div:.2f}%"),       # div_yield already in %
        (fv, tr("evi_payout"),   _payout_disp(_f(r.get("payout")))),
        (ft, tr("evi_rsi"),      "—" if math.isnan(rsi) else f"{rsi:.0f}"),
        (ft, tr("evi_bbpct"),    "—" if math.isnan(bbp) else f"{bbp:.2f}"),
        (fq, tr("evi_roe"),      "—" if math.isnan(roe) else f"{roe * 100:.1f}%"),  # roe is a fraction
        (fh, tr("evi_mentions"), f"{safe_float(r.get('hype_mentions'), 0):g}"),
        (fh, tr("evi_short"),    "—" if math.isnan(shortp) else f"{shortp * 100:.1f}%"),  # fraction of float
        (fth, tr("evi_theme_basket"), str(r.get("theme_match") or "—")),
        (fth, tr("evi_theme_peers"),  fmt_num(safe_float(r.get("theme"), float("nan")), 0)),
    ]
    # Yahoo!掲示板 みんなの評価 — shown only for names where a poll was actually
    # fetched (Japanese tickers with the toggle on), so the row's presence is itself
    # the "is the forum signal live?" confirmation Gemini wanted for the live test.
    if not (math.isnan(jp_bull) or math.isnan(jp_bear)):
        rows.append((fh, tr("evi_jp_forum"), tr("evi_jp_forum_val").format(
            bull=f"{jp_bull:.0f}", bear=f"{jp_bear:.0f}")))
    return rows


def _screen_rank(histories: dict, n: int) -> list:
    """Stage-1 price screen: rank tickers by the multi-factor screen score from
    indicators.screen_metrics (momentum blend + volume surge + 52w-high proximity,
    with a falling-knife cap). Returns the top n as [(ticker, metrics_dict), ...].
    Pure function over the bulk histories — still zero extra API calls."""
    scored = []
    for t, h in histories.items():
        vol = h["Volume"] if "Volume" in h.columns else None
        m = screen_metrics(h["Close"], vol)
        if m is not None:
            scored.append((t, m))
    scored.sort(key=lambda x: x[1]["score"], reverse=True)
    return scored[:n]


def run_deep_scan(region: str) -> tuple[list, int]:
    """Deep scan funnel for one market. Stage 1: ONE bulk price download for the
    market's curated deep list MERGED with any live screener names (see
    deep_universe_for), ranked on the multi-factor screen score. Stage 2: full
    fundamental scoring on the top finalists only — Yahoo sees ~1 bulk request +
    DEEP_FINALISTS per-ticker calls. Finalists also get a theme classification
    from the sector/industry that stage 2 fetches anyway."""
    tickers, _n_live = deep_universe_for(region)
    # Park symbols that have missed repeatedly; one success elsewhere resets them.
    _parked = skipped_symbols()
    tickers = [t for t in tickers if t not in _parked]
    # 1y (~252 trading days), not 8mo: screen_metrics' 52-week-high proximity reads
    # closes.iloc[-252:], so an 8-month frame silently turned it into an 8-month
    # high — flattering names that peaked 9-12 months ago and bled since, the exact
    # profile the falling-knife cap exists to exclude. One bulk download either way.
    histories = get_histories(tickers, period="1y")
    n_screened = len(histories)
    _missing = [t for t in tickers if t not in histories]
    record_symbol_results(ok=list(histories.keys()), failed=_missing)
    st.session_state[f"deep_missing_{region}"] = _missing
    finalists = _screen_rank(histories, DEEP_FINALISTS)
    weights = get_latest_weights()
    scored: list[tuple[dict, dict]] = []
    prog = st.progress(0.0, text=tr("deep_scan_scoring"))
    for i, (t, m) in enumerate(finalists, start=1):
        try:
            # Reuse the stage-1 bulk frame — stage 2 previously re-fetched each
            # finalist's history per ticker even though it was already in memory.
            a = analyze_ticker(t, region, 0.0, hist=histories.get(t))
            if a:
                a["screen_score"] = m["score"]
                a["screen_blend"] = m["blend_pct"]
                a["screen_dhigh"] = m["dist_high_pct"]
                a["screen_vsurge"] = m["vol_surge"]
                a["theme_match"] = match_theme(region, a.get("sector"), a.get("industry"))
                scored.append((a, m))
        except Exception:
            pass   # a throttled finalist is dropped, not fatal
        prog.progress(i / max(1, len(finalists)), text=tr("deep_scan_scoring"))
    prog.empty()
    # Theme KPI across the finalist cohort (same cross-sectional logic as the main
    # scan): a finalist in a basket whose scanned peers are also strong gets a tilt.
    theme_members: dict[str, list[dict]] = {}
    for a, _m in scored:
        if a.get("theme_match"):
            theme_members.setdefault(a["theme_match"], []).append(a)
    results = []
    for a, _m in scored:
        peers = [p["momentum"] for p in theme_members.get(a.get("theme_match"), []) if p is not a]
        a["theme"] = theme_strength_score(peers)
        a.update(score_with_weights(a, weights))
        # the EXACT weights behind this composite, for persistence and display
        a["weights_snapshot"] = dict(weights)
        a["production_model_version"] = PRODUCTION_MODEL_VERSION
        results.append(a)
    results.sort(key=lambda x: safe_float(x.get("composite"), float("-inf")), reverse=True)
    return results, n_screened


def render_deep_scan() -> None:
    st.caption(tr("deep_scan_intro"))
    # Current promotion layer — visible up front, with the persistence snippet and a
    # clear button, so the state of "what rides along with the main scan" is obvious.
    promoted_now = get_promoted_universe()
    if any(promoted_now.values()):
        items = " · ".join(
            f"{region_name(r)}: {', '.join(ts)}" for r, ts in promoted_now.items() if ts)
        st.caption(tr("promoted_current", items=items))
        with st.expander(tr("promote_snippet_hint")):
            st.code(promotions_config_snippet(), language="python")
        if st.button(tr("promote_clear"), key="promote_clear_btn"):
            clear_promotions()
            st.info(tr("promote_clear_note"))
            st.rerun()
    region_labels = {tr("deep_region_us"): "USA", tr("deep_region_jp"): "Japan",
                     tr("deep_region_cn"): "China", tr("deep_region_eu"): "Europe"}
    choice = st.radio(tr("deep_region_label"), list(region_labels.keys()),
                      horizontal=True, key="deep_region")
    region = region_labels[choice]
    if region != "USA":
        st.caption(tr("deep_scan_jpcn_note"))
    if region == "Europe":
        st.caption(tr("deep_scan_gbp_note"))
    # Universe status: curated floor + live screener overlay, with freshness.
    _dyn, _dyn_ts = get_dynamic_universe(region)
    _curated_n = len(DEEP_UNIVERSES.get(region, []))
    _live_n = deep_universe_for(region)[1]
    _ago_part = ""
    if _dyn_ts:
        try:
            _ago_part = f" · {_ago(pd.Timestamp(_dyn_ts).timestamp())}"
        except Exception:
            pass
    st.caption(tr("dyn_universe_status", curated=_curated_n, dynamic=_live_n, ago=_ago_part))
    col_run, col_refresh = st.columns(2)
    if col_refresh.button(tr("dyn_refresh_btn"), key=f"dyn_refresh_{region}"):
        with st.spinner(tr("deep_scan_running")):
            syms = refresh_dynamic_universe(region)
        if syms:
            save_dynamic_universe(region, syms)
            st.success(tr("dyn_refresh_done", n=len(syms)))
            st.rerun()
        else:
            st.warning(tr("dyn_refresh_fail"))
    if col_run.button(tr("deep_scan_btn"), key="deep_scan_run"):
        with st.spinner(tr("deep_scan_running")):
            res, n = run_deep_scan(region)
        st.session_state[f"deep_results_{region}"] = res
        st.session_state[f"deep_screened_{region}"] = n
    res = st.session_state.get(f"deep_results_{region}")
    if not res:
        st.info(tr("deep_scan_hint"))
        return
    _missed = st.session_state.get(f"deep_missing_{region}") or []
    _parked = skipped_symbols()
    if _missed or _parked:
        with st.expander(tr("deep_health_header", miss=len(_missed), parked=len(_parked))):
            if _missed:
                st.caption(tr("deep_missed_note", syms=", ".join(_missed[:40])))
            if _parked:
                st.caption(tr("deep_parked_note",
                              syms=", ".join(f"{k} ({v}x)" for k, v in sorted(_parked.items()))))
                if st.button(tr("deep_unpark_btn"), key=f"unpark_{region}"):
                    clear_symbol_health()
                    st.rerun()
    st.caption(tr("deep_scan_done", screened=st.session_state.get(f"deep_screened_{region}", 0),
               total=len(deep_universe_for(region)[0]), finalists=len(res)))

    cols = st.columns(3)
    for i, item in enumerate(res[:3]):
        comp = safe_float(item.get("composite"), float("nan"))
        with cols[i]:
            st.markdown(metric_card(f"{item['ticker']} · {item.get('name', item['ticker'])}",
                        fmt_num(comp, 1), positive=(not math.isnan(comp) and comp >= BUY_THRESHOLD)),
                        unsafe_allow_html=True)
            st.markdown(rec_pill(str(item.get("recommendation", ""))), unsafe_allow_html=True)

    df = pd.DataFrame([{
        tr("col_ticker"): x["ticker"], tr("col_company"): x.get("name", x["ticker"]),
        tr("col_theme_strength"): safe_float(x.get("composite"), float("nan")),
        tr("why_call"): str(x.get("recommendation", "—")),
        tr("deep_col_score"): safe_float(x.get("screen_score"), float("nan")),
        tr("deep_col_dhigh"): safe_float(x.get("screen_dhigh"), float("nan")),
        tr("deep_col_vsurge"): safe_float(x.get("screen_vsurge"), float("nan")),
        tr("deep_col_theme"): x.get("theme_match") or "—",
        tr("pe_ratio"): safe_float(x.get("pe"), float("nan")),
    } for x in res])
    st.dataframe(df.style.format({tr("col_theme_strength"): "{:.0f}", tr("deep_col_score"): "{:.0f}",
                 tr("deep_col_dhigh"): "{:+.1f}%", tr("deep_col_vsurge"): "{:.1f}×",
                 tr("pe_ratio"): "{:,.1f}"}, na_rep="—"),
                 width="stretch", hide_index=True)
    st.caption(tr("deep_scan_note"))

    # Promote this market's best finalists (PROMOTION_QUOTA per market) into the main scan.
    # Ranked by composite; names already in the base TICKER_UNIVERSE are skipped so
    # promotion never double-scans a name. Replaces this region's previous
    # promotions — re-running deep scans naturally rotates the layer.
    quota = PROMOTION_QUOTA.get(region, 0)
    if quota and st.button(tr("promote_btn", n=quota), key=f"promote_{region}"):
        picks, skipped = [], 0
        for x in res:
            if len(picks) >= quota:
                break
            t = x["ticker"]
            if t in _BASE_UNIVERSE_SET:
                skipped += 1
                continue
            picks.append((t, str(x.get("name") or t), safe_float(x.get("composite"), 0.0)))
        if picks:
            save_promotions(region, picks)
            st.success(tr("promote_done", added=len(picks), skipped=skipped))
            st.rerun()
        else:
            st.info(tr("promote_none"))


def record_theme_snapshot(rows: list[dict]) -> None:
    """Persist per-theme aggregates for one FULL scan. Quick scans are skipped by the
    caller (comparing quick vs full would be noise, not signal). A content signature
    dedupes Streamlit's reruns: the same scan rendering ten times inserts once."""
    sig = hashlib.md5(json.dumps(
        [(r["theme"], round(safe_float(r.get("momentum"), 0.0), 2), r["n"]) for r in rows],
        sort_keys=True).encode()).hexdigest()
    try:
        with get_conn() as conn:
            last = conn.execute(
                "SELECT snapshot FROM theme_history ORDER BY id DESC LIMIT 1").fetchone()
            if last and last[0] == sig:
                return
            now = datetime.now().isoformat(timespec="seconds")
            conn.executemany(
                "INSERT INTO theme_history (snapshot, theme, momentum, hype, composite, n, cover, created_at) "
                "VALUES (?,?,?,?,?,?,?,?)",
                [(sig, r["theme"], safe_float(r.get("momentum")), safe_float(r.get("hype")),
                  safe_float(r.get("composite")), int(r["n"]), int(r["cover"]), now)
                 for r in rows])
    except Exception as e:
        logger.warning("theme history write skipped: %s", e)


def theme_momentum_deltas() -> dict[str, float]:
    """Momentum change per theme vs the PREVIOUS recorded snapshot (latest minus
    prior). Empty dict when fewer than two snapshots exist — the Δ column shows '—'
    until a second full scan is recorded."""
    try:
        with get_conn() as conn:
            snaps = [r[0] for r in conn.execute(
                # GROUP BY + MAX(id) instead of DISTINCT + ORDER BY id: Postgres
                # rejects ordering a DISTINCT by a column outside the select list
                # (sqlite tolerates it); this form is valid and identical on both.
                "SELECT snapshot FROM theme_history GROUP BY snapshot "
                "ORDER BY MAX(id) DESC LIMIT 2")]
            if len(snaps) < 2:
                return {}
            cur = dict(conn.execute(
                "SELECT theme, momentum FROM theme_history WHERE snapshot = ?", (snaps[0],)))
            prev = dict(conn.execute(
                "SELECT theme, momentum FROM theme_history WHERE snapshot = ?", (snaps[1],)))
    except Exception as e:
        logger.warning("theme history read skipped: %s", e)
        return {}
    return {t: float(cur[t]) - float(prev[t])
            for t in cur if t in prev
            and cur[t] is not None and prev[t] is not None}


def render_themes(results: list[dict]) -> None:
    if not results:
        st.info(tr("need_run_engine"))
        return
    by_ticker = {r["ticker"]: r for r in results}

    def _avg(present, key):
        vals = [safe_float(x.get(key), float("nan")) for x in present]
        vals = [v for v in vals if not math.isnan(v)]
        return sum(vals) / len(vals) if vals else float("nan")

    # Smart-money overlay: superinvestor 13F NEW buys, summed per theme. US-only and
    # ~45-day lagged by nature; cached a day. Independent of the yfinance scan, so it
    # covers every US member regardless of quick-scan. Fail-safe -> NaN if unavailable.
    sci = {}
    if sec_research is not None:
        all_us = sorted({t for ticks in THEMES.values() for t in ticks if "." not in t})
        try:
            sci = _superinvestor_counts_cached(tuple(all_us))
        except Exception:
            sci = {}
    smart_ok = bool(sci)

    rows = []
    for theme, ticks in THEMES.items():
        present = [by_ticker[t] for t in ticks if t in by_ticker]
        if not present:
            continue   # nothing from this theme was scanned -> omit (coverage note explains)
        smart = float(sum(int(sci.get(t, 0) or 0) for t in ticks)) if smart_ok else float("nan")
        # Breadth: does the whole basket participate, or is one megacap carrying the
        # average? (>SMA50 % and BUY %). This is the honest fix for megacap skew —
        # not cap-weighting, which would amplify it.
        above = sum(1 for x in present
                    if safe_float(x.get("price"), float("nan")) > safe_float(x.get("sma50"), float("inf")))
        buys = sum(1 for x in present if str(x.get("recommendation")) == "BUY")
        rows.append({"theme": theme,
                     "momentum": _avg(present, "momentum"),
                     "hype": _avg(present, "hype_score"),
                     "smart": smart,
                     "composite": _avg(present, "composite"),
                     "ret1m": _avg(present, "ret_1m"),
                     "breadth": above / len(present) * 100.0,
                     "buyspct": buys / len(present) * 100.0,
                     "n": len(present), "cover": len(ticks)})
    if not rows:
        st.warning(tr("themes_no_coverage"))
        return
    # Rotation memory: record full scans only, then diff vs the previous snapshot.
    if not st.session_state.get("scan_is_quick", True):
        record_theme_snapshot(rows)
    deltas = theme_momentum_deltas()
    df = pd.DataFrame(rows)
    df["delta"] = df["theme"].map(lambda t: deltas.get(t, float("nan")))

    st.caption(tr("themes_caption"))

    # Multi-lens bubble: momentum (x) vs attention (y), bubble size = smart-money buys
    # (falls back to coverage when 13F is unavailable). Lets you read quadrants at a
    # glance — strong-but-quiet (right/low) vs loud-but-weak (left/high).
    size_field, size_title = (("smart", tr("col_theme_smart")) if smart_ok
                              else ("n", tr("col_theme_coverage")))
    bubble = (alt.Chart(df).mark_circle(opacity=0.7).encode(
        x=alt.X("momentum:Q", axis=alt.Axis(title=tr("themes_momentum_axis"))),
        y=alt.Y("hype:Q", axis=alt.Axis(title=tr("themes_hype_axis"))),
        size=alt.Size(f"{size_field}:Q", title=size_title, scale=alt.Scale(range=[80, 900])),
        color=alt.Color("theme:N", legend=None),
        tooltip=[alt.Tooltip("theme:N", title=tr("col_theme")),
                 alt.Tooltip("momentum:Q", title=tr("col_theme_momentum"), format=".0f"),
                 alt.Tooltip("hype:Q", title=tr("col_theme_hype"), format=".0f"),
                 alt.Tooltip("smart:Q", title=tr("col_theme_smart"), format=".0f"),
                 alt.Tooltip("composite:Q", title=tr("col_theme_strength"), format=".0f")])
        .properties(height=380, width="container"))
    st.altair_chart(bubble)
    st.caption(tr("themes_bubble_caption"))

    # Rank-by lens: momentum (strong now), attention (hype volume), or smart-money (13F
    # new buys). Triangulation, not prediction — see the caption caveats.
    lenses = {tr("themes_rank_momentum"): ("momentum", tr("themes_momentum_axis")),
              tr("themes_rank_hype"): ("hype", tr("themes_hype_axis")),
              tr("themes_rank_smart"): ("smart", tr("themes_smart_axis"))}
    choice = st.radio(tr("themes_rank_by"), list(lenses.keys()), horizontal=True)
    sort_key, axis_title = lenses[choice]
    df = df.sort_values(sort_key, ascending=False, na_position="last")

    chart = (alt.Chart(df).mark_bar()
             .encode(
                 x=alt.X(f"{sort_key}:Q", axis=alt.Axis(title=axis_title)),
                 y=alt.Y("theme:N", sort="-x", axis=alt.Axis(title=None)),
                 color=alt.Color("theme:N", legend=None),
                 tooltip=[alt.Tooltip("theme:N", title=tr("col_theme")),
                          alt.Tooltip("momentum:Q", title=tr("col_theme_momentum"), format=".0f"),
                          alt.Tooltip("hype:Q", title=tr("col_theme_hype"), format=".0f"),
                          alt.Tooltip("smart:Q", title=tr("col_theme_smart"), format=".0f"),
                          alt.Tooltip("composite:Q", title=tr("col_theme_strength"), format=".0f")])
             .properties(height=max(180, 28 * len(df)), width="container"))
    st.altair_chart(chart)

    table = df.assign(
        coverage=lambda d: d["n"].astype(str) + "/" + d["cover"].astype(str),
        delta_disp=lambda d: d["delta"].map(
            lambda v: "—" if math.isnan(v) else f"{'▲' if v >= 0 else '▼'} {v:+.1f}"))[
        ["theme", "momentum", "delta_disp", "breadth", "buyspct", "hype", "smart",
         "composite", "ret1m", "coverage"]].rename(columns={
        "theme": tr("col_theme"), "momentum": tr("col_theme_momentum"),
        "delta_disp": tr("col_theme_delta"),
        "breadth": tr("col_theme_breadth"), "buyspct": tr("col_theme_buyspct"),
        "hype": tr("col_theme_hype"), "smart": tr("col_theme_smart"),
        "composite": tr("col_theme_strength"), "ret1m": tr("col_theme_ret1m"),
        "coverage": tr("col_theme_coverage")})
    st.dataframe(table.style.format({tr("col_theme_momentum"): "{:.0f}", tr("col_theme_hype"): "{:.0f}",
                 tr("col_theme_breadth"): "{:.0f}%", tr("col_theme_buyspct"): "{:.0f}%",
                 tr("col_theme_smart"): "{:.0f}", tr("col_theme_strength"): "{:.0f}",
                 tr("col_theme_ret1m"): "{:+.1f}%"}, na_rep="—"),
                 width="stretch", hide_index=True)
    st.caption(tr("themes_coverage_note"))
    st.caption(tr("themes_delta_note"))

    if not smart_ok:
        st.caption(tr("themes_smart_unavailable"))

    # drill into one theme -> its scanned stocks, with per-name smart-money buys
    st.markdown(f"#### {tr('themes_top_header')}")
    pick = st.selectbox(tr("themes_select"), list(df["theme"]))
    members = sorted([by_ticker[t] for t in THEMES[pick] if t in by_ticker],
                     key=lambda x: safe_float(x.get("composite"), float("-inf")), reverse=True)
    mdf = pd.DataFrame([{
        tr("col_ticker"): x["ticker"], tr("col_company"): x.get("name", x["ticker"]),
        tr("col_theme_strength"): safe_float(x.get("composite"), float("nan")),
        tr("col_theme_momentum"): safe_float(x.get("momentum"), float("nan")),
        tr("col_theme_hype"): safe_float(x.get("hype_score"), float("nan")),
        tr("col_theme_smart"): float(int(sci.get(x["ticker"], 0) or 0)) if smart_ok else float("nan"),
        tr("col_theme_ret1m"): safe_float(x.get("ret_1m"), float("nan")),
        tr("why_call"): str(x.get("recommendation", "—")),
    } for x in members])
    st.dataframe(mdf.style.format({tr("col_theme_strength"): "{:.0f}", tr("col_theme_momentum"): "{:.0f}",
                 tr("col_theme_hype"): "{:.0f}", tr("col_theme_smart"): "{:.0f}",
                 tr("col_theme_ret1m"): "{:+.1f}%"}, na_rep="—"),
                 width="stretch", hide_index=True)

    # Deep-scan echo: cross-reference the latest deep-scan finalists (any market,
    # pulled from session state — no new fetching) against these theme baskets via
    # their Yahoo sector/industry. This is the Themes <-> Deep Scan bridge: theme
    # heat measured on the curated basket, confirmed or contradicted by the top
    # names from the much wider deep universe — including names the baskets don't
    # know about, which is exactly the discovery the curated lists can't provide.
    # NOTE: placed at the very end of the tab (nothing else follows), so an empty
    # state here can never skip the leaderboard or drill-down rendered above.
    deep_all = []
    for reg in DEEP_UNIVERSES:
        deep_all.extend(st.session_state.get(f"deep_results_{reg}") or [])
    st.markdown(f"##### {tr('themes_deep_echo')}")
    if not deep_all:
        st.caption(tr("themes_deep_echo_hint"))
    else:
        echo_rows = [{
            tr("col_theme"): x["theme_match"],
            tr("col_ticker"): x["ticker"],
            tr("col_company"): x.get("name", x["ticker"]),
            "_region": region_name(x.get("region", "")),
            tr("col_theme_strength"): safe_float(x.get("composite"), float("nan")),
            tr("deep_col_score"): safe_float(x.get("screen_score"), float("nan")),
        } for x in deep_all if x.get("theme_match")]
        if not echo_rows:
            st.caption(tr("themes_deep_echo_none"))
        else:
            edf = (pd.DataFrame(echo_rows)
                   .sort_values([tr("col_theme"), tr("col_theme_strength")], ascending=[True, False])
                   .groupby(tr("col_theme"), sort=False).head(3)
                   .rename(columns={"_region": tr("regions_to_scan")}))
            st.dataframe(edf.style.format({tr("col_theme_strength"): "{:.0f}",
                         tr("deep_col_score"): "{:.0f}"}, na_rep="—"),
                         width="stretch", hide_index=True)
            st.caption(tr("themes_deep_echo_note"))


def refresh_levels_for(r: dict) -> bool:
    """Refetch ONE ticker fresh and compute CURRENT reference levels into
    r["live_levels"]. The scan-time result (price, score, call, levels, price_date) is
    never modified, and audit rows stay frozen. Returns False on any failure, leaving
    the result exactly as it was."""
    try:
        fresh = _bulk_history([r["ticker"]], period="1y").get(r["ticker"])
        if fresh is None or fresh.empty or "Close" not in fresh.columns:
            return False
        close = fresh["Close"].dropna()
        if len(close) < 30:
            return False
        px = safe_float(close.iloc[-1])
        s20 = safe_float(close.rolling(20).mean().iloc[-1])
        s50 = safe_float(close.rolling(50).mean().iloc[-1])
        atr = (compute_atr(fresh["High"], fresh["Low"], close)
               if "High" in fresh.columns and "Low" in fresh.columns else float("nan"))
        lvls = trade_levels(px, s20, s50, atr, safe_float(close.iloc[-252:].max()))
        if lvls is None:
            return False
        # Stored SEPARATELY. Overwriting price/levels in place left a record whose
        # composite, call and price_date came from the scan while its price and levels
        # came from now — two moments presented as one. The scan-time result stays
        # exactly as scored; refreshed levels carry their own as-of and fetch time.
        r["live_levels"] = {
            "price": px, "atr": atr, "sma20": s20, "sma50": s50,
            "entry_lo": lvls["entry_lo"], "entry_hi": lvls["entry_hi"],
            "target": lvls["target"], "stop": lvls["stop"],
            "price_asof": bar_date(close.index),
            "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        return True
    except Exception as e:
        logger.warning("level refresh failed for %s: %s", r.get("ticker"), e)
        return False


def normalize_news(raw, limit: int = 6) -> list[dict]:
    """Flatten either yfinance news schema to [{title, publisher, url, ts}].

    yfinance changed shape across versions: older releases return a flat list of
    dicts (title / publisher / link / providerPublishTime), newer ones wrap the same
    information in item["content"] with nested provider and canonicalUrl objects and
    an ISO pubDate. Both are handled, because pinning a yfinance version for one
    cosmetic panel isn't worth it. Pure function — no network, no Streamlit.
    """
    out = []
    for item in raw or []:
        if not isinstance(item, dict):
            continue
        c = item.get("content") if isinstance(item.get("content"), dict) else item
        title = str(c.get("title") or item.get("title") or "").strip()
        if not title:
            continue
        prov = c.get("provider") if isinstance(c.get("provider"), dict) else {}
        publisher = str(prov.get("displayName") or item.get("publisher")
                        or c.get("publisher") or "").strip()
        url = str(item.get("link") or "")
        for key in ("canonicalUrl", "clickThroughUrl"):
            v = c.get(key)
            if isinstance(v, dict) and v.get("url"):
                url = str(v["url"]); break
            if isinstance(v, str) and v:
                url = v; break
        ts = float("nan")
        epoch = item.get("providerPublishTime") or c.get("providerPublishTime")
        if epoch:
            ts = safe_float(epoch)
        else:
            for key in ("pubDate", "displayTime"):
                if c.get(key):
                    try:
                        ts = float(pd.Timestamp(c[key]).timestamp()); break
                    except Exception:
                        pass
        out.append({"title": title, "publisher": publisher, "url": url, "ts": ts})
        if len(out) >= limit:
            break
    return out


@st.cache_data(ttl=1800, show_spinner=False)
def fetch_news(ticker: str, limit: int = 6) -> list[dict]:
    """Recent headlines for one ticker from yfinance (already a dependency — no
    scraping, no extra package, works on Streamlit Cloud unlike a forum scraper).

    This is CONTEXT FOR THE READER, never a scoring input: nothing here reaches the
    composite, the factors or the walk-forward loop. Turning headlines into a signal
    would need sentiment analysis this app deliberately doesn't do.
    Fail-safe: [] on any error, and coverage is genuinely patchy outside the US.
    """
    if yf is None:
        return []
    try:
        time.sleep(0.15)   # pace the per-ticker endpoint; cache misses only
        raw = _ticker(ticker).news or []
    except Exception as e:
        logger.warning("news fetch failed for %s: %s", ticker, e)
        return []
    return normalize_news(raw, limit)


def explanation_weights(r: dict) -> tuple[dict, bool]:
    """(weights, exact) to explain a result's composite with. exact=True means these
    are the weights that PRODUCED the score; False means the result predates weight
    snapshots and the current weights are a labelled approximation."""
    snap = r.get("weights_snapshot")
    if snap:
        return dict(snap), True
    return get_latest_weights(), False



def _hype_source_record(r: dict, source: str) -> dict:
    """Read scan-time data only. Rendering never fetches or changes a score."""
    ticker = str(r.get("ticker") or "").upper()
    if source == "jp_board":
        if not ticker.endswith(".T"):
            return {"status": "not_applicable"}
        record = r.get("jp_board")
        if isinstance(record, dict) and record:
            return dict(record)
        if r.get("jp_forum_enabled") is False:
            return {"status": "disabled"}
        return {"status": "not_collected"}
    if stocktwits_symbol(ticker) is None:
        return {"status": "not_applicable"}
    record = r.get("stocktwits")
    return dict(record) if isinstance(record, dict) and record else {"status": "not_collected"}


def _hype_timestamp(value) -> str:
    """Retain the actual offset. Never label an unknown timezone as UTC."""
    if not value:
        return "\u2014"
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt.isoformat(timespec="minutes")
    except (TypeError, ValueError):
        return str(value)


def render_hype_sentiment(r: dict) -> None:
    """Always-visible bilingual source cards. No network, no synthetic values."""
    st.markdown(f"#### {tr('hype_panel_title')}")
    st.caption(tr("hype_panel_intro"))
    summary = st.columns(3)
    summary[0].metric(tr("factor_hype"), fmt_num(safe_float(r.get("hype_score")), 1) + " /100")
    summary[1].metric(tr("evi_mentions"), fmt_num(safe_float(r.get("hype_mentions")), 1))
    hype = r.get("hype") if isinstance(r.get("hype"), dict) else {}
    summary[2].metric(tr("hype_panel_breakouts"),
                      str(hype.get("breakout_days")) if hype.get("breakout_days") is not None else "\u2014")
    st.caption(tr("hype_panel_snapshot", asof=str(r.get("price_date") or "\u2014")))
    # What the mention count is and which feeds produced it. These were on the Deep Dive
    # before the panel replaced that block; they are last-scan values, so nothing is fetched.
    st.caption(tr("hype_buzz_caption"))
    if _LAST_HYPE_STATUS:
        st.caption(_LAST_HYPE_STATUS)
    if _LAST_HYPE_FETCHED_AT:
        st.caption(tr("hype_updated", ago=_ago(_LAST_HYPE_FETCHED_AT)))
    left, right = st.columns(2)
    for col, source, title in ((left, "jp_board", "Yahoo!\u63b2\u793a\u677f \u300c\u307f\u3093\u306a\u306e\u8a55\u4fa1\u300d"),
                               (right, "stocktwits", "Stocktwits")):
        record = _hype_source_record(r, source)
        status = str(record.get("status") or "unavailable")
        with col:
            with st.container(border=True):
                st.markdown(f"**{title}**")
                status_key = "hype_feed_" + status
                # Unknown provider statuses are text, never unsafe HTML.
                status_text = tr(status_key) if status_key in TRANSLATIONS.get(get_lang(), {}) else status
                st.caption(status_text)
                if source == "jp_board":
                    st.caption(tr("hype_jp_role"))
                    b = safe_float(record.get("buy_pct"))
                    s = safe_float(record.get("sell_pct"))
                    n = safe_float(record.get("neutral_pct"))
                    if status == "ok" and not (math.isnan(b) or math.isnan(s)):
                        for key, val in (("crowd_jp_buy", b), ("crowd_jp_neutral", n), ("crowd_jp_sell", s)):
                            st.metric(tr(key), "\u2014" if math.isnan(val) else f"{val:.2f}%")
                        # Applied means this scan actually received a scorable poll,
                        # not that today's sidebar happens to be switched on.
                        sb, ss = safe_float(r.get("jp_bull")), safe_float(r.get("jp_bear"))
                        neutral = record.get("neutral_pct")
                        applied = (not math.isnan(sb) and not math.isnan(ss)
                                   and abs(sb-b) < 1e-9 and abs(ss-s) < 1e-9
                                   and forum_sentiment_score(b, s, neutral) is not None)
                        st.caption(tr("hype_jp_applied" if applied else "hype_jp_not_applied"))
                    elif status == "disabled":
                        st.info(tr("hype_jp_disabled_hint"))
                    elif status == "not_collected":
                        st.info(tr("hype_feed_scan_hint"))
                    elif status != "not_applicable":
                        st.info(tr("hype_no_number"))
                else:
                    st.caption(tr("hype_st_role"))
                    score = safe_float(record.get("score"))
                    if status == "ok" and not math.isnan(score) and 0 <= score <= 100:
                        st.metric(tr("crowd_st_score"), f"{score:.1f} /100")
                        st.progress(score / 100.0)
                        # Provider label is rendered as literal text, not HTML/Markdown.
                        st.text(str(record.get("label") or "\u2014"))
                        attention = safe_float(record.get("message_volume_score"))
                        st.metric(tr("crowd_st_attention"),
                                  "\u2014" if math.isnan(attention) else f"{attention:.1f} /100")
                    elif status == "not_configured":
                        st.info(tr("hype_st_credentials"))
                    elif status == "not_collected":
                        st.info(tr("hype_feed_scan_hint"))
                    elif status != "not_applicable":
                        st.info(tr("hype_no_number"))
                    st.caption(tr("hype_st_not_percent"))
                if record.get("fetched_at"):
                    st.caption(tr("hype_fetched", value=_hype_timestamp(record.get("fetched_at"))))
                with st.expander(tr("hype_source_details")):
                    st.text(tr("hype_window") + ": " + str(record.get("window") or "\u2014"))
                    st.text(tr("hype_provider_asof") + ": " + _hype_timestamp(record.get("provider_asof")))
                    st.text(tr("hype_parser") + ": " + str(record.get("parser_version") or "\u2014"))
                    if record.get("reason"):
                        st.text(tr("hype_reason") + ": " + str(record["reason"]))
                    if source == "jp_board" and isinstance(record.get("categories"), dict) and record["categories"]:
                        st.dataframe(pd.DataFrame([
                            {tr("crowd_col_category"): k, tr("crowd_col_pct"): v}
                            for k, v in record["categories"].items()
                        ]), hide_index=True, width="stretch")
    st.caption(tr("hype_panel_footer"))


def render_deep_dive(results: list[dict]) -> None:
    if not results:
        st.info(tr("need_run_history"))
        return
    rank_of = {x["ticker"]: i + 1 for i, x in enumerate(
        sorted(results, key=lambda x: safe_float(x.get("composite"), float("-inf")), reverse=True))}

    names = {r["ticker"]: r.get("name", r["ticker"]) for r in results}
    opts = [r["ticker"] for r in results]
    # "deep_dive_pick" may have been set by a row click in the Regional tab (which
    # renders earlier in the same rerun). Sanitize: a stale pick from a previous
    # scan that's no longer in the results must not crash the keyed selectbox.
    if st.session_state.get("deep_dive_pick") not in opts:
        st.session_state.pop("deep_dive_pick", None)
    pick = st.selectbox(tr("select_profile"), opts,
                        format_func=lambda t: f"{t} — {names.get(t, t)}",
                        key="deep_dive_pick")
    r = next(x for x in results if x["ticker"] == pick)
    # Explain the score with the weights that PRODUCED it. Weights can change after a
    # scan, and a restored snapshot can predate a change; decomposing an old score
    # with current weights would not add up to the score being explained.
    weights, _weights_exact = explanation_weights(r)
    st.markdown(f"### {r['ticker']} — {r.get('name', r['ticker'])}")

    # --- headline: composite, call, rank ---
    comp = safe_float(r.get("composite"), float("nan"))
    rec = str(r.get("recommendation", "—"))
    hc = st.columns(3)
    hc[0].markdown(metric_card(tr("why_composite"), fmt_num(comp, 1),
                   positive=(not math.isnan(comp) and comp >= BUY_THRESHOLD)), unsafe_allow_html=True)
    hc[1].markdown(metric_card(tr("why_call"), rec, positive=(rec == "BUY")), unsafe_allow_html=True)
    hc[2].markdown(metric_card(tr("why_rank"), f"#{rank_of.get(pick, '—')} / {len(results)}"),
                   unsafe_allow_html=True)

    # --- Trade reference levels (entry / target / stop) -----------------------
    # Structure+volatility-derived LEVELS, not forecasts (see indicators.trade_levels).
    # Hidden entirely when ATR wasn't computable — made-up levels are worse than none.
    # The refresh button refetches THIS ticker fresh and recomputes in place — one
    # bulk call for one name, so it's cheap and can also FILL levels a throttled
    # scan left blank. Audit rows are never rewritten (frozen at rec time).
    bc, cc = st.columns([1, 3])
    if bc.button(tr("levels_refresh_btn"), key=f"lvl_refresh_{pick}"):
        if not refresh_levels_for(r):
            st.warning(tr("levels_refresh_failed"))
    # Scan-time levels (what the engine scored) first, refreshed levels separately.
    st.caption(tr("levels_scan_time", asof=r.get("price_date") or "—"))
    e_lo, e_hi = safe_float(r.get("entry_lo")), safe_float(r.get("entry_hi"))
    tgt, stp = safe_float(r.get("target_level")), safe_float(r.get("stop_level"))
    px = safe_float(r.get("price"))
    if not any(math.isnan(v) for v in (e_lo, e_hi, tgt, stp, px)) and px > 0:
        lv = st.columns(3)
        lv[0].markdown(metric_card(tr("level_entry"), f"{e_lo:,.2f} – {e_hi:,.2f}"),
                       unsafe_allow_html=True)
        lv[1].markdown(metric_card(tr("level_target"), f"{tgt:,.2f}",
                       f"{(tgt / px - 1) * 100:+.1f}%", positive=True), unsafe_allow_html=True)
        lv[2].markdown(metric_card(tr("level_stop"), f"{stp:,.2f}",
                       f"{(stp / px - 1) * 100:+.1f}%", positive=False), unsafe_allow_html=True)
        st.caption(tr("levels_note"))
    _ll = r.get("live_levels") or {}
    if _ll:
        st.markdown(f"**{tr('levels_live_header')}**")
        st.caption(tr("levels_live_caption", asof=_ll.get("price_asof") or "—",
                      fetched=str(_ll.get("fetched_at") or "—")[:16].replace("T", " ")))
        lpx = safe_float(_ll.get("price"))
        if lpx > 0:
            lc = st.columns(4)
            lc[0].markdown(metric_card(tr("price_label"), f"{lpx:,.2f}"), unsafe_allow_html=True)
            lc[1].markdown(metric_card(tr("level_entry"),
                           f"{safe_float(_ll.get('entry_lo')):,.2f} – {safe_float(_ll.get('entry_hi')):,.2f}"),
                           unsafe_allow_html=True)
            lc[2].markdown(metric_card(tr("level_target"), f"{safe_float(_ll.get('target')):,.2f}"),
                           unsafe_allow_html=True)
            lc[3].markdown(metric_card(tr("level_stop"), f"{safe_float(_ll.get('stop')):,.2f}"),
                           unsafe_allow_html=True)

    # --- factor profile: six-axis radar, this pick vs the scan average ---
    # The contribution bars below answer "why this composite"; the radar answers
    # "what KIND of stock is this" (momentum monster vs. value dog) at a glance.
    # plotly is optional (guarded import) — without it the section is skipped.
    if go is not None:
        def _fval(x: dict, f: str) -> float:
            return safe_float(x.get("hype_score" if f == "hype" else f), 50.0)
        cats = [tr(f"factor_{f}") for f in FACTORS]
        vals = [_fval(r, f) for f in FACTORS]
        avgs = [float(np.mean([_fval(x, f) for x in results])) for f in FACTORS]
        fig = go.Figure()
        fig.add_trace(go.Scatterpolar(
            r=avgs + avgs[:1], theta=cats + cats[:1], name=tr("radar_scan_avg"),
            line=dict(color="#94a3b8", dash="dot"), opacity=0.65))
        fig.add_trace(go.Scatterpolar(
            r=vals + vals[:1], theta=cats + cats[:1], name=r["ticker"],
            fill="toself", line=dict(color="#3b82f6"),
            fillcolor="rgba(59,130,246,0.25)"))
        fig.update_layout(
            polar=dict(bgcolor="rgba(0,0,0,0)",
                       radialaxis=dict(range=[0, 100], showticklabels=True,
                                       tickfont=dict(size=10), gridcolor="rgba(148,163,184,0.25)"),
                       angularaxis=dict(gridcolor="rgba(148,163,184,0.25)")),
            paper_bgcolor="rgba(0,0,0,0)", font=dict(color="#94a3b8"),
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.15, x=0.5, xanchor="center"),
            height=360, margin=dict(l=50, r=50, t=30, b=30))
        st.markdown(f"#### {tr('radar_header')}")
        st.plotly_chart(fig, width="stretch", key=f"radar_{pick}")
    else:
        st.caption(tr("radar_plotly_hint"))

    # --- why this pick: exact weighted-contribution decomposition ---
    st.markdown(f"#### {tr('why_header')}")
    if not _weights_exact:
        # A result restored from before snapshots existed: the original weights are
        # unknown, so this breakdown uses CURRENT weights and may not add up exactly.
        st.caption(tr("why_weights_unavailable"))
    name_map = {"momentum": tr("factor_momentum"), "value": tr("factor_value"),
                "technical": tr("factor_technical"), "hype": tr("factor_hype"),
                "quality": tr("factor_quality"), "theme": tr("factor_theme")}
    bd = _pick_breakdown(r, weights)
    bd["label"] = bd["factor"].map(name_map)
    total = float(bd["contribution"].sum())
    bd_sorted = bd.sort_values("contribution", ascending=False)

    chart = (alt.Chart(bd_sorted)
             .mark_bar()
             .encode(
                 x=alt.X("contribution:Q", axis=alt.Axis(title=tr("why_contrib_axis"))),
                 y=alt.Y("label:N", sort="-x", axis=alt.Axis(title=None)),
                 color=alt.Color("label:N", legend=None),
                 tooltip=[alt.Tooltip("label:N", title=tr("col_factor")),
                          alt.Tooltip("score:Q", title=tr("col_score"), format=".0f"),
                          alt.Tooltip("weight:Q", title=tr("col_weight"), format=".0%"),
                          alt.Tooltip("contribution:Q", title=tr("col_contribution"), format=".1f")])
             .properties(height=210, width="container"))
    st.altair_chart(chart)
    st.caption(tr("why_contrib_caption"))

    show = (bd_sorted.assign(share=lambda d: (d["contribution"] / total * 100.0) if total else float("nan"))
            [["label", "score", "weight", "contribution", "share"]]
            .rename(columns={"label": tr("col_factor"), "score": tr("col_score"),
                             "weight": tr("col_weight"), "contribution": tr("col_contribution"),
                             "share": tr("col_share")}))
    st.dataframe(show.style.format({tr("col_score"): "{:.0f}", tr("col_weight"): "{:.0%}",
                 tr("col_contribution"): "{:.1f}", tr("col_share"): "{:.0f}%"}, na_rep="—"),
                 width="stretch", hide_index=True)

    # plain-language rationale: top two contributors as drivers, lowest score as the drag
    top, second = bd_sorted.iloc[0], bd_sorted.iloc[1]
    weak = bd.sort_values("score").iloc[0]
    share2 = ((top["contribution"] + second["contribution"]) / total * 100.0) if total else float("nan")
    st.info(tr("why_rationale", d1=top["label"], s1=f"{top['score']:.0f}",
               d2=second["label"], s2=f"{second['score']:.0f}", share=f"{share2:.0f}",
               w=weak["label"], sw=f"{weak['score']:.0f}"))

    # Hype context sits beside the factor explanation, not below the price chart.
    render_hype_sentiment(r)

    # --- evidence: the real numbers behind each factor ---
    st.markdown(f"#### {tr('why_evidence')}")
    ev = pd.DataFrame(_evidence_rows(r), columns=[tr("col_factor"), tr("col_metric"), tr("col_value")])
    st.dataframe(ev, width="stretch", hide_index=True)

    # --- price context ---
    # Restored snapshot results carry no history frame (stripped before
    # serialising) — lazily refetch just the picked ticker's series, cache it
    # back onto the dict, and degrade to a caption if the fetch fails.
    hist = r.get("history")
    if hist is None:
        try:
            hist = fetch_history(r["ticker"])
            r["history"] = hist
        except Exception:
            hist = None
    if hist is not None and "Close" in getattr(hist, "columns", []):
        st.markdown(f"#### {tr('price_trend')}")
        chart_df = pd.DataFrame({"Close": hist["Close"],
                                 "SMA20": hist["Close"].rolling(20).mean(),
                                 "SMA50": hist["Close"].rolling(50).mean()})
        st.line_chart(chart_df.dropna())
    else:
        st.caption(tr("price_chart_unavailable"))

    # --- Recent news -------------------------------------------------------
    # Deliberately last and visually separate: it is reading material, not part of
    # the score. Fetched on demand for the selected name only, so it costs one
    # request per stock you actually open rather than one per name scanned.
    st.markdown(f"##### {tr('news_header')}")
    _news = fetch_news(pick)
    if not _news:
        st.caption(tr("news_none"))
    else:
        for _n in _news:
            _age = _ago(_n["ts"]) if not math.isnan(_n["ts"]) else ""
            _meta = " · ".join(x for x in (_n["publisher"], _age) if x)
            _head = f"[{_n['title']}]({_n['url']})" if _n["url"] else _n["title"]
            st.markdown(f"- {_head}  \n  <span class='qc-sub'>{_meta}</span>",
                        unsafe_allow_html=True)
        st.caption(tr("news_note"))

def split_outcomes_by_basis(df: pd.DataFrame) -> dict:
    """Resolved BUY/SELL outcomes grouped by how they were judged.

      verified — outcome_basis == 'excess': measured against a benchmark
      absolute — 'absolute': no usable benchmark, judged on raw return
      unknown  — NULL/other: written before the basis was recorded. These may mix
                 benchmark-relative and absolute judgements and may include simulated
                 rows an older demo seed wrote into the live table, so they are shown
                 separately and never counted as verified accuracy. Nothing is deleted.
    """
    empty = pd.DataFrame()
    if df is None or df.empty:
        return {"verified": empty, "absolute": empty, "unknown": empty}
    done = df[df["outcome"].isin([OUTCOME_LOSS, OUTCOME_WIN])
              & df["recommendation"].isin(DIRECTIONAL_CALLS)]
    basis = (done["outcome_basis"].astype(str) if "outcome_basis" in done.columns
             else pd.Series("None", index=done.index))
    return {"verified": done[basis.eq("excess")],
            "absolute": done[basis.eq("absolute")],
            "unknown": done[~basis.isin(["excess", "absolute"])]}


def accuracy_summary(df: pd.DataFrame, demo: bool = False) -> dict:
    """What the Audit headline counts. Live data: ONLY outcomes judged against a
    benchmark. Demo data is wholly simulated (and bannered), so it is shown whole."""
    groups = split_outcomes_by_basis(df)
    done = (pd.concat(list(groups.values())) if demo else groups["verified"])
    win = 100.0 * done["outcome"].mean() if not done.empty else float("nan")
    return {"groups": groups, "headline": done, "win_rate": win}


def render_model_lab() -> None:
    """Model Lab: realised forward excess returns by score, factor and candidate signal.

    Its own function because it reads the observations ledger only — nothing here
    depends on the mock portfolio — yet it used to sit BELOW the mock-portfolio
    section's early `return`, so an empty mock portfolio (a fresh database, or no
    picks yet) silently hid the whole Model Lab.
    """
    # --- Model Lab (V2.1 measurement) -------------------------------------
    # Does a high composite actually precede excess return? This reports realised
    # numbers only. No expected-return or probability figure is shown, because those
    # would need out-of-sample calibration this dataset can't yet support — inventing
    # them would be exactly the false precision the rest of the app avoids.
    with st.expander(tr("lab_header")):
        try:
            with get_conn() as _c:
                _tot = _c.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
                _mat = _c.execute(
                    "SELECT COUNT(*) FROM observations WHERE x20 IS NOT NULL").fetchone()[0]
        except Exception:
            _tot, _mat = 0, 0
        st.caption(tr("lab_intro", total=_tot, matured=_mat))
        # Rows scored by an earlier factor definition are kept but not pooled: mixing
        # absolute-momentum and relative-momentum rows would measure neither model.
        try:
            with get_conn() as _c:
                _old = _c.execute(
                    "SELECT COUNT(*) FROM observations WHERE model_version IS NULL "
                    "OR model_version <> ?", (PRODUCTION_MODEL_VERSION,)).fetchone()[0]
        except Exception:
            _old = 0
        st.caption(tr("lab_prod_model", version=PRODUCTION_MODEL_VERSION))
        if _old:
            st.caption(tr("lab_prod_excluded", n=_old))
        _h = st.radio(tr("lab_horizon"), list(OBS_HORIZONS), horizontal=True,
                      format_func=lambda d: tr("lab_days", d=d), key="lab_h")
        # Headline evidence first: does the top of the ranking beat the bottom?
        _sm = composite_summary(int(_h))
        if _sm and "spread" in _sm:
            m1, m2, m3, m4 = st.columns(4)
            m1.metric(tr("lab_m_spread"), f"{_sm['spread']:+.2f}%")
            m2.metric(tr("lab_m_top"), f"{_sm['top_q']:+.2f}%")
            m3.metric(tr("lab_m_bottom"), f"{_sm['bottom_q']:+.2f}%")
            m4.metric(tr("lab_m_ic"), "—" if math.isnan(_sm["ic"]) else f"{_sm['ic']:+.3f}")
            st.caption(tr("lab_m_note", n=_sm["n"], pos=f"{_sm['top_positive_rate']:.0f}",
                          dates=_sm["ic_dates"]))
            st.caption(tr("lab_m_cohorts", k=_sm["cohorts"], x=_sm["excluded_cohorts"],
                          m=COHORT_MIN_NAMES))
        elif _sm and _sm.get("n", 0) >= 50:
            st.caption(tr("lab_m_no_cohorts", n=_sm["n"], x=_sm.get("excluded_cohorts", 0),
                          m=COHORT_MIN_NAMES))
        elif _sm:
            st.caption(tr("lab_m_thin", n=_sm["n"]))
        _mix = benchmark_mix()
        if len([k for k in _mix if k != "unknown"]) > 1:
            st.caption(tr("lab_bench_mix"))
        _rg = region_breakdown(int(_h))
        if not _rg.empty:
            st.dataframe(_rg.rename(columns={
                "region": tr("col_region"), "count": tr("lab_col_n"),
                "mean": tr("lab_col_mean"), "median": tr("lab_col_median")})
                .assign(**{tr("col_region"): lambda d: d[tr("col_region")].map(region_name)})
                .style.format({tr("lab_col_mean"): "{:+.2f}%",
                               tr("lab_col_median"): "{:+.2f}%"}, na_rep="—"),
                width="stretch", hide_index=True)
        _b = observation_buckets(int(_h))
        if _b.empty:
            st.info(tr("lab_empty"))
        else:
            _disp = _b.rename(columns={"bucket": tr("lab_col_bucket"),
                                       "count": tr("lab_col_n"),
                                       "mean": tr("lab_col_mean"),
                                       "median": tr("lab_col_median")})
            st.dataframe(_disp.style.format({tr("lab_col_mean"): "{:+.2f}%",
                         tr("lab_col_median"): "{:+.2f}%"}, na_rep="—"),
                         width="stretch", hide_index=True)
            st.caption(tr("lab_note"))

        # --- Which factor actually forecasts? (measurement only) ----------
        st.markdown(f"**{tr('ic_header')}**")
        st.caption(tr("ic_intro"))
        _ic, _ndates = factor_ic_report(int(_h))
        if _ic.empty or _ndates == 0:
            st.info(tr("ic_empty"))
        else:
            if _ndates < IC_MIN_DATES:
                st.warning(tr("ic_thin", n=_ndates, need=IC_MIN_DATES))
            _ic = ic_display_frame(_ic)
            _ic = _ic.sort_values("mean_ic", ascending=False, na_position="last")
            st.dataframe(_ic.rename(columns={
                "signal": tr("ic_col_signal"), "kind": tr("ic_col_kind"),
                "mean_ic": tr("ic_col_ic"), "n_dates": tr("ic_col_dates"),
                "pct_positive": tr("ic_col_stable"), "n_obs": tr("lab_col_n")})
                [[tr("ic_col_signal"), tr("ic_col_kind"), tr("ic_col_ic"),
                  tr("ic_col_stable"), tr("ic_col_dates"), tr("lab_col_n")]]
                .style.format({tr("ic_col_ic"): "{:+.3f}", tr("ic_col_stable"): "{:.0f}%"},
                              na_rep="—"),
                width="stretch", hide_index=True)
            st.caption(tr("ic_note"))

        # --- Early Setup comparison (measurement only) --------------------
        st.markdown(f"**{tr('setup_lab_header')}**")
        st.caption(tr("setup_lab_intro"))
        st.caption(tr("setup_lab_model", version=EARLY_SETUP_MODEL_VERSION))
        # Version filtering hides rows scored by an older detector — correct, since
        # mixing them would compare different models in one bucket, but it must be
        # visible or the lab silently empties itself after every version bump.
        try:
            with get_conn() as _c:
                _other = _c.execute(
                    "SELECT COUNT(*) FROM observations WHERE setup_score IS NOT NULL "
                    "AND (setup_model_version IS NULL OR setup_model_version <> ?)",
                    (EARLY_SETUP_MODEL_VERSION,)).fetchone()[0]
        except Exception:
            _other = 0
        if _other:
            st.caption(tr("setup_lab_excluded", n=_other))
        _cov = setup_coverage()
        if _cov["total"]:
            st.caption(tr("setup_lab_coverage", n=_cov["total"],
                          avg=f"{_cov['avg_coverage_pct']:.0f}",
                          vol=f"{_cov['volume_pct']:.0f}",
                          bench=f"{_cov['benchmark_pct']:.0f}",
                          year=f"{_cov['full_year_pct']:.0f}"))
        _modest = st.checkbox(tr("setup_lab_modest"), value=False, key="lab_modest")
        _sb = setup_buckets(int(_h), modest_only=_modest)
        if _sb.empty:
            st.info(tr("setup_lab_empty"))
        else:
            _sd = _sb.rename(columns={"bucket": tr("setup_col_bucket"),
                                      "count": tr("lab_col_n"),
                                      "mean": tr("lab_col_mean"),
                                      "median": tr("lab_col_median"),
                                      "positive_rate": tr("setup_col_posrate")})
            st.dataframe(_sd.style.format({tr("lab_col_mean"): "{:+.2f}%",
                         tr("lab_col_median"): "{:+.2f}%",
                         tr("setup_col_posrate"): "{:.0f}%"}, na_rep="—"),
                         width="stretch", hide_index=True)
            _thin = _sb[_sb["count"] < 30]
            if not _thin.empty:
                st.caption(tr("setup_lab_thin",
                              buckets=", ".join(str(b) for b in _thin[_sb.columns[0]])))
            _st = setup_state_performance(int(_h))
            if not _st.empty:
                st.dataframe(_st.rename(columns={"setup_state": tr("setup_col_state"),
                                                 "count": tr("lab_col_n"),
                                                 "mean": tr("lab_col_mean"),
                                                 "median": tr("lab_col_median")})
                             .style.format({tr("lab_col_mean"): "{:+.2f}%",
                                            tr("lab_col_median"): "{:+.2f}%"}, na_rep="—"),
                             width="stretch", hide_index=True)
            st.caption(tr("setup_lab_note"))


def render_engine_audit(update_prices: bool = True) -> None:
    st.markdown(f"### {tr('audit_header_text')}")
    demo = bool(st.session_state.get("show_demo"))
    if demo and not os.path.exists(DEMO_DB_PATH):
        # Demo flag set but the demo file is gone (deleted, or never created): fall back
        # to the live view instead of crashing on the missing demo tables.
        st.session_state["show_demo"] = False
        demo = False
    if demo:
        st.warning(tr("demo_banner"))
        b1, b2 = st.columns(2)
        if b1.button(tr("demo_exit"), key="demo_exit"):
            st.session_state["show_demo"] = False
            st.rerun()
        if b2.button(tr("demo_clear"), key="demo_clear"):
            clear_demo_data()
            st.session_state["show_demo"] = False
            st.rerun()
    else:
        # An older build seeded demo rows straight into the LIVE database. Weight rows
        # are identifiable exactly; report them (never auto-delete) and offer an
        # explicit, history-preserving reset.
        _cont = live_demo_contamination()
        if _cont["active_weights_are_demo"]:
            st.error(tr("demo_live_weights", n=_cont["weight_rows"]))
            if st.button(tr("demo_reset_weights"), key="demo_reset_weights"):
                save_weights(dict(DEFAULT_WEIGHTS),
                             note="reset to defaults after demo contamination (user action)")
                st.rerun()
        elif _cont["weight_rows"]:
            st.caption(tr("demo_live_history", n=_cont["weight_rows"]))
        if _cont["suspect_recommendations"]:
            st.caption(tr("demo_live_recs", n=_cont["suspect_recommendations"]))
    st.caption(tr("persistence_note"))
    st.caption(tr("benchmark_note"))
    df = get_recommendations(demo=demo)
    if df.empty:
        st.info(tr("no_tracks"))
        # The Model Lab reads the observations ledger, which fills from scans whether
        # or not any recommendation has been recorded yet.
        if not demo:
            render_model_lab()
        return
    # Directional accuracy = BUY/SELL only, split by HOW each outcome was judged. Only
    # outcomes measured against a benchmark count as the headline accuracy; absolute-
    # return and legacy/unknown-provenance outcomes are shown beside it, not inside it.
    # (Demo data is wholly simulated and already bannered, so there it is shown whole.)
    _acc = accuracy_summary(df, demo=demo)
    groups, done, overall_win = _acc["groups"], _acc["headline"], _acc["win_rate"]
    c = st.columns(3)
    c[0].markdown(metric_card(tr("card_archived_calls"), str(len(df))), unsafe_allow_html=True)
    c[1].markdown(metric_card(tr("card_perf_verified"), str(len(done))), unsafe_allow_html=True)
    c[2].markdown(metric_card(tr("card_accuracy_verified"), f"{overall_win:.0f}%" if not math.isnan(overall_win) else "—", positive=(not math.isnan(overall_win) and overall_win >= 50)), unsafe_allow_html=True)
    if not demo:
        st.markdown(f"**{tr('audit_group_header')}**")
        st.dataframe(pd.DataFrame([{
            tr("audit_group_col_group"): tr(f"audit_group_{k}"),
            tr("audit_group_col_n"): len(g),
            tr("audit_group_col_win"): (100.0 * g["outcome"].mean() if len(g) else float("nan")),
        } for k, g in groups.items()]).style.format(
            {tr("audit_group_col_win"): "{:.0f}%"}, na_rep="—"),
            width="stretch", hide_index=True)
        st.caption(tr("audit_group_note"))

    if not done.empty:
        st.markdown(f"#### {tr('winrate_over_time')}")
        wr = (done.assign(week=done["rec_date"].dt.to_period("W").dt.start_time)
                  .groupby("week")["outcome"].mean().mul(100).round(1))
        st.bar_chart(wr.rename(tr("winrate_col")))

    # Say plainly that the learner is frozen — otherwise flat weights read as a bug.
    if not ENABLE_LEGACY_WEIGHT_LEARNING and not demo:
        st.info(tr("legacy_frozen"))
        try:
            with get_conn() as _c:
                _sh = _c.execute("SELECT created_at, n_picks, proposed FROM shadow_weights "
                                 "ORDER BY id DESC LIMIT 1").fetchone()
        except Exception:
            _sh = None
        if _sh:
            try:
                _prop = json.loads(_sh[2] or "{}")
                _txt = ", ".join(f"{tr('factor_' + k)} {v:.0%}" for k, v in _prop.items())
                st.caption(tr("legacy_shadow_last", when=str(_sh[0])[:10], n=_sh[1], w=_txt))
            except Exception:
                pass

    wh = get_weight_history(demo=demo)
    if len(wh) >= 2:
        st.markdown(f"#### {tr('kpi_weight_evolution')}")
        plot = wh.copy()
        plot["update_date"] = pd.to_datetime(plot["update_date"], errors="coerce")
        long = (plot.melt(id_vars="update_date", value_vars=FACTORS,
                          var_name="factor", value_name="weight")
                    .dropna(subset=["update_date"]))
        # Altair lets us force the x-axis to show the DATE only (not 6AM/6PM ticks).
        # width="container" keeps it responsive without the deprecated container flag.
        chart = (
            alt.Chart(long)
            .mark_line()
            .encode(
                x=alt.X("update_date:T", axis=alt.Axis(format="%Y-%m-%d", title=None)),
                y=alt.Y("weight:Q", axis=alt.Axis(title=None)),
                color=alt.Color("factor:N", legend=alt.Legend(title=None)),
            )
            .properties(height=320, width="container")
        )
        st.altair_chart(chart)

    # --- Historical Performance: live return of every logged mock-portfolio pick ---
    if demo:
        # The demo only simulates accuracy and weight history; the sections below are
        # live-only and are not shown against simulated data.
        st.caption(tr("demo_sections_hidden"))
        return
    st.markdown(f"#### {tr('historical_performance')}")
    mp = get_mock_portfolio()
    if mp.empty:
        st.caption(tr("no_portfolio_picks"))
        render_model_lab()     # independent of the mock portfolio
        return
    mp["date"] = pd.to_datetime(mp["timestamp"], errors="coerce")
    # Join key = the pick's AS-OF date (recommendations are stored under price_date);
    # scan date only for legacy rows that predate it. Joining on scan date silently
    # dropped the levels of every weekend / pre-open pick.
    _asof = pd.to_datetime(mp["price_date"], errors="coerce") if "price_date" in mp.columns \
        else pd.Series(pd.NaT, index=mp.index)
    mp["asof"] = _asof.fillna(mp["date"])
    one_per = st.checkbox(tr("audit_one_per_stock"), value=True)

    if one_per:
        # one row per stock: anchor on its FIRST recommendation (so return reflects the
        # full development since the engine first flagged it) and count how often picked
        view = mp.sort_values("date").drop_duplicates("ticker", keep="first").copy()
        view["times"] = view["ticker"].map(mp.groupby("ticker").size()).astype(int)
    else:
        view = mp.head(40).copy()

    uniq = list(view["ticker"].unique())
    if update_prices:
        # SINGLE bulk request for every unique ticker — replaces the per-ticker fetch
        # storm that was tripping Yahoo's rate limiter and crashing the app. Tuple:
        # the function is cached (5 min), so the argument must be hashable.
        prices = _bulk_latest_close(tuple(uniq))
    else:
        prices = {t: float("nan") for t in uniq}   # checkbox off -> leave prices blank
    view["current"] = view["ticker"].map(prices)
    view["return_pct"] = (view["current"] / view["recommendation_price"] - 1.0) * 100.0
    view["date_str"] = view["date"].dt.date.astype(str)
    view["name"] = view["name"].fillna("")   # older rows logged before names were stored
    reason_map = {"Top Growth": tr("reason_growth"), "Top Dividend": tr("reason_dividend")}
    view["reason"] = view["reason"].map(lambda x: reason_map.get(x, x))

    # Merge the trade levels recorded at recommendation time (recommendations table)
    # onto the portfolio rows (ticker + calendar day), so the audit shows what the
    # engine SAID at the time — the raw material for judging the levels later.
    try:
        recs = get_recommendations()
        if not recs.empty and "target_level" in recs.columns:
            recs = recs.assign(date_key=recs["rec_date"].dt.date)[
                ["ticker", "date_key", "entry_lo", "entry_hi", "target_level", "stop_level"]
            ].drop_duplicates(subset=["ticker", "date_key"], keep="first")
            view = view.assign(date_key=view["asof"].dt.date).merge(
                recs, on=["ticker", "date_key"], how="left")
    except Exception as e:
        logger.warning("audit level merge skipped: %s", e)
    for c in ("entry_lo", "entry_hi", "target_level", "stop_level"):
        if c not in view.columns:
            view[c] = float("nan")
    view["entry_disp"] = [
        "—" if (math.isnan(safe_float(lo)) or math.isnan(safe_float(hi)))
        else f"{safe_float(lo):,.2f}–{safe_float(hi):,.2f}"
        for lo, hi in zip(view["entry_lo"], view["entry_hi"])]

    ret_col = tr("col_return_pct")
    rec_col, cur_col = tr("col_rec_price"), tr("col_current_price")
    if one_per:
        view = view.sort_values("return_pct", ascending=False, na_position="last")
        disp = view[["date_str", "ticker", "name", "reason", "times",
                     "recommendation_price", "current", "return_pct",
                     "entry_disp", "target_level", "stop_level"]].rename(columns={
            "date_str": tr("col_first_rec"), "ticker": tr("col_ticker"), "name": tr("col_company"),
            "reason": tr("col_reason"), "times": tr("col_times"),
            "recommendation_price": rec_col, "current": cur_col, "return_pct": ret_col,
            "entry_disp": tr("col_entry"), "target_level": tr("col_target"),
            "stop_level": tr("col_stop")})
    else:
        disp = view[["date_str", "ticker", "name", "reason",
                     "recommendation_price", "current", "return_pct",
                     "entry_disp", "target_level", "stop_level"]].rename(columns={
            "date_str": tr("col_date"), "ticker": tr("col_ticker"), "name": tr("col_company"),
            "reason": tr("col_reason"),
            "recommendation_price": rec_col, "current": cur_col, "return_pct": ret_col,
            "entry_disp": tr("col_entry"), "target_level": tr("col_target"),
            "stop_level": tr("col_stop")})

    def _style_returns(series):
        styles = []
        for v in series:
            if pd.isna(v): styles.append("")
            elif v >= 0: styles.append("color: #16a34a; font-weight: 600;")  # green winner
            else: styles.append("color: #dc2626; font-weight: 600;")          # red loser
        return styles

    styled = (disp.style
              .apply(_style_returns, subset=[ret_col])
              .format({rec_col: "{:,.2f}", cur_col: "{:,.2f}", ret_col: "{:+.2f}%",
                       tr("col_target"): "{:,.2f}", tr("col_stop"): "{:,.2f}"}, na_rep="—"))
    st.dataframe(styled, width="stretch", hide_index=True)
    st.caption(tr("audit_one_per_note") if one_per else tr("historical_perf_note"))
    render_model_lab()

    if update_prices:
        unpriced = sorted({t for t in uniq if pd.isna(prices.get(t, float("nan")))})
        if unpriced and len(unpriced) == len(uniq):
            # EVERY ticker came back empty. Previously this rendered as a quiet
            # caption listing all of them, so the blank Current Price / Return
            # columns looked like a bug in the table rather than a failed fetch.
            # The result is cached for 5 minutes, so a single throttled request
            # keeps the columns blank until it expires or Force Data Refresh runs.
            st.warning(tr("prices_all_unavailable", n=len(uniq)))
        elif unpriced:
            st.caption(tr("prices_unavailable", tickers=", ".join(unpriced)))
    else:
        st.caption(tr("prices_skipped"))

def _sell_pill(verdict: str) -> str:
    cls = {"high": "qc-sell", "mixed": "qc-hold", "low": "qc-buy"}.get(verdict, "qc-hold")
    return f'<span class="qc-pill {cls}">{tr(f"sell_verdict_{verdict}")}</span>'

def _render_sell_detail(data: dict) -> None:
    """Full single-ticker sell breakdown (reused by the optional drill-down)."""
    cur = (data["currency"] + " ") if data["currency"] else ""
    comp_txt = "—" if math.isnan(data["composite"]) else f"{data['composite']:.0f}/100"
    price_txt = "—" if math.isnan(data["price"]) else f"{cur}{data['price']:,.2f}"
    c = st.columns([2, 1, 1])
    c[0].markdown(
        f'<div class="qc-card"><span class="qc-ticker">{data["ticker"]}</span> {_sell_pill(data["verdict"])}'
        f'<br><span class="qc-sub">{data["name"]}</span></div>',
        unsafe_allow_html=True,
    )
    c[1].markdown(metric_card(tr("sell_pressure"), comp_txt,
                              positive=(not math.isnan(data["composite"]) and data["composite"] < SELL_LOW)),
                  unsafe_allow_html=True)
    c[2].markdown(metric_card(tr("price_label"), price_txt), unsafe_allow_html=True)

    # --- why this is a sell: exact weighted-contribution decomposition ---
    st.markdown(f"#### {tr('sell_why_header')}")
    scored = [(k, float(s)) for k, s, _ in data["signals"] if s is not None]
    if not scored:
        st.caption(tr("sell_no_signal_data"))
    else:
        den = sum(SELL_KPI_WEIGHTS[k] for k, _ in scored) or 1.0
        sb = pd.DataFrame([{
            "label": tr(f"kpi_{k}"), "score": s, "weight": SELL_KPI_WEIGHTS[k],
            "contribution": SELL_KPI_WEIGHTS[k] * s / den,    # contributions sum to the composite
        } for k, s in scored])
        total = float(sb["contribution"].sum())
        sb_sorted = sb.sort_values("contribution", ascending=False)

        chart = (alt.Chart(sb_sorted).mark_bar()
                 .encode(
                     x=alt.X("contribution:Q", axis=alt.Axis(title=tr("sell_why_axis"))),
                     y=alt.Y("label:N", sort="-x", axis=alt.Axis(title=None)),
                     color=alt.Color("label:N", legend=None),
                     tooltip=[alt.Tooltip("label:N", title=tr("col_kpi")),
                              alt.Tooltip("score:Q", title=tr("col_score"), format=".0f"),
                              alt.Tooltip("weight:Q", title=tr("col_weight"), format=".0%"),
                              alt.Tooltip("contribution:Q", title=tr("col_contribution"), format=".1f")])
                 .properties(height=210, width="container"))
        st.altair_chart(chart)
        st.caption(tr("sell_why_caption"))

        show = (sb_sorted.assign(share=lambda d: (d["contribution"] / total * 100.0) if total else float("nan"))
                [["label", "score", "weight", "contribution", "share"]]
                .rename(columns={"label": tr("col_kpi"), "score": tr("col_score"),
                                 "weight": tr("col_weight"), "contribution": tr("col_contribution"),
                                 "share": tr("col_share")}))
        st.dataframe(show.style.format({tr("col_score"): "{:.0f}", tr("col_weight"): "{:.0%}",
                     tr("col_contribution"): "{:.1f}", tr("col_share"): "{:.0f}%"}, na_rep="—"),
                     width="stretch", hide_index=True)

        top = sb_sorted.iloc[0]
        if len(sb_sorted) >= 2:
            second = sb_sorted.iloc[1]
            share2 = ((top["contribution"] + second["contribution"]) / total * 100.0) if total else float("nan")
            st.info(tr("sell_why_rationale", d1=top["label"], s1=f"{top['score']:.0f}",
                       d2=second["label"], s2=f"{second['score']:.0f}", share=f"{share2:.0f}"))
        else:
            share1 = (top["contribution"] / total * 100.0) if total else float("nan")
            st.info(tr("sell_why_rationale_one", d1=top["label"], s1=f"{top['score']:.0f}",
                       share=f"{share1:.0f}"))

        skipped = [tr(f"kpi_{k}") for k, s, _ in data["signals"] if s is None]
        if skipped:
            st.caption(tr("sell_not_scored", items=", ".join(skipped)))

    st.markdown(f"#### {tr('sell_breakdown_title')}")

    readings = [{
        tr("col_kpi"): tr(f"kpi_{k}"),
        tr("col_signal"): "—" if s is None else f"{s:.0f}",
        tr("col_reading"): detail,
    } for k, s, detail in data["signals"]]
    st.dataframe(pd.DataFrame(readings), width="stretch", hide_index=True)

    st.markdown(f"#### {tr('sell_recent_downgrades')}")
    if data["changes"]:
        cdf = pd.DataFrame(data["changes"]).rename(columns={
            "date": tr("col_date"), "firm": tr("col_firm"),
            "from": tr("col_from"), "to": tr("col_to"), "action": tr("col_action"),
        })
        st.dataframe(cdf, width="stretch", hide_index=True)
    else:
        st.caption(tr("sell_no_analyst"))

    st.markdown(f"#### {tr('sell_insider_activity')}")
    ins = data["insider"]
    if ins["available"] and ins["rows"]:
        idf = pd.DataFrame(ins["rows"]).rename(columns={
            "date": tr("col_date"), "insider": tr("col_insider"),
            "transaction": tr("col_transaction"), "shares": tr("col_shares"), "value": tr("col_value"),
        })
        st.dataframe(idf, width="stretch", hide_index=True)
    else:
        st.caption(tr("sell_no_insider"))

def _parse_portfolio_input(pasted: str, uploaded) -> list:
    """Build a deduped ticker list from a comma/space/newline text area and/or a CSV
    whose 'Ticker' or 'Symbol' column (case-insensitive) holds the symbols."""
    tickers = []
    if pasted:
        tickers += [s.strip().upper() for s in re.split(r"[,\n;\s]+", pasted) if s.strip()]
    if uploaded is not None:
        try:
            cdf = pd.read_csv(uploaded)
            col = next((c for c in cdf.columns if str(c).strip().lower() in ("ticker", "symbol")), None)
            if col is None:
                st.warning(tr("sell_csv_nocol"))
            else:
                tickers += [str(x).strip().upper() for x in cdf[col].dropna().tolist() if str(x).strip()]
        except Exception:
            st.warning(tr("sell_csv_error"))
    return list(dict.fromkeys(t for t in tickers if t))   # dedupe, preserve order

def render_sell_signals() -> None:
    st.markdown(f"### {tr('sell_header')}")
    st.caption(tr("sell_disclaimer"))
    st.caption(tr("sell_privacy_note"))

    # Cross-page handoff (e.g. "Review holdings" on My Trades) arrives in a PLAIN
    # session key, consumed here just before the widget is built. Writing straight to
    # "sell_paste" from another page doesn't survive: with st.navigation the paste box
    # isn't rendered while you're elsewhere, and Streamlit garbage-collects widget
    # state for widgets that aren't on screen — which is why the autofill was lost.
    _pre = st.session_state.pop("sell_prefill", None)
    if _pre:
        st.session_state["sell_paste"] = _pre

    pasted = st.text_area(tr("sell_paste_label"), key="sell_paste", placeholder="AAPL, MSFT, NVDA")

    # Searchable instrument picker: type a ticker, an English name or a Japanese name.
    # Options come from the curated tables plus every name your uploaded trade history
    # or last scan introduced, so it covers stocks outside the app's universe too.
    picked: list = []
    if pf is not None:
        _idx = pf.instrument_index(COMPANY_NAMES, INSTRUMENT_JA,
                                   trades=st.session_state.get("pf_trades"),
                                   results=st.session_state.get("results"))
        if _idx:
            _labels = pf.instrument_labels(_idx)
            _chosen = st.multiselect(tr("sell_pick_label"), _labels, key="sell_picks",
                                     placeholder=tr("sell_pick_placeholder"))
            picked = [t for t in (pf.label_to_ticker(l) for l in _chosen) if t]
            st.caption(tr("sell_pick_note", n=len(_labels)))

    uploaded = st.file_uploader(tr("sell_upload_label"), type=["csv"], key="sell_csv")

    # Pasted text, picker choices and an uploaded CSV all feed the same list.
    tickers = _parse_portfolio_input(pasted, uploaded)
    tickers = list(dict.fromkeys([t for t in (list(tickers) + picked) if t]))
    if tickers:
        # Stored in session_state only — never written to the SQLite DB — so each
        # user's portfolio stays private in a shared/multi-user deployment.
        st.session_state["portfolio_tickers"] = tickers

    portfolio = st.session_state.get("portfolio_tickers", [])
    if portfolio:
        preview = ", ".join(portfolio[:20]) + (" …" if len(portfolio) > 20 else "")
        st.caption(tr("sell_loaded", n=len(portfolio), tickers=preview))

    if st.button(tr("sell_scan_btn"), width="stretch", disabled=not portfolio):
        rows = []
        details = {}
        # OPTIMISATION: one bulk yf.download for every name's history up front, so
        # the per-ticker loop reuses it instead of making a history request each.
        with st.spinner(tr("sell_bulk_fetch", total=len(portfolio))):
            histories = get_histories(portfolio, period="1y")
        prog = st.progress(0.0, text=tr("sell_scan_progress", done=0, total=len(portfolio)))
        for i, tk in enumerate(portfolio, start=1):
            try:
                data = analyze_sell_signals(tk, hist=histories.get(tk))
            except Exception:
                data = None
            if data is not None:
                rows.append({"ticker": data["ticker"], "price": data["price"],
                             "composite": data["composite"],
                             "verdict": tr(f"sell_verdict_{data['verdict']}")})
                details[data["ticker"]] = data   # keep the full breakdown for the drill-down
            else:
                rows.append({"ticker": tk, "price": float("nan"),
                             "composite": float("nan"), "verdict": tr("sell_verdict_na")})
            prog.progress(i / len(portfolio), text=tr("sell_scan_progress", done=i, total=len(portfolio)))
        prog.empty()
        st.session_state["portfolio_results"] = rows
        st.session_state["portfolio_details"] = details

    results = st.session_state.get("portfolio_results", [])
    if not results:
        st.info(tr("sell_need_portfolio"))
        return

    rdf = pd.DataFrame(results).sort_values(by="composite", ascending=False, na_position="last")
    comp_col, price_col = tr("sell_pressure"), tr("col_current_price")
    verdict_col, tick_col = tr("col_verdict"), tr("col_ticker")
    disp = rdf.rename(columns={"ticker": tick_col, "price": price_col, "composite": comp_col, "verdict": verdict_col})

    def _style_pressure(series):
        out = []
        for v in series:
            if pd.isna(v): out.append("")
            elif v >= SELL_HIGH: out.append("color: #dc2626; font-weight: 600;")   # elevated -> red
            elif v < SELL_LOW: out.append("color: #16a34a; font-weight: 600;")      # low -> green
            else: out.append("color: #d97706; font-weight: 600;")                   # mixed -> amber
        return out

    styled = (disp.style.apply(_style_pressure, subset=[comp_col])
              .format({price_col: "{:,.2f}", comp_col: "{:.0f}"}, na_rep="—"))
    st.dataframe(styled, width="stretch", hide_index=True)

    # Drill-down: show the full breakdown computed during the scan — no re-fetch, so it
    # works for any number of stocks (re-fetching here got rate-limited after a big scan).
    with st.expander(tr("sell_detail_expander")):
        choices = [r["ticker"] for r in results]
        sel = st.selectbox(tr("sell_detail_select"), choices, key="sell_detail_pick")
        detail = st.session_state.get("portfolio_details", {}).get(sel)
        if detail is None and sel:        # fallback (e.g. results from an older session)
            with st.spinner(tr("sell_spinner", ticker=sel)):
                try:
                    detail = analyze_sell_signals(sel)
                except Exception:
                    detail = None   # a raised (rate-limited) sub-fetch -> show the notice
        if detail is None:
            st.warning(tr("sell_no_data", ticker=sel))
        else:
            _render_sell_detail(detail)

# ----------------------------------------------------------------------------
# Help / About tab — in-app documentation, bilingual (follows the language menu).
# Content lives here (not in TRANSLATIONS) because it's long-form prose per
# language, not templated UI strings.
# ----------------------------------------------------------------------------
_HELP_SECTIONS = {
    "en": [
        ("🚀 What is this app?",
         """The **Alpha Quant Engine** scans a global stock universe (US, Japan, Europe, China), scores
every name on **six KPI factors**, and turns the weighted composite into a BUY / HOLD / SELL call.
It is a *screening and research* tool: it surfaces candidates and shows its work — it is **not
financial advice**, and its signals are based on free, sometimes-delayed data sources."""),
        ("🧭 Quick start",
         """1. In the sidebar, pick the **regions** to scan and leave **Quick scan** on (first 10 names
per region — fast, and gentle on the data sources).
2. Press **Run scan**. Results populate the Top Selections, Regional, Category, Themes and Deep-Dive tabs.
3. Open **Deep-Dive Analysis** on any name to see *exactly* why it scored what it did — an exact
weighted-contribution breakdown, plus the raw evidence behind every factor.
4. Use the **Deep Scan** tab to hunt outside the curated universe, and **promote** winners so they
ride along with your daily scans.
5. The engine logs every scored name and measures what happened afterwards in the **Model Lab**.
Automatic weight re-tuning is currently **paused** (shadow mode): weights stay fixed while that
evidence builds, and the paused learner only records what it *would* have changed."""),
        ("📊 The six KPI factors",
         """Every stock gets a 0–100 score per factor; the composite is the weighted average.
- **Momentum** — price vs. its 50-day average, MACD direction, and the **3-month return relative to the home benchmark** (S&P 500, Nikkei 225, etc.). A stock only scores highly if it is trending up *and* beating its market — so a broad rally no longer lifts everything.
- **Value** — trailing P/E mapped to a score (cheaper = higher), plus a dividend-yield bonus.
- **Technical** — RSI positioning and Bollinger %B; rewards healthy, mid-band setups over
overbought/oversold extremes.
- **Hype** — volume-breakout detection vs. a 30-day baseline, boosted by live retail/news buzz
(Reddit, GDELT), the Yahoo! Japan forum poll for Japanese names (experimental, off by default), and a short-squeeze modifier.
- **Quality** — return on equity (profitability). Missing data scores neutral, never penalised.
- **Theme** *(new)* — industry-rotation strength: the average momentum of the *other* scanned members
of the stock's theme basket (AI, Semis, Defense, Clean Energy…), damped so a hot industry helps a
name without drowning out its own signals. Stocks without a theme score a neutral 50.

**Calls:** composite ≥ 65 → BUY · < 45 → SELL · otherwise HOLD."""),
        ("🔁 How the engine learns (walk-forward loop)",
         """Each full scan logs the day's Top-3 Growth and Top-3 Dividend picks with a snapshot of their
factor scores. Once a pick is **14 days** old, the engine checks whether it beat its home-market
benchmark (S&P 500 for US names, Nikkei for Japan, etc.). Factors that scored highly on *winners*
get nudged **up**; factors that scored highly on *losers* get nudged **down** — with a floor so no
factor ever dies completely. The **Systems Audit** tab charts the weight evolution and win rate.

**Currently paused (shadow mode).** This loop learns from just six hand-picked names with a win/lose
outcome, so it is the weakest evidence in the app. It still runs and records the weights it *would*
set (shown in the Systems Audit tab), but production weights stay fixed until the **Model Lab** —
which measures every scanned name at 5, 20 and 60 trading sessions — supports a change.
Set ENABLE_LEGACY_WEIGHT_LEARNING = True in app.py to resume it."""),
        ("🔬 Deep Scan & promotions",
         """The Deep Scan is a two-stage funnel, available for **four markets**: US (~215 names),
Europe (~145), Japan (~97) and China (~84). **Stage 1** downloads prices for the whole list in one
bulk request and ranks them on a pure price screen (momentum blend, volume surge, 52-week-high
proximity, with a falling-knife cap). **Stage 2** runs full fundamental scoring on the top 25
finalists only, which is what keeps the request count bounded. Each market's list is curated primary
listings and can be refreshed from Yahoo's live screener with the 🔄 button.

The best finalists can be **promoted** into your main daily scan — up to **US 8 / Europe 5 / JP 5 /
CN 3**. Promoted names ride along on every scan (including Quick scans), show a ⭐ in the tables, and
rotate each time you re-run and promote. They are the data-driven counterweight to the fixed
universe, which stays deliberately stable because most of its names are the constituents the Themes
baskets are measured on. On cloud deployments the promotion table resets on redeploy — paste the
offered `PROMOTED_TICKERS` snippet into `config.py` to make it stick."""),
        ("📡 Data sources & limitations",
         """Prices and fundamentals come from **Yahoo Finance** (with a free Stooq fallback for US names and
an optional FMP key for fundamentals). Sentiment comes from **Reddit**, **GDELT news**, and the
**Yahoo! Japan forum poll** for Japanese tickers (experimental and off by default — its page parser is not yet verified against Yahoo's live page). All sources are free/unofficial: they can be
delayed, throttled, or blocked, and every fetch is wrapped so a dead source degrades a signal to
neutral instead of crashing a scan. If a whole scan fails, it is almost always a temporary Yahoo
rate limit — wait a few minutes and use Quick scan."""),
        ("⚠️ Disclaimer",
         """This app is an educational screening tool. Scores are mechanical transformations of public,
sometimes-delayed data; they can be wrong, stale, or based on incomplete inputs. Nothing here is a
recommendation to buy or sell any security. Always do your own research and consider consulting a
licensed financial advisor before trading."""),
    ],
    "ja": [
        ("🚀 このアプリについて",
         """**Alpha Quant Engine** は、グローバル株式ユニバース（米国・日本・欧州・中国）をスキャンし、
各銘柄を **6つのKPIファクター** で採点、加重平均のコンポジットスコアから BUY / HOLD / SELL を
判定します。これは*スクリーニング・リサーチ*ツールであり、**投資助言ではありません**。
シグナルは無料（遅延あり）のデータソースに基づきます。"""),
        ("🧭 クイックスタート",
         """1. サイドバーでスキャンする**地域**を選び、**クイックスキャン**はONのまま（各地域の先頭10銘柄のみ・高速）。
2. **スキャン実行**を押すと、トップ銘柄・地域別・カテゴリ・テーマ・詳細分析の各タブに結果が反映されます。
3. **詳細分析**タブで銘柄を選ぶと、スコアの根拠（ファクター別の正確な寄与分解と裏付けデータ）を確認できます。
4. **ディープスキャン**タブで通常ユニバース外を探索し、勝者を**プロモート**すると日次スキャンに同乗します。
5. エンジンは評価した全銘柄を記録し、その後の実績を**モデルラボ**で測定します。重みの自動調整は現在**停止中**（シャドーモード）で、根拠が蓄積されるまで重みは固定され、停止中の学習ループは変更していたはずの内容を記録するだけです。"""),
        ("📊 6つのKPIファクター",
         """各銘柄はファクターごとに0–100点、コンポジットはその加重平均です。
- **モメンタム** — 50日移動平均との乖離、MACDの向き、そして**本国ベンチマーク（S&P500、日経225など）に対する3か月相対リターン**。上昇トレンドにあり、かつ市場を上回っている銘柄だけが高評価となるため、相場全体の上昇ですべての銘柄が高得点になることはありません。
- **バリュー** — 実績PER（割安ほど高得点）＋配当利回りボーナス。
- **テクニカル** — RSIの位置とボリンジャー%B。過熱・売られすぎより健全な中間帯を評価。
- **ハイプ** — 30日ベースライン比の出来高ブレイクアウトに、Reddit・GDELTニュース・
Yahoo!掲示板「みんなの評価」（日本株・試験運用で既定はオフ）・踏み上げ（ショートスクイーズ）補正を加味。
- **クオリティ** — ROE（収益性）。データ欠損は中立扱いで減点しません。
- **テーマ**（新設）— 業種ローテーションの強さ。同じテーマバスケット（AI・半導体・防衛・
クリーンエネルギー等）の*他の*スキャン銘柄の平均モメンタムを減衰付きで反映します。
テーマなしの銘柄は中立の50点です。

**判定:** コンポジット 65以上 → BUY ・ 45未満 → SELL ・ それ以外 → HOLD"""),
        ("🔁 エンジンの学習（ウォークフォワード）",
         """フルスキャンごとに、その日のトップ3グロース／トップ3配当ピックをファクタースコア付きで記録します。
**14日**経過後、各ピックが自国市場ベンチマーク（米国株はS&P 500、日本株は日経平均など）に勝ったかを
判定し、勝者で高得点だったファクターの重みを**引き上げ**、敗者で高得点だったファクターを**引き下げ**
ます（下限付き）。**システム監査**タブで重みの推移と勝率を確認できます。新設のテーマファクターは
12%の小さな重みから始まり、このループで実力に応じて調整されます。

**現在は停止中（シャドーモード）です。** このループは手選びの6銘柄の勝敗だけから学習するため、アプリ内で最も
根拠の弱いデータです。引き続き動作し、設定していたはずの重みを記録します（システム監査タブに表示）が、
5・20・60営業日で全スキャン銘柄を測定する**モデルラボ**が変更を裏付けるまで本番の重みは固定されます。
再開するには app.py の ENABLE_LEGACY_WEIGHT_LEARNING を True にしてください。"""),
        ("🔬 ディープスキャンとプロモート",
         """**4市場**（米国 約215銘柄・欧州 約145・日本 約97・中国 約84）に対応した2段階ファネルです。
**ステージ1**はリスト全体の株価を一括取得し、価格スクリーン（モメンタムブレンド・出来高サージ・
52週高値近接度・急落キャップ）でランク付け。**ステージ2**は上位25銘柄のみファンダメンタルズを含む
フル採点を行い、これにより通信量を抑えています。各市場のリストは厳選した主要上場銘柄で、🔄ボタンで
Yahooのスクリーナーから最新銘柄を取り込めます。

上位ファイナリストは**米8・欧州5・日5・中3**の枠でメインスキャンに**プロモート**できます。
プロモート銘柄はクイックスキャンを含む毎回のスキャンに同乗し、表では⭐が付き、再実行のたびに
入れ替わります。固定ユニバースはテーマ分析の構成銘柄でもあるため意図的に安定させており、
プロモート枠がその対となる「データ駆動」の層です。クラウド環境では再デプロイでプロモートが消えるため、
表示される `PROMOTED_TICKERS` スニペットを `config.py` に貼り付けると永続化できます。"""),
        ("📡 データソースと制限",
         """株価・ファンダメンタルズは **Yahoo Finance**（米国株はStooqフォールバック、任意でFMP APIキー）、
センチメントは **Reddit**・**GDELTニュース**・日本株は **Yahoo!掲示板「みんなの評価」**（試験運用・既定はオフ。ページ解析はYahoo!の実ページで未検証）を利用します。
いずれも無料・非公式のソースで、遅延・制限・ブロックの可能性があります。全取得処理はフェイルセーフで、
ソース停止時はシグナルが中立に劣化するだけでスキャンは継続します。スキャン全体が失敗する場合は
ほぼYahooの一時的なレート制限です。数分待ってクイックスキャンをお試しください。"""),
        ("⚠️ 免責事項",
         """本アプリは教育目的のスクリーニングツールです。スコアは公開データ（遅延あり）の機械的な変換であり、
誤り・陳腐化・入力不足の可能性があります。特定の証券の売買を推奨するものではありません。
投資判断はご自身の調査に基づき、必要に応じて有資格のファイナンシャルアドバイザーにご相談ください。"""),
    ],
}


def render_help() -> None:
    """In-app documentation. First section open by default; the rest collapsed."""
    sections = _HELP_SECTIONS.get(get_lang(), _HELP_SECTIONS["en"])
    for i, (title, body) in enumerate(sections):
        with st.expander(title, expanded=(i == 0)):
            st.markdown(body)


# ----------------------------------------------------------------------------
# Main Application Controller Setup — st.navigation page structure.
#
# The old single-script st.tabs(10) bar had two costs: every widget click
# re-rendered ALL ten tabs (Audit queries, Sell scanner, everything), and the
# bar itself scrolled horizontally, worse in Japanese. st.navigation renders
# only the selected page per rerun and groups the app into four sections in the
# sidebar. Page url_paths are language-independent, so switching 言語 keeps you
# on the same page; _PAGES lets other modules jump programmatically
# (st.switch_page) — e.g. the Regional table's "Open full analysis" button.
# Requires Streamlit >= 1.36 (the app already uses >= 1.35 APIs elsewhere).
# ----------------------------------------------------------------------------
_PAGES: dict[str, "st.Page"] = {}


def _session_results() -> list[dict]:
    return st.session_state.get("results", [])


# Page wrappers: st.Page callables take no arguments, so each page pulls the
# shared scan results (and the audit toggle) from session state itself.
def page_top() -> None: render_daily_top_3(_session_results())
def page_regional() -> None: render_global_sectors(_session_results())
def page_category() -> None: render_category_views(_session_results())
def page_themes() -> None: render_themes(_session_results())
def page_deep_dive() -> None: render_deep_dive(_session_results())
def page_deep_scan() -> None: render_deep_scan()
def page_us() -> None: render_us_conviction(_session_results())
def page_audit() -> None: render_engine_audit(st.session_state.get("_update_prices", True))
def page_sell() -> None: render_sell_signals()
def page_portfolio() -> None:
    render_portfolio()


def setup_coverage() -> dict:
    """Read-only instrumentation coverage across the stored ledger.

    Tells the Model Lab how much of the Early Setup evidence was computed on full
    inputs. A bucket built mostly on rows lacking volume or a benchmark is measuring
    a different (weaker) detector than one built on complete data.
    """
    empty = {"total": 0, "volume_pct": 0.0, "benchmark_pct": 0.0,
             "full_year_pct": 0.0, "avg_coverage_pct": 0.0}
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT setup_quality FROM observations "
                "WHERE setup_score IS NOT NULL AND setup_quality IS NOT NULL").fetchall()
    except Exception as e:
        logger.warning("setup coverage read skipped: %s", e)
        return empty
    quality = []
    for row in rows:
        try:
            q = json.loads(row[0] or "{}")
        except Exception:
            q = {}
        if q:
            quality.append(q)
    if not quality:
        return empty
    n = len(quality)
    return {
        "total": n,
        "volume_pct": 100.0 * sum(bool(q.get("volume_available")) for q in quality) / n,
        "benchmark_pct": 100.0 * sum(bool(q.get("benchmark_available")) for q in quality) / n,
        "full_year_pct": 100.0 * sum(bool(q.get("price_history_full_year")) for q in quality) / n,
        "avg_coverage_pct": sum(float(q.get("coverage_pct", 0.0)) for q in quality) / n,
    }


def render_early_setups(results: list[dict]) -> None:
    """Current-scan Early Setup watchlist.

    These are NOT buy recommendations. The detector is measurement-only and still
    unvalidated: the Model Lab is accumulating forward outcomes to test whether the
    score precedes excess return at all. The page exists so the signal can be watched
    while that evidence builds — deliberately separate from the Top Selections page,
    which carries the production BUY/HOLD/SELL calls.
    """
    if not results:
        st.info(tr("need_run_engine"))
        return
    scored = [r for r in results if r.get("setup_state")]
    if not scored:
        st.info(tr("setup_page_none"))
        return

    st.warning(tr("setup_page_disclaimer"))
    quality_rows = [r.get("setup_data_quality") or {} for r in scored]
    if any(quality_rows):
        n_q = len(quality_rows)
        q1, q2, q3, q4 = st.columns(4)
        q1.metric(tr("setup_quality_coverage"),
                  f"{sum(float(q.get('coverage_pct', 0)) for q in quality_rows) / n_q:.0f}%")
        q2.metric(tr("setup_quality_volume"),
                  f"{100 * sum(bool(q.get('volume_available')) for q in quality_rows) / n_q:.0f}%")
        q3.metric(tr("setup_quality_benchmark"),
                  f"{100 * sum(bool(q.get('benchmark_available')) for q in quality_rows) / n_q:.0f}%")
        q4.metric(tr("setup_quality_full_year"),
                  f"{100 * sum(bool(q.get('price_history_full_year')) for q in quality_rows) / n_q:.0f}%")

    # --- filters ----------------------------------------------------------
    states = [s for s in SETUP_STATES if any(r.get("setup_state") == s for r in scored)]
    default = [s for s in ("EARLY WATCH", "SETUP STRENGTHENING") if s in states]
    f1, f2 = st.columns(2)
    chosen = f1.multiselect(tr("setup_page_filter"), states, default=default or states,
                            key="setup_states")
    regions = sorted({r.get("region", "") for r in scored if r.get("region")})
    reg_pick = f2.multiselect(tr("regions_to_scan"), regions, default=regions,
                              key="setup_regions", format_func=region_name)
    f3, f4 = st.columns(2)
    min_score = f3.slider(tr("setup_page_min"), 0, 100, 0, key="setup_min")
    calls = sorted({str(r.get("recommendation", "")) for r in scored if r.get("recommendation")})
    call_pick = f4.multiselect(tr("why_call"), calls, default=calls, key="setup_calls")

    rows = [r for r in scored
            if r.get("setup_state") in chosen
            and r.get("region", "") in reg_pick
            and safe_float(r.get("setup_score"), -1.0) >= min_score
            and str(r.get("recommendation", "")) in call_pick]
    rows.sort(key=lambda r: safe_float(r.get("setup_score"), float("-inf")), reverse=True)
    if not rows:
        st.caption(tr("setup_page_empty_filter"))
        return

    def _c(r, key):
        """Component value, tolerant of a restored snapshot with no components."""
        return safe_float((r.get("setup_components") or {}).get(key), float("nan"))

    df = pd.DataFrame([{
        tr("col_ticker"): r["ticker"],
        tr("col_company"): r.get("name", r["ticker"]),
        tr("col_region"): region_name(r.get("region", "")),
        tr("setup_col_bucket"): safe_float(r.get("setup_score")),
        tr("setup_col_state"): r.get("setup_state"),
        tr("col_overall_score"): safe_float(r.get("composite")),
        tr("why_call"): str(r.get("recommendation", "—")),
        tr("col_momentum_1m"): safe_float(r.get("ret_1m")),
        # the four components that describe WHY it is an early setup
        tr("setup_c_macd"): _c(r, "macd"),
        tr("setup_c_compression"): _c(r, "compression"),
        tr("setup_c_accumulation"): _c(r, "accumulation"),
        tr("setup_c_rel_strength"): _c(r, "rel_strength"),
        tr("setup_col_trigger"): safe_float(r.get("setup_trigger")),
        tr("setup_col_invalidation"): safe_float(r.get("setup_invalidation")),
        tr("setup_col_to_trigger"): safe_float(
            (r.get("setup_metrics") or {}).get("distance_to_trigger_pct")),
        tr("setup_col_to_invalidation"): safe_float(
            (r.get("setup_metrics") or {}).get("distance_to_invalidation_pct")),
        tr("setup_col_risk_range"): safe_float(
            (r.get("setup_metrics") or {}).get("risk_range_pct")),
        tr("setup_col_quality"): safe_float(
            (r.get("setup_data_quality") or {}).get("coverage_pct")),
        tr("setup_col_change"): (tr("setup_change_new") if r.get("setup_is_new")
                                 else tr("setup_change_changed") if r.get("setup_state_changed")
                                 else "—"),
    } for r in rows])
    _num = {tr("setup_col_bucket"): "{:.1f}", tr("col_overall_score"): "{:.1f}",
            tr("col_momentum_1m"): "{:+.1f}%"}
    _num.update({tr(f"setup_c_{k}"): "{:.0f}" for k in
                 ("macd", "compression", "accumulation", "rel_strength")})
    _num.update({tr("setup_col_trigger"): "{:,.2f}",
                 tr("setup_col_invalidation"): "{:,.2f}",
                 tr("setup_col_to_trigger"): "{:+.1f}%",
                 tr("setup_col_to_invalidation"): "{:.1f}%",
                 tr("setup_col_risk_range"): "{:.1f}%",
                 tr("setup_col_quality"): "{:.0f}%"})
    st.dataframe(df.style.format(_num, na_rep="—"), width="stretch", hide_index=True)
    st.caption(tr("setup_page_note"))

    # component breakdown for one name — shows WHICH conditions are improving
    st.markdown(f"#### {tr('setup_page_components')}")
    pick = st.selectbox(tr("setup_page_select"), [r["ticker"] for r in rows],
                        key="setup_pick")
    chosen_row = next((r for r in rows if r["ticker"] == pick), None)
    comps = (chosen_row or {}).get("setup_components") or {}
    if comps:
        cdf = pd.DataFrame([{tr("setup_col_component"): tr(f"setup_c_{k}"),
                             tr("col_score"): safe_float(v)} for k, v in comps.items()])
        cdf = cdf.sort_values(tr("col_score"), ascending=False)
        st.dataframe(cdf.style.format({tr("col_score"): "{:.0f}"}, na_rep="—"),
                     width="stretch", hide_index=True)
        st.caption(tr("setup_page_comp_note"))


def page_early_setups() -> None:
    render_early_setups(st.session_state.get("results") or [])


def page_help() -> None: render_help()



# ----------------------------------------------------------------------------
# My Trades — Rakuten CSV upload, review queue, search, currency toggle
# ----------------------------------------------------------------------------
def _pf_signature(files) -> tuple:
    """Identity of the current upload set: (name, size) per file. Parsing is keyed on
    this, so Streamlit's constant reruns (every widget click) reuse the parsed frame
    instead of re-decoding cp932 and re-parsing every CSV."""
    return tuple(sorted((f.name, getattr(f, "size", 0)) for f in (files or [])))


def _pf_load(files) -> tuple:
    """Parse an upload set -> (combined canonical frame, per-file diagnostics).
    IO + Streamlit-specific bits only; every transformation lives in portfolio.py."""
    frames, diags = [], []
    for f in files or []:
        try:
            f.seek(0)
            raw = pd.read_csv(f, encoding="cp932")      # Rakuten exports are Shift-JIS
        except UnicodeDecodeError:
            f.seek(0)
            raw = pd.read_csv(f, encoding="utf-8-sig")  # tolerate a re-saved file
        except Exception as e:
            diags.append({"file": f.name, "kind": "—", "rows": 0, "note": str(e)[:60]})
            continue
        kind = pf.detect_kind(raw)
        if kind is None:
            diags.append({"file": f.name, "kind": "—", "rows": 0,
                          "note": tr("pf_unknown_layout")})
            continue
        norm = pf.normalize_trades(raw, kind)
        frames.append(norm)
        diags.append({"file": f.name, "kind": kind, "rows": len(norm), "note": ""})
    return pf.combine_trades(frames), diags


def _pf_money(v: float, currency: str) -> str:
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "—"
    return f"${v:,.2f}" if currency == "USD" else f"¥{v:,.0f}"


def render_portfolio() -> None:
    if pf is None:
        st.error(tr("pf_module_missing"))
        return
    st.caption(tr("pf_intro"))

    files = st.file_uploader(tr("pf_upload_label"), type=["csv"],
                             accept_multiple_files=True, key="pf_files")

    # --- session caching -----------------------------------------------------
    # Reparse ONLY when the upload set changes. st.session_state survives reruns, so
    # switching currency, searching, or clicking any button reuses these frames.
    sig = _pf_signature(files)
    if files and sig != st.session_state.get("pf_sig"):
        with st.spinner(tr("pf_parsing")):
            df, diags = _pf_load(files)
        st.session_state["pf_sig"] = sig
        st.session_state["pf_trades"] = df
        st.session_state["pf_diags"] = diags
    elif not files and st.session_state.get("pf_sig") and st.session_state.get("pf_clear_on_empty", True):
        pass   # keep the last upload in memory after the widget is cleared

    df = st.session_state.get("pf_trades")
    if df is None or df.empty:
        st.info(tr("pf_no_data"))
        return

    for d in st.session_state.get("pf_diags", []):
        if d["kind"] == "—":
            st.warning(f"{d['file']}: {d['note']}")
    st.caption(tr("pf_loaded", files=len(st.session_state.get("pf_diags", [])),
                  rows=len(df), symbols=int(df["symbol"].nunique())))

    # --- currency toggle -----------------------------------------------------
    currency = st.radio(tr("pf_currency"), ["JPY", "USD"], horizontal=True, key="pf_ccy")
    val_col = "value_usd" if currency == "USD" else "value_jpy"

    # --- OPEN POSITIONS: the real sell-review queue ---------------------------
    # The Sell Scanner answers "should I exit this?", which only applies to something
    # still held — so holdings drive this panel. Closed trades are a re-entry (buy-side)
    # question and live in the expander below, pointed at the Deep Dive instead.
    held = pf.holdings(df)
    if held.empty:
        st.info(tr("pf_no_holdings"))
    else:
        st.warning(tr("pf_holdings_header", n=len(held)))
        inv_col = "invested_usd" if currency == "USD" else "invested_jpy"
        hv = pd.DataFrame({
            tr("col_ticker"): held["symbol"],
            tr("col_company"): held["name"],
            tr("pf_col_net_qty"): held["net_qty"],
            tr("pf_col_avg_buy"): [
                ("—" if math.isnan(p) else (f"${p:,.2f}" if mk == "US" else f"¥{p:,.1f}"))
                for p, mk in zip(held["avg_buy_price"], held["market"])],
            tr("pf_col_invested"): [_pf_money(v, currency) for v in held[inv_col]],
            tr("pf_col_last"): held["last_trade"].dt.strftime("%Y-%m-%d"),
        })
        st.dataframe(hv, width="stretch", hide_index=True)
        st.caption(tr("pf_avg_buy_note"))

        # How many to review. The Sell Scanner spends ~3 cached Yahoo requests per name
        # (fundamentals + analyst + insider; a 4th for .T names' 掲示板 poll) and paces
        # ~0.55s each on a cold cache — price history is bulk-fetched once for the whole
        # list, so it costs nothing per name. There is no hard technical limit: the
        # slider just makes that cost visible instead of hiding it behind a default.
        all_syms = [x for x in held["symbol"].tolist() if x]
        n_default = min(20, len(all_syms))
        top_n = st.slider(tr("pf_review_count"), 1, max(1, len(all_syms)), n_default,
                          key="pf_hold_n") if len(all_syms) > 1 else len(all_syms)
        manual = st.multiselect(tr("pf_select_holdings"), all_syms, default=[],
                                key="pf_hold_pick", placeholder=tr("pf_select_placeholder"))
        chosen = manual or all_syms[:top_n]     # a manual pick overrides the slider

        jp_n = sum(1 for t in chosen if t.endswith(".T"))
        reqs = 3 * len(chosen) + jp_n
        secs = 0.55 * len(chosen) + 0.25 * jp_n
        st.caption(tr("pf_cost_estimate", n=len(chosen), reqs=reqs, secs=f"{secs:.0f}"))

        hc = st.columns([1, 2])
        if hc[0].button(tr("pf_send_holdings"), key="pf_to_sell", disabled=not chosen):
            st.session_state["sell_prefill"] = ", ".join(chosen)
            page = _PAGES.get("sell")
            if page is not None:
                st.switch_page(page)
        hc[1].caption(tr("pf_holdings_note", n=len(chosen)))

    # --- partial history warning ---------------------------------------------
    inc = pf.incomplete_positions(df)
    if not inc.empty:
        st.caption(tr("pf_incomplete_note",
                      syms=", ".join(f"{r.symbol} ({r.net_qty:+.0f})" for r in inc.itertuples())))

    # --- closed positions: re-entry watchlist, NOT a sell queue ---------------
    closed = pf.closed_positions(df)
    if not closed.empty:
        with st.expander(tr("pf_closed_header", n=len(closed))):
            cv = pd.DataFrame({
                tr("pf_col_exited"): closed["exited"].dt.strftime("%Y-%m-%d"),
                tr("col_ticker"): closed["symbol"],
                tr("col_company"): closed["name"],
                tr("pf_col_sold_value"): [_pf_money(v, currency) for v in
                                          (closed["sold_usd"] if currency == "USD"
                                           else closed["sold_jpy"])],
            })
            st.dataframe(cv, width="stretch", hide_index=True)
            st.caption(tr("pf_closed_note"))

    # --- summary -------------------------------------------------------------
    smry = pf.summary(df, currency)
    mc = st.columns(4)
    mc[0].markdown(metric_card(tr("pf_m_trades"), f"{smry['trades']:,}"), unsafe_allow_html=True)
    mc[1].markdown(metric_card(tr("pf_m_symbols"), f"{smry['symbols']:,}"), unsafe_allow_html=True)
    mc[2].markdown(metric_card(tr("pf_m_bought"), _pf_money(smry["buy_value"], currency)),
                   unsafe_allow_html=True)
    mc[3].markdown(metric_card(tr("pf_m_sold"), _pf_money(smry["sell_value"], currency)),
                   unsafe_allow_html=True)
    if smry["missing"]:
        st.caption(tr("pf_missing_note", n=smry["missing"], ccy=currency))
    st.caption(tr("pf_cashflow_note"))

    # --- autocomplete search -------------------------------------------------
    st.markdown(f"#### {tr('pf_search_header')}")
    opts = pf.search_options(df)
    picked = st.selectbox(tr("pf_search_label"), opts, index=None,
                          placeholder=tr("pf_search_placeholder"), key="pf_search")
    if picked:
        sym = pf.option_to_symbol(picked, df)
        rows = pf.trades_for(df, sym)
        det = pd.DataFrame({
            tr("col_date"): rows["date"].dt.strftime("%Y-%m-%d"),
            tr("pf_col_side"): rows["side"],
            tr("pf_col_qty"): rows["qty"],
            tr("pf_col_price"): rows["price_local"],
            tr("pf_col_value"): [("≈ " if est and currency == "JPY" else "") + _pf_money(v, currency)
                                 for v, est in zip(rows[val_col], rows["jpy_estimated"])],
            tr("pf_col_account"): rows["account"],
        })
        st.dataframe(det, width="stretch", hide_index=True)
        net = pf.net_qty(df, sym)   # module owns the arithmetic (handles 入庫/出庫)
        st.caption(tr("pf_net_qty", sym=sym, qty=f"{net:,.0f}"))
        results = st.session_state.get("results") or []
        if any(x.get("ticker") == sym for x in results):
            if st.button(tr("pf_open_deep_dive"), key="pf_to_dd"):
                st.session_state["deep_dive_pick"] = sym
                page = _PAGES.get("deep_dive")
                if page is not None:
                    st.switch_page(page)
        else:
            st.caption(tr("pf_not_in_scan", sym=sym))

    # --- full history --------------------------------------------------------
    with st.expander(tr("pf_all_trades")):
        allt = pd.DataFrame({
            tr("col_date"): df["date"].dt.strftime("%Y-%m-%d"),
            tr("col_ticker"): df["symbol"],
            tr("col_company"): df["name"],
            tr("pf_col_side"): df["side"],
            tr("pf_col_qty"): df["qty"],
            tr("pf_col_value"): [("≈ " if est and currency == "JPY" else "") + _pf_money(v, currency)
                                 for v, est in zip(df[val_col], df["jpy_estimated"])],
        })
        st.dataframe(allt, width="stretch", hide_index=True)
        st.caption(tr("pf_estimated_note"))


def _build_navigation() -> "st.navigation":
    """Grouped page tree. Titles are translated per rerun (tr follows the language
    menu, which is read before this runs); url_paths stay fixed so bookmarks and
    the current selection survive a language switch."""
    global _PAGES
    _PAGES = {
        "top": st.Page(page_top, title=tr("tab_top"), url_path="top", default=True),
        "regional": st.Page(page_regional, title=tr("tab_regional"), url_path="regional"),
        "category": st.Page(page_category, title=tr("tab_category"), url_path="category"),
        "themes": st.Page(page_themes, title=tr("tab_themes"), url_path="themes"),
        "deep_dive": st.Page(page_deep_dive, title=tr("tab_deep"), url_path="deep-dive"),
        "deep_scan": st.Page(page_deep_scan, title=tr("tab_deep_scan"), url_path="deep-scan"),
        "early_setups": st.Page(page_early_setups, title=tr("tab_early_setups"),
                                url_path="early-setups"),
        "us": st.Page(page_us, title=tr("tab_us"), url_path="us-conviction"),
        "audit": st.Page(page_audit, title=tr("tab_audit"), url_path="audit"),
        "sell": st.Page(page_sell, title=tr("tab_sell"), url_path="sell"),
        "trades": st.Page(page_portfolio, title=tr("tab_trades"), url_path="my-trades"),
        "help": st.Page(page_help, title=tr("tab_help"), url_path="help"),
    }
    return st.navigation({
        tr("nav_scan"): [_PAGES["top"], _PAGES["regional"], _PAGES["category"], _PAGES["themes"]],
        tr("nav_research"): [_PAGES["deep_dive"], _PAGES["deep_scan"], _PAGES["early_setups"], _PAGES["us"]],
        tr("nav_audit"): [_PAGES["audit"], _PAGES["sell"], _PAGES["trades"]],
        tr("nav_info"): [_PAGES["help"]],
    })


def main() -> None:
    init_db()
    inject_css()

    # Resolve matured recommendation outcomes for the audit accuracy panel (no weight
    # change), then run the single learning loop — the walk-forward optimiser — which
    # re-tunes kpi_weights from matured mock-portfolio picks.
    # Guarded to ONCE PER SESSION: Streamlit reruns main() on every widget
    # interaction, and both loops hit the network when matured picks exist — a
    # persistently-failing ticker (e.g. delisted) would otherwise re-block the UI
    # for several seconds on every single click.
    if not st.session_state.get("_maintenance_done"):
        try: evaluate_outcomes_only()
        except Exception: pass
        try: walk_forward_update()
        except Exception: pass
        # V2.1 measurement pass — independent of the learning loop above.
        try: evaluate_observations()
        except Exception: pass
        st.session_state["_maintenance_done"] = True

    # Sidebar Interface Controller Layout
    # Language menu first: tr() must reflect the chosen language BEFORE the page
    # tree is built, so section headers and page titles localize on this rerun.
    # (st.navigation pins the nav to the top of the sidebar; these controls
    # render below it regardless of call order.)
    lang_choice = st.sidebar.selectbox("🌐 Language / 言語", list(LANGUAGES.keys()), key="lang_select")
    st.session_state["lang"] = LANGUAGES[lang_choice]

    pg = _build_navigation()

    st.sidebar.title(tr("console_title"))
    region_keys = list(TICKER_UNIVERSE.keys())
    selected_regions = st.sidebar.multiselect(tr("regions_to_scan"), region_keys,
                                              default=region_keys, format_func=region_name)
    _n_promoted = sum(len(v) for v in get_promoted_universe().values())
    if _n_promoted:
        st.sidebar.caption(tr("promoted_sidebar", n=_n_promoted))
    quick_scan = st.sidebar.toggle(tr("scan_quick_toggle"), value=True, help=tr("scan_quick_help"))
    jp_forum_on = st.sidebar.toggle(tr("jp_forum_toggle"), value=JP_FORUM_DEFAULT_ON,
                                    help=tr("jp_forum_help"))
    st.session_state["_jp_forum_on"] = bool(jp_forum_on)
    update_prices = st.sidebar.checkbox(tr("update_hist_prices"), value=True)
    # The Audit page reads this from session state (page callables take no args).
    st.session_state["_update_prices"] = bool(update_prices)
    source_keys = list(SENTIMENT_SOURCES.keys())
    selected_sources = st.sidebar.multiselect(
        tr("sentiment_sources"), source_keys, default=source_keys,
        format_func=lambda k: tr(SENTIMENT_SOURCES[k]["label_key"]),
    )
    if st.sidebar.button(tr("scan_btn"), width="stretch"):
        if not selected_regions:
            st.sidebar.warning(tr("no_region_selected"))
        else:
            with st.spinner(tr("scan_spinner")):
                limit = 10 if quick_scan else None
                res, fail = run_engine(limit_per_region=limit, regions=selected_regions,
                                       sources=selected_sources, use_jp_forum=jp_forum_on)
                st.session_state["results"], st.session_state["failed"] = res, fail
                st.session_state["scan_is_quick"] = bool(quick_scan)
            if res:
                st.success(tr("scan_success"))
            elif fail:
                # Nothing came back and tickers failed → almost always an IP-level
                # rate limit from Yahoo, which is common on Streamlit Cloud.
                st.error(tr("all_failed"))

    if st.sidebar.button(tr("seed_btn"), width="stretch"):
        seed_demo_history()          # separate demo database; live data untouched
        st.session_state["show_demo"] = True
        st.sidebar.success(tr("seed_success"))
        st.rerun()

    # Escape hatch for the 30-min data caches: without this, a sudden intraday
    # move is invisible until the TTL lapses because every scan is served from
    # cached frames. Clears price/fundamentals caches only (sentiment keeps its
    # own TTL); the user then re-runs the scan to pull fresh data.
    if st.sidebar.button(tr("refresh_btn"), width="stretch", help=tr("refresh_help")):
        clear_market_data_caches()
        st.sidebar.success(tr("refresh_success"))

    # Read existing session metrics safely. A brand-new session (refresh, new
    # browser tab, cloud session timeout) restores the last persisted scan
    # snapshot so returning users land on their results, not the empty state.
    if "results" not in st.session_state:
        snap = load_latest_scan_snapshot()
        if snap:
            res, created_at, was_quick = snap
            st.session_state["results"] = res
            st.session_state["failed"] = []
            st.session_state["scan_is_quick"] = was_quick
            st.session_state["restored_scan"] = True
            try:
                st.session_state["scan_ts"] = pd.Timestamp(created_at).timestamp()
            except Exception:
                st.session_state["scan_ts"] = None
    results = st.session_state.get("results", [])
    failed = st.session_state.get("failed", [])

    if failed:
        st.sidebar.warning(tr("skipped", items=", ".join(failed)))

    # Freshness chip: when, how many, quick or full — visible on every page.
    if results:
        scan_ts = st.session_state.get("scan_ts")
        ago_txt = _ago(scan_ts) if scan_ts else "—"
        mode = tr("scan_mode_quick") if st.session_state.get("scan_is_quick") else tr("scan_mode_full")
        st.markdown(
            f'<span class="qc-chip">🕒 {tr("scan_chip", ago=ago_txt, n=len(results), mode=mode)}</span>',
            unsafe_allow_html=True)
        if st.session_state.get("restored_scan"):
            st.caption(tr("scan_restored_note"))

    # --- First-run empty state ---------------------------------------------
    # A new user — especially on mobile, where the sidebar starts collapsed —
    # would otherwise land on "please run a scan" pages with the actual Run
    # button hidden. Give them a hero card with a primary CTA right on the main
    # page; it disappears once results exist, and is skipped on the Help page
    # (reading the docs shouldn't compete with a call to action).
    if not results and pg.url_path != "help":
        st.markdown(
            f'<div class="qc-card" style="padding:26px 24px;">'
            f'<div class="qc-ticker">{tr("hero_title")}</div>'
            f'<div class="qc-sub" style="margin-top:6px; max-width:60ch;">{tr("hero_sub")}</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
        if st.button(tr("hero_btn"), type="primary", key="hero_scan_btn"):
            with st.spinner(tr("scan_spinner")):
                res, fail = run_engine(limit_per_region=10,
                                       regions=list(TICKER_UNIVERSE.keys()),
                                       sources=selected_sources, use_jp_forum=jp_forum_on)
                st.session_state["results"], st.session_state["failed"] = res, fail
                st.session_state["scan_is_quick"] = True
            if not res and fail:
                st.error(tr("all_failed"))
            else:
                st.rerun()
        st.caption(tr("hero_hint"))

    # Global sentiment telemetry: surface the buzz sources + freshness once a scan has
    # run, so it's visible app-wide rather than only inside the Deep-Dive page.
    if _LAST_HYPE_FETCHED_AT:
        _msg = tr("hype_updated", ago=_ago(_LAST_HYPE_FETCHED_AT))
        st.caption(f"{_LAST_HYPE_STATUS} · {_msg}" if _LAST_HYPE_STATUS else _msg)

    # Deploying app.py without config.py is the single most common breakage here
    # (it shows up as raw keys and stale labels), so say so plainly rather than
    # letting the user hunt for it.
    # Always show which config.py is actually loaded — this project has now hit the
    # stale-file problem several times, and a visible version is faster to check than
    # inferring it from odd labels.
    st.sidebar.caption(f"config v{CONFIG_SCHEMA_VERSION} · app expects v{EXPECTED_CONFIG_SCHEMA}"
                       + ("  ✅" if CONFIG_SCHEMA_VERSION >= EXPECTED_CONFIG_SCHEMA else "  ⚠️"))
    if CONFIG_SCHEMA_VERSION < EXPECTED_CONFIG_SCHEMA:
        # Deliberately NOT tr(): the message is about config.py being out of date,
        # so it cannot live in config.py — a stale file would render the warning
        # itself as a blank or humanised key, exactly when it is needed most.
        _msg = ("⚠️ config.py is out of date (v{have}, app.py expects v{want}). "
                "Labels will look wrong. Copy the latest config.py AND the "
                ".streamlit/config.toml folder next to app.py, then redeploy."
                if get_lang() != "ja" else
                "⚠️ config.py が古いバージョンです（v{have}／app.py は v{want} を想定）。"
                "表示が崩れます。最新の config.py と .streamlit/config.toml を "
                "app.py と同じ場所に配置して再デプロイしてください。")
        st.sidebar.error(_msg.format(have=CONFIG_SCHEMA_VERSION, want=EXPECTED_CONFIG_SCHEMA))

    # Signature board strip — real engine state, constant field layout, every page.
    _res = st.session_state.get("results") or []
    _held = 0
    if pf is not None:
        _t = st.session_state.get("pf_trades")
        if _t is not None and not _t.empty:
            _held = len(pf.holdings(_t))
    _quick = st.session_state.get("scan_is_quick")
    # Empty cells say WHY they're empty rather than showing a bare dash — a board with
    # four dashes tells you nothing about what would fill it.
    _cells = [
        (tr("board_universe"), f"{len(_res)}" if _res else tr("board_no_scan"),
         bool(_res), tr("board_universe_hint")),
        (tr("board_depth"),
         (tr("board_quick") if _quick else tr("board_full")) if _res else tr("board_no_scan"),
         bool(_res), tr("board_depth_hint")),
        (tr("board_holdings"), f"{_held}" if _held else tr("board_no_csv"),
         bool(_held), tr("board_holdings_hint")),
        (tr("board_feed"),
         (_ago(_LAST_HYPE_FETCHED_AT) if _LAST_HYPE_FETCHED_AT else tr("board_not_run")),
         bool(_LAST_HYPE_FETCHED_AT), tr("board_feed_hint")),
    ]
    st.markdown(board_strip(_cells), unsafe_allow_html=True)

    # App-wide "needs review" banner: once trades are loaded, unreviewed sells stay
    # visible on every page (not just My Trades) until dismissed for the session.
    _pf_df = st.session_state.get("pf_trades")
    if (pf is not None and _pf_df is not None and not _pf_df.empty
            and not st.session_state.get("pf_alert_dismissed")):
        _n = len(pf.holdings(_pf_df))
        if _n:
            _ac = st.columns([5, 1])
            _ac[0].warning(tr("pf_banner", n=_n))
            if _ac[1].button(tr("pf_banner_dismiss"), key="pf_dismiss"):
                st.session_state["pf_alert_dismissed"] = True
                st.rerun()

    # Render ONLY the selected page (lazy — the whole point of st.navigation).
    pg.run()

if __name__ == "__main__":
    main()