"""v21.2 regression tests — three gaps found in a second independent review.

  1. "Every accepted poll is scorable" still had counterexamples: an all-様子見 poll
     (0/0/100/0/0) and an impossible display (100% + 2%) were accepted by the parser and
     refused by both scorers. Random checks had missed them, so these are DETERMINISTIC
     boundary tests, plus a fixed grid over corner values.
  2. Poll scopes crossed unrelated section headings, because HTML headings are stripped
     before parsing and the scope only ended at another 「みんなの評価」.
  3. The Model Lab was still hidden when there were no recommendations at all.

Offline and deterministic. Each test was mutation-checked.
Run: pytest -q test_v212_fixes.py
"""
import itertools
import json
import os
import sys
import types

import jp_fake_http
import pandas as pd
import pytest

import indicators
import sentiment_sources as ss
from indicators import forum_euphoria_sell_score, forum_sentiment_score, jp_poll_problem

SB, B, N, S, SS = ss.JP_LABELS
HEAD = ss.JP_POLL_HEADINGS[0]


def poll(values):
    return f"{HEAD} " + " ".join(f"{lab}{v}%" for lab, v in zip(ss.JP_LABELS, values))


def scores(r):
    return (forum_sentiment_score(r["buy_pct"], r["sell_pct"], r["neutral_pct"]),
            forum_euphoria_sell_score(r["buy_pct"], r["sell_pct"], r["neutral_pct"]))


# ======================================================== 1. accepted => scorable
def test_an_all_neutral_poll_is_a_real_neutral_poll():
    r = ss.parse_jp_board(poll([0, 0, 100, 0, 0]))
    assert r["status"] == "ok" and r["neutral_pct"] == 100
    assert scores(r) == (50.0, 50.0), "everyone on 様子見 = net zero = neutral 50"


def test_nothing_recorded_is_a_labelled_non_scoring_state():
    r = ss.parse_jp_board(f"{HEAD} {B}0% {S}0%")
    assert r["status"] == "unavailable" and r["reason"] == "no_votes"
    assert forum_sentiment_score(0, 0) is None and jp_poll_problem(0, 0) == "no_votes"


def test_an_impossible_display_is_rejected():
    """100% and 2% cannot both round from real shares that sum to 100."""
    r = ss.parse_jp_board(poll([100, 2, 0, 0, 0]))
    assert r["status"] == "parse_error" and r["reason"] == "impossible_display"


@pytest.mark.parametrize("vals", [
    [0, 0, 100, 0, 0], [100, 0, 0, 0, 0], [0, 0, 0, 0, 100], [0, 0, 0, 100, 0],
    [50, 0, 0, 0, 50], [33.33, 0, 0, 0, 66.67], [99, 2, 0, 0, 0], [30, 30.5, 0, 20, 20.5],
    [100, 2, 0, 0, 0], [101, 0, 0, 0, 0], [60, 45, 0, 0, 0], [0, 0, 0, 0, 0]])
def test_boundary_polls_parser_and_scorers_agree(vals):
    """Either both accept or the parser refuses — never 'shown but skipped'."""
    r = ss.parse_jp_board(poll(vals))
    if r["status"] == "ok":
        assert None not in scores(r), f"{vals} accepted but unscorable"


def test_fixed_grid_over_corner_values():
    """Every five-category combination of corner values (6**5 = 7,776 polls), fixed and
    deterministic: no accepted poll may be refused by either scorer."""
    corners = (0, 1, 2, 50, 99, 100)
    accepted = 0
    for vals in itertools.product(corners, repeat=5):
        r = ss.parse_jp_board(poll(list(vals)))
        if r["status"] == "ok":
            accepted += 1
            assert None not in scores(r), vals
    assert accepted > 0


def test_the_parser_applies_the_scorers_own_rule():
    """Not just the same tolerance: the same function decides."""
    assert ss.jp_poll_problem is indicators.jp_poll_problem


@pytest.mark.parametrize("args,why", [
    ((0, 0), "no_votes"), ((0, 0, 100), None), ((102.6, 0), "aggregate_over_100"),
    ((60, 43), "total_over_100"), ((-1, 50), "negative"), ((float("nan"), 1), "not_a_number"),
    ((64, 14, 22), None), ((60, 40, 3), "total_over_100")])
def test_jp_poll_problem_contract(args, why):
    assert jp_poll_problem(*args) == why


# ======================================================== 2. structural scoping
NEXT_SECTION = (f"<section><h2>{HEAD}</h2><p>データなし</p></section>"
                f"<section><h2>掲示板投稿</h2><p>{SB}10% {B}21% {N}2% {S}30% {SS}37%</p></section>")


def test_scope_does_not_cross_into_the_next_section():
    r = ss.parse_jp_board(NEXT_SECTION)
    assert r["status"] == "unavailable" and r["buy_pct"] is None, \
        "numbers from the NEXT section must never be attributed to the poll"


def test_scope_stops_at_a_sibling_heading_too():
    page = (f"<div><h2>{HEAD}</h2><p>データなし</p><h2>掲示板投稿</h2>"
            f"<p>{SB}10% {B}21% {N}2% {S}30% {SS}37%</p></div>")
    assert ss.parse_jp_board(page)["status"] == "unavailable"


def test_a_poll_inside_its_own_section_is_read():
    page = (f"<section><h2>{HEAD}</h2><ul><li>{SB}10%</li><li>{B}21%</li><li>{N}2%</li>"
            f"<li>{S}30%</li><li>{SS}37%</li></ul></section><section><h2>掲示板投稿</h2></section>")
    r = ss.parse_jp_board(page)
    assert r["status"] == "ok" and (r["buy_pct"], r["sell_pct"]) == (31, 67)


def test_head_and_scripts_cannot_open_a_scope():
    page = (f"<head><title>{HEAD}</title></head><script>var t='{HEAD} {SB}99%';</script>"
            f"<p>{SB}10% {B}21% {N}2% {S}30% {SS}37%</p>")
    assert ss.parse_jp_board(page)["reason"] == "poll_heading_not_found"


def test_plain_text_still_parses():
    assert ss.parse_jp_board(poll([10, 21, 2, 30, 37]))["status"] == "ok"


# ======================================================== app fixtures
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getitem__(self, i): return _Any()
    def __bool__(self): return False                  # widgets are un-clicked by default
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    def __getattr__(self, n): return _Any()
    def columns(self, spec, **k):        # so `b1, b2 = st.columns(2)` unpacks
        return [_Any() for _ in range(spec if isinstance(spec, int) else len(spec))]
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, here)
    spec = importlib.util.spec_from_file_location("app_v212", os.path.join(here, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    return app


# ======================================================== 1 through a real scan
def test_an_all_neutral_poll_reaches_the_score_as_neutral(db, monkeypatch):
    app = db
    idx = pd.bdate_range("2026-01-05", periods=230)
    frame = pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)],
                          "Volume": [1e6] * 230}, index=idx)
    page = f"<html><body><section><h2>{HEAD}</h2><p>{poll([0, 0, 100, 0, 0])}</p></section></body></html>"
    jp_fake_http.install(monkeypatch, page)
    monkeypatch.setattr(app, "TICKER_UNIVERSE", {"Japan": ["7203.T"]})
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})
    on, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    # read the persisted record NOW: the next scan replaces today's daily-view row
    with app.get_conn() as c:
        rs = json.loads(c.execute("SELECT retail_sentiment FROM observations").fetchone()[0])
    assert rs["jp_board"]["neutral_pct"] == 100
    off, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=False)
    assert on[0]["hype_score"] == pytest.approx(min(100.0, max(0.0, 0.5 * off[0]["hype_score"] + 25.0))), \
        "an all-neutral poll must blend in as 50, not be dropped"


def test_the_japan_poll_is_opt_in(app):
    assert app.JP_FORUM_DEFAULT_ON is False


# ======================================================== 3. Model Lab on every live path
def _lab_calls(app, monkeypatch):
    calls = []
    monkeypatch.setattr(app, "render_model_lab", lambda: calls.append(1))
    return calls


def test_model_lab_shows_with_no_recommendations_at_all(db, monkeypatch):
    app = db
    calls = _lab_calls(app, monkeypatch)
    with app.get_conn() as c:      # observations exist; recommendations and mock do not
        c.execute("INSERT INTO observations (scan_id, obs_date, ticker, composite, rank_pct, "
                  "factors, x20, model_version) VALUES ('s','2026-03-02','AAA',70,50,'{}',1.0,?)",
                  (app.PRODUCTION_MODEL_VERSION,))
    assert app.get_recommendations().empty and app.get_mock_portfolio().empty
    app.render_engine_audit(update_prices=False)
    assert calls == [1]


def test_model_lab_shows_with_recommendations_but_no_mock_picks(db, monkeypatch):
    app = db
    calls = _lab_calls(app, monkeypatch)
    with app.get_conn() as c:
        c.execute("INSERT INTO recommendations (ticker, rec_date, recommendation, composite, "
                  "price_at_rec, price_after, outcome, eval_date, outcome_basis) "
                  "VALUES ('AAA','2026-03-02','BUY',70,100,105,1,'2026-03-20','excess')")
    app.render_engine_audit(update_prices=False)
    assert calls == [1]


def test_demo_view_never_shows_the_live_model_lab(db, monkeypatch):
    app = db
    app.seed_demo_history()
    calls = _lab_calls(app, monkeypatch)
    app.st.session_state["show_demo"] = True
    app.render_engine_audit(update_prices=False)
    assert calls == [], "the Model Lab is live-only"


def test_demo_flag_without_a_demo_database_falls_back_to_live(db, monkeypatch):
    """Found while writing the test above: demo mode with the demo file missing used to
    crash the Audit page ('no such table')."""
    app = db
    assert not os.path.exists(app.DEMO_DB_PATH)
    calls = _lab_calls(app, monkeypatch)
    app.st.session_state["show_demo"] = True
    app.render_engine_audit(update_prices=False)          # must not raise
    assert app.st.session_state["show_demo"] is False and calls == [1]
