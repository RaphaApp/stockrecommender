"""v21.4 tests — the Japan board's rounded headline summary, the diagnostic, and the
scan-to-ledger path.

The bug: a page that shows the five-category breakdown AND a rounded headline summary
("買いたい 72% / 売りたい 20%") was rejected as `duplicate_label`, because the summary reuses
the plain buy/sell labels. Reproduced with the numbers from the handoff:

    strong buy 62.96 / buy 9.26 / watch 7.41 / sell 3.70 / strong sell 16.67   (sums to 100)
    rounded summary: buy 72 / sell 20      (62.96 + 9.26 = 72.22 ; 3.70 + 16.67 = 20.37)

These tests use fixtures ONLY. Nothing here is a live Yahoo! page, so none of it proves
the live page is readable; the diagnostic script exists to find that out on a real page.

Run: pytest -q test_v214_jp_summary.py
"""
import json
import logging
import os
import sys
import types
import urllib.error

import jp_fake_http
import numpy as np
import pandas as pd
import pytest

import sentiment_sources as ss
from indicators import forum_sentiment_score

HERE = os.path.dirname(os.path.abspath(__file__))
SB, B, N, S, SS = ss.JP_LABELS
H = ss.JP_POLL_HEADINGS[0]

DETAIL = f"{SB}62.96% {B}9.26% {N}7.41% {S}3.70% {SS}16.67%"
SUMMARY = f"{B}72% {S}20%"


def page(*parts, heading=True):
    body = "".join(f"<p>{p}</p>" for p in parts)
    return f"<section>{f'<h2>{H}</h2>' if heading else ''}{body}</section>"


# ============================================================ the reported bug
@pytest.mark.parametrize("order", ["detail_first", "summary_first"])
def test_breakdown_plus_rounded_summary_is_read(order):
    parts = (DETAIL, SUMMARY) if order == "detail_first" else (SUMMARY, DETAIL)
    r = ss.parse_jp_board(page(*parts))
    assert r["status"] == "ok", r["reason"]
    assert r["buy_pct"] == pytest.approx(72.22) and r["sell_pct"] == pytest.approx(20.37)
    assert r["neutral_pct"] == pytest.approx(7.41)
    assert (r["summary_buy_pct"], r["summary_sell_pct"]) == (72.0, 20.0)


def test_the_breakdown_alone_still_works_and_records_no_summary():
    r = ss.parse_jp_board(page(DETAIL))
    assert r["status"] == "ok" and r["summary_buy_pct"] is None and r["summary_sell_pct"] is None


def test_the_score_uses_the_precise_category_sums_not_the_rounded_summary():
    r = ss.parse_jp_board(page(DETAIL, SUMMARY))
    precise = forum_sentiment_score(72.22, 20.37, 7.41)
    rounded = forum_sentiment_score(72.0, 20.0, 7.41)
    assert precise != rounded
    assert forum_sentiment_score(r["buy_pct"], r["sell_pct"], r["neutral_pct"]) == pytest.approx(precise)


def test_nothing_is_counted_twice():
    r = ss.parse_jp_board(page(DETAIL, SUMMARY))
    assert r["buy_pct"] < 100 and r["buy_pct"] + r["neutral_pct"] + r["sell_pct"] == pytest.approx(100.0)
    assert sum(r["categories"].values()) == pytest.approx(100.0)


def test_raw_categories_neutral_and_provenance_are_preserved():
    r = ss.parse_jp_board(page(DETAIL, SUMMARY))
    assert r["categories"] == {SB: 62.96, B: 9.26, N: 7.41, S: 3.70, SS: 16.67}
    assert r["layout"] == "five_category" and r["parser_version"] == ss.JP_PARSER_VERSION


def test_parser_version_records_the_summary_capability():
    assert ss.JP_PARSER_VERSION == "jp-board-v5-visible-detail-safe-summary"


# ============================================================ the summary is CHECKED, not trusted
@pytest.mark.parametrize("buy,sell,accepted", [
    (72, 20, True), (73, 21, True), (72, 21, True), (73, 20, True),      # within ~1.01 of 72.22 / 20.37
    (71, 20, False), (72, 19, False), (74, 20, False), (72, 22, False),  # just outside it
])
def test_summary_rounding_boundary(buy, sell, accepted):
    """Allowed gap = display half-units + 0.5 slack (for a summary built from separately
    rounded parts) = 1.01. Against 72.22 / 20.37: 71 and 19 are ~1.2 / ~1.4 away."""
    r = ss.parse_jp_board(page(DETAIL, f"{B}{buy}% {S}{sell}%"))
    assert (r["status"] == "ok") is accepted, (buy, sell, r["reason"])
    if not accepted:
        assert r["reason"] == "summary_conflicts_with_categories"


@pytest.mark.parametrize("summary", [f"{B}40% {S}20%", f"{B}72% {S}45%", f"{B}74% {S}20%",
                                     f"{B}9% {S}4%"])
def test_a_summary_that_contradicts_the_categories_is_rejected_not_averaged(summary):
    r = ss.parse_jp_board(page(DETAIL, summary))
    assert r["status"] == "parse_error" and r["reason"] == "summary_conflicts_with_categories"
    assert r["buy_pct"] is None, "a contradiction must not produce a number"


def test_a_summary_on_one_side_only_is_refused_visibly_next_to_an_ordered_breakdown():
    """v21.4 accepted this; the reviewed parser (v5) refuses it with a visible reason rather
    than guess which side the lone number describes. No known live layout needs it."""
    r = ss.parse_jp_board(page(DETAIL, f"{B}72%"))
    assert r["status"] == "parse_error" and r["reason"] == "unresolved_numeric_poll_labels"
    assert r["buy_pct"] is None


def test_summary_cannot_rescue_an_invalid_breakdown():
    bad = f"{SB}40% {B}9.26% {N}7.41% {S}3.70% {SS}16.67%"            # totals 77%
    assert ss.parse_jp_board(page(bad, f"{B}49% {S}20%"))["status"] == "parse_error"


def test_ambiguous_readings_resolve_identically_in_either_order():
    """Strong-buy 0%: '50.4' could be the category or '50' could. Both readings fit the
    arithmetic; the more precisely shown number is the category (the summary is the
    rounded one), and the order on the page must not change that."""
    detail = f"{SB}0% {B}50.4% {N}9.6% {S}20.0% {SS}20.0%"
    a = ss.parse_jp_board(page(detail, f"{B}50% {S}40%"))
    b = ss.parse_jp_board(page(f"{B}50% {S}40%", detail))
    assert a["status"] == b["status"] == "ok"
    for r in (a, b):
        assert r["buy_pct"] == 50.4 and r["summary_buy_pct"] == 50.0 and r["sell_pct"] == 40.0


def test_an_all_neutral_poll_with_a_zero_summary_is_a_neutral_poll():
    r = ss.parse_jp_board(page(f"{SB}0% {B}0% {N}100% {S}0% {SS}0%", f"{B}0% {S}0%"))
    assert r["status"] == "ok" and r["neutral_pct"] == 100
    assert forum_sentiment_score(r["buy_pct"], r["sell_pct"], r["neutral_pct"]) == 50.0


# ============================================================ real conflicts are still rejected
def test_a_whole_component_repeated_in_one_scope_is_rejected():
    r = ss.parse_jp_board(page(DETAIL + " " + DETAIL))
    assert r["status"] == "parse_error" and r["reason"] == "duplicate_label"


def test_strong_buy_twice_is_rejected():
    r = ss.parse_jp_board(page(DETAIL, f"{SB}10%"))
    assert r["status"] == "parse_error" and r["reason"] == "duplicate_label"


def test_three_plain_buy_labels_are_rejected():
    r = ss.parse_jp_board(page(DETAIL, f"{B}72%", f"{B}71%"))
    assert r["status"] == "parse_error"


def test_disagreeing_components_in_separate_scopes_are_ambiguous():
    other = f"{SB}10% {B}21% {N}2% {S}30% {SS}37%"
    r = ss.parse_jp_board(page(DETAIL, SUMMARY) + page(other))
    assert r["status"] == "ambiguous"


def test_agreeing_components_where_only_one_has_a_summary_are_one_poll():
    r = ss.parse_jp_board(page(DETAIL, SUMMARY) + page(DETAIL))
    assert r["status"] == "ok" and r["buy_pct"] == pytest.approx(72.22)


def test_failure_is_visible_never_a_zero_or_a_neutral_50():
    r = ss.parse_jp_board(page(DETAIL, f"{B}40% {S}20%"))
    assert r["buy_pct"] is None and r["sell_pct"] is None and r["neutral_pct"] is None


# ============================================================ property check (seeded)
def test_random_polls_with_rounded_summaries_always_read_back_exactly():
    """2,000 seeded random breakdowns, each shown with a summary rounded the way the
    page is described to round it, in both orders: the parser must return the precise
    category sums every time, and never raise or double count."""
    rng = np.random.default_rng(14)
    checked = 0
    for _ in range(2000):
        dec = int(rng.integers(0, 3))
        raw = rng.dirichlet(np.ones(5)) * 100
        v = [round(float(x), dec) for x in raw]
        v[2] = round(100 - sum(v[:2] + v[3:]), dec)                    # force the total to 100
        if min(v) < 0:
            continue
        detail = f"{SB}{v[0]}% {B}{v[1]}% {N}{v[2]}% {S}{v[3]}% {SS}{v[4]}%"
        buy, sell = v[0] + v[1], v[3] + v[4]
        summary = f"{B}{round(buy)}% {S}{round(sell)}%"
        for parts in ((detail, summary), (summary, detail)):
            r = ss.parse_jp_board(page(*parts))
            if r["status"] != "ok":
                # the only legitimate refusal is an impossible display (shares that cannot sum to 100)
                assert r["reason"] in ("impossible_display", "total_not_100"), (v, r["reason"])
                continue
            assert r["buy_pct"] == pytest.approx(buy) and r["sell_pct"] == pytest.approx(sell), v
            assert r["neutral_pct"] == pytest.approx(v[2])
            checked += 1
    assert checked > 1500


# ============================================================ the diagnostic (no network)
SCRIPT_ONLY = (f'<html><body><div id="root"></div><script id="__NEXT_DATA__">'
               f'{{"{H}":1,"{SB}":62.96,"{B}":9.26}}</script></body></html>')
BLOCKED = "<html><body><p>Access denied</p></body></html>"


def test_describe_page_tells_the_three_failure_modes_apart():
    ok = ss.describe_poll_page(page(DETAIL, SUMMARY))
    assert ok["result"]["status"] == "ok" and ok["heading_in_visible_text"] == 1
    assert sum(ok["label_counts_script_data"].values()) == 0 and ok["scope_count"] == 1
    js = ss.describe_poll_page(SCRIPT_ONLY)
    assert js["heading_in_visible_text"] == 0 and js["heading_in_script_data"] == 1
    assert sum(js["label_counts_visible"].values()) == 0 and sum(js["label_counts_script_data"].values()) >= 2
    blocked = ss.describe_poll_page(BLOCKED)
    assert blocked["result"]["reason"] == "poll_heading_not_found"
    assert sum(blocked["label_counts_script_data"].values()) == 0


def test_describe_page_is_total_on_odd_input():
    for raw in ("", None, "<<<>>>", "x" * 5000, "<script>" + H * 3):
        d = ss.describe_poll_page(raw)
        assert "result" in d and isinstance(d["snippets"], list)


def test_describe_page_shows_what_each_scope_contains():
    d = ss.describe_poll_page(page(DETAIL, f"{B}40% {S}20%"))
    assert d["result"]["reason"] == "summary_conflicts_with_categories"
    assert "62.96" in d["scopes"][0] and "40%" in d["scopes"][0]


def _diag(tmp_path, html, args=()):
    import subprocess
    f = tmp_path / "saved.html"
    f.write_text(html, encoding="utf-8")
    return subprocess.run([sys.executable, os.path.join(HERE, "jp_board_diagnose.py"), "--file", str(f), *args],
                          capture_output=True, text=True, cwd=HERE, timeout=60)


def test_diagnose_script_explains_a_readable_page(tmp_path):
    r = _diag(tmp_path, page(DETAIL, SUMMARY))
    assert r.returncode == 0 and "READABLE" in r.stdout and "72.22" in r.stdout
    assert "rounded headline summary" in r.stdout


def test_diagnose_script_explains_script_only_data(tmp_path):
    r = _diag(tmp_path, SCRIPT_ONLY)
    assert r.returncode == 0 and "ONLY inside script data" in r.stdout


def test_diagnose_script_explains_a_blocked_page(tmp_path):
    r = _diag(tmp_path, BLOCKED)
    assert r.returncode == 0 and "login/consent/blocking" in r.stdout


def test_diagnose_script_explains_a_poll_that_does_not_validate(tmp_path):
    r = _diag(tmp_path, page(DETAIL, f"{B}40% {S}20%"))
    assert "HEADING FOUND but the poll did not validate" in r.stdout
    assert "summary_conflicts_with_categories" in r.stdout


def test_diagnose_script_reports_a_fetch_failure_instead_of_guessing(monkeypatch, capsys):
    sys.path.insert(0, HERE)
    import jp_board_diagnose as jd
    def boom(ticker, timeout=15.0):
        raise urllib.error.URLError("no route")
    monkeypatch.setattr(jd, "fetch_page", boom)       # what main() actually calls
    assert jd.main(["7203.T"]) == 2
    out = capsys.readouterr().out
    assert "FETCH FAILED" in out and "STOCKREC_CA_BUNDLE" in out


def test_diagnose_script_refuses_non_tokyo_tickers(capsys):
    sys.path.insert(0, HERE)
    import jp_board_diagnose as jd
    with pytest.raises(SystemExit) as e:
        jd.main(["AAPL"])
    assert e.value.code == 2


# ============================================================ app fixtures (in-process, stubbed streamlit)
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getitem__(self, i): return _Any()
    def __bool__(self): return False
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    def __getattr__(self, n): return _Any()
    def columns(self, spec, **k):
        return [_Any() for _ in range(spec if isinstance(spec, int) else len(spec))]
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    sys.path.insert(0, HERE)
    spec = importlib.util.spec_from_file_location("app_v214", os.path.join(HERE, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    return app


def _frame():
    idx = pd.bdate_range("2026-01-05", periods=230)
    return pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)],
                         "High": [101 * 1.001 ** i for i in range(230)],
                         "Low": [99 * 1.001 ** i for i in range(230)],
                         "Volume": [1e6] * 230}, index=idx)


def _env(app, monkeypatch, html, calls):
    frame = _frame()
    jp_fake_http.install(monkeypatch, html, calls)
    monkeypatch.setattr(app, "TICKER_UNIVERSE", {"Japan": ["7203.T"]})
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})
    return frame


# ============================================================ real scan -> ledger
def test_a_page_with_a_summary_flows_through_a_real_scan_into_the_ledger(db, monkeypatch):
    app, calls = db, []
    html = f"<html><body>{page(DETAIL, SUMMARY)}</body></html>"
    _env(app, monkeypatch, html, calls)
    on, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    r = on[0]
    assert len(calls) == 1 and r["jp_board"]["status"] == "ok"
    assert (r["jp_bull"], r["jp_bear"]) == (pytest.approx(72.22), pytest.approx(20.37))
    # the poll reached the composite's hype input through the unchanged 50/50 blend
    with app.get_conn() as c:
        row = c.execute("SELECT retail_sentiment, model_version FROM observations").fetchone()
    rec = json.loads(row[0])["jp_board"]
    assert rec["status"] == "ok" and (rec["summary_buy_pct"], rec["summary_sell_pct"]) == (72.0, 20.0)
    assert rec["neutral_pct"] == pytest.approx(7.41) and rec["parser_version"] == ss.JP_PARSER_VERSION
    assert rec["categories"][SB] == 62.96
    assert row[1] == app.PRODUCTION_MODEL_VERSION == "composite-v8-jp-visible-detail"
    off, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=False)
    fs = forum_sentiment_score(72.22, 20.37, 7.41)
    assert on[0]["hype_score"] == pytest.approx(min(100.0, max(0.0, 0.5 * off[0]["hype_score"] + 0.5 * fs)))


def test_a_conflicting_summary_is_recorded_as_a_failure_in_the_ledger_not_a_number(db, monkeypatch):
    app, calls = db, []
    _env(app, monkeypatch, f"<html><body>{page(DETAIL, f'{B}40% {S}20%')}</body></html>", calls)
    res, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    assert res[0]["jp_board"]["status"] == "parse_error"
    assert res[0]["jp_board"]["reason"] == "summary_conflicts_with_categories"
    assert str(res[0]["jp_bull"]) == "nan", "no poll number may reach the score"
    with app.get_conn() as c:
        rec = json.loads(c.execute("SELECT retail_sentiment FROM observations").fetchone()[0])["jp_board"]
    assert rec["status"] == "parse_error" and rec["buy_pct"] is None


def test_the_toggle_still_gates_everything(db, monkeypatch):
    app, calls = db, []
    _env(app, monkeypatch, f"<html><body>{page(DETAIL, SUMMARY)}</body></html>", calls)
    res, _ = app.run_engine(regions=["Japan"], sources=[])
    assert calls == [] and res[0]["jp_forum_enabled"] is False


def test_deep_scan_does_not_fetch_the_japan_board(db, monkeypatch):
    """Pinned current behaviour (the handoff asks users to be told): Deep Scan scores with
    no board poll. If this is ever changed the toggle's help text must change with it."""
    app, calls = db, []
    frame = _env(app, monkeypatch, f"<html><body>{page(DETAIL, SUMMARY)}</body></html>", calls)
    monkeypatch.setattr(app, "deep_universe_for", lambda region: (["7203.T", "6758.T"], 0))
    res, _n = app.run_deep_scan("Japan")
    assert res, "the deep scan must have scored something for this test to mean anything"
    assert calls == []
    assert all(not r.get("jp_board") and "jp_forum_enabled" not in r for r in res)


def test_the_toggle_help_says_deep_scan_is_excluded_and_a_new_scan_is_needed():
    import config
    for lang, deep, new in (("en", "Deep Scan", "next main scan"), ("ja", "ディープスキャン", "次回メインスキャン")):
        text = config.TRANSLATIONS[lang]["jp_forum_help"]
        assert deep in text and new in text, lang


# ============================================================ credentials never leak (handoff section 6)
SENTINEL_USER, SENTINEL_PASS = "SENTINEL_USER_a1b2c3", "SENTINEL_PASS_z9y8x7"


def _no_secret(text):
    import base64
    token = base64.b64encode(f"{SENTINEL_USER}:{SENTINEL_PASS}".encode()).decode()
    return all(s not in text for s in (SENTINEL_USER, SENTINEL_PASS, token))


@pytest.mark.parametrize("exc", [urllib.error.HTTPError("u", 401, "x", {}, None),
                                 urllib.error.HTTPError("u", 429, "x", {}, None),
                                 urllib.error.URLError("down"), TimeoutError(), ValueError("bad")])
def test_stocktwits_client_never_returns_or_logs_credentials(exc, caplog):
    def opener(req, timeout=None):
        raise exc
    with caplog.at_level(logging.DEBUG):
        rec = ss.fetch_stocktwits_approved("AAPL", SENTINEL_USER, SENTINEL_PASS, opener=opener)
    assert _no_secret(json.dumps(rec, default=str)) and _no_secret(caplog.text)


def test_the_app_path_never_logs_or_stores_credentials(db, monkeypatch, caplog):
    app = db
    monkeypatch.setattr(app, "_stocktwits_credentials", lambda: (SENTINEL_USER, SENTINEL_PASS))
    def fail(*a, **k):
        raise RuntimeError("provider exploded")
    monkeypatch.setattr(app, "_fetch_stocktwits_cached", fail)
    with caplog.at_level(logging.DEBUG):
        rec = app.fetch_stocktwits("AAPL")
        results = [{"ticker": "AAPL"}]
        app.attach_retail_sentiment(results)
    assert rec["status"] == "network_error"
    assert _no_secret(json.dumps(rec, default=str)) and _no_secret(json.dumps(results, default=str))
    assert _no_secret(caplog.text)


def test_no_guessed_rapidapi_integration_exists():
    """The handoff: do not implement a guessed RapidAPI endpoint or reuse a RapidAPI key in
    the existing username/password fields. Access is unresolved, so the only supported
    Stocktwits route stays the documented approved API."""
    for f in ("app.py", "sentiment_sources.py", "config.py"):
        assert "rapidapi" not in open(os.path.join(HERE, f), encoding="utf-8").read().lower(), f
    assert ss.STOCKTWITS_ENDPOINT.startswith("https://api-gw-prd.stocktwits.com/")


# ============================================================ the panel in real Streamlit
def _panel_cases():
    from test_v213_hype_panel import jp_ok, JP_BASE, UNUSABLE
    with_summary = dict(jp_ok(72.22, 7.41, 20.37), summary_buy_pct=72.0, summary_sell_pct=20.0)
    return {
        "summary": dict(JP_BASE, jp_board=with_summary, jp_bull=72.22, jp_bear=20.37),
        "no_summary": dict(JP_BASE, jp_board=jp_ok(), jp_bull=31.0, jp_bear=67.0),
        "conflict": dict(JP_BASE, jp_forum_enabled=True,
                         jp_board=UNUSABLE("summary_conflicts_with_categories", "parse_error")),
        "no_heading": dict(JP_BASE, jp_forum_enabled=True,
                           jp_board=UNUSABLE("poll_heading_not_found", "unavailable")),
        "no_votes": dict(JP_BASE, jp_forum_enabled=True, jp_board=UNUSABLE("no_votes", "unavailable")),
        "ambiguous": dict(JP_BASE, jp_forum_enabled=True, jp_board=UNUSABLE("duplicate_components_disagree", "ambiguous")),
    }


@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    from test_v213_hype_panel import PANEL_SCRIPT, PANEL_DRIVER, _run_driver
    cases = {f"{name}|{lang}": {"record": rec, "lang": lang}
             for name, rec in _panel_cases().items() for lang in ("en", "ja")}
    res = _run_driver(PANEL_DRIVER, tmp_path_factory.mktemp("panel214"), cases, PANEL_SCRIPT)
    for k, v in res.items():
        assert not v["exceptions"], (k, v["exceptions"])
    return res


def T(key, lang="en", **kw):
    import config
    return config.TRANSLATIONS[lang][key].format(**kw)


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_the_panel_shows_the_summary_with_its_provenance(panel, lang):
    r = panel[f"summary|{lang}"]
    assert T("hype_jp_summary", lang, buy="72%", sell="20%") in r["text"]
    assert T("hype_jp_applied", lang) in r["caption"]
    m = r["metric"]
    assert m[T("crowd_jp_buy", lang)] == "72.22%" and m[T("crowd_jp_sell", lang)] == "20.37%"
    assert m[T("crowd_jp_neutral", lang)] == "7.41%"


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_no_summary_line_when_the_page_showed_none(panel, lang):
    assert not any(t.startswith(T("hype_jp_summary", lang, buy="", sell="")[:12]) for t in panel[f"no_summary|{lang}"]["text"])


@pytest.mark.parametrize("name", ["conflict", "no_heading", "ambiguous"])
@pytest.mark.parametrize("lang", ["en", "ja"])
def test_an_unreadable_poll_points_to_the_diagnostic(panel, name, lang):
    r = panel[f"{name}|{lang}"]
    assert T("hype_jp_diag_hint", lang) in r["caption"] and T("hype_no_number", lang) in r["info"]
    assert not any("%" in v for v in r["metric"].values())


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_an_empty_poll_is_not_sent_to_the_diagnostic(panel, lang):
    """Nobody has voted is not a parsing problem."""
    assert T("hype_jp_diag_hint", lang) not in panel[f"no_votes|{lang}"]["caption"]


def test_the_reason_is_visible_in_the_details(panel):
    assert any("summary_conflicts_with_categories" in t for t in panel["conflict|en"]["text"])
