"""P1 regression tests: Stocktwits measurement layer, benchmark coverage, scoring-time
weights in explanations, non-mutating level refresh, within-cohort quintiles, as-of
dating of picks, and the append-only observation log.

Offline and deterministic: no network (the approved-API client is driven through an
injected opener), a temp SQLite database, fixed dates. Each test was mutation-checked.
Run: pytest -q test_p1_integrity.py
"""
import io
import json
import os
import sys
import types
import urllib.error
from datetime import date

import numpy as np
import pandas as pd
import pytest

import sentiment_sources as ss


# ================================================================= Stocktwits (pure)
def _payload(score=34, window="24h", label="Bearish", volume=65):
    return {"data": {"sentiment": {window: {"valueNormalized": score, "labelNormalized": label}},
                     "messageVolume": {window: {"valueNormalized": volume}}}}


def test_normalised_score_is_not_a_buy_percentage():
    r = ss.normalize_stocktwits(_payload(34), "SHEL", "24h")
    assert r["status"] == "ok" and r["score"] == 34 and r["label"] == "Bearish"
    assert r["buy_pct"] is None and r["sell_pct"] is None, "34/100 is not 34% buy / 66% sell"
    assert r["message_volume_score"] == 65 and r["metric_type"] == "provider_normalized_sentiment"


def test_zero_is_a_value_and_missing_is_unavailable():
    assert ss.normalize_stocktwits(_payload(0), "X", "24h")["score"] == 0
    assert ss.normalize_stocktwits(_payload(None), "X", "24h")["status"] == "unavailable"


def test_requested_window_is_never_substituted():
    assert ss.normalize_stocktwits(_payload(window="15m"), "X", "24h")["status"] == "unavailable"


class _Resp(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): return False


def _opener(body=None, exc=None):
    def op(req, timeout=None):
        if exc is not None:
            raise exc
        return _Resp(body)
    return op


def test_no_credentials_means_no_request():
    def never(*a, **k):
        raise AssertionError("must not request without credentials")
    assert ss.fetch_stocktwits_approved("SHEL", None, None, opener=never)["status"] == "not_configured"


@pytest.mark.parametrize("exc,status", [
    (urllib.error.HTTPError("u", 401, "x", {}, None), "unauthorized"),
    (urllib.error.HTTPError("u", 403, "x", {}, None), "forbidden"),
    (urllib.error.HTTPError("u", 429, "x", {}, None), "rate_limited"),
    (TimeoutError(), "network_error"),
    (urllib.error.URLError("down"), "network_error")])
def test_http_and_network_failures_fail_safe(exc, status):
    r = ss.fetch_stocktwits_approved("SHEL", "u", "p", opener=_opener(exc=exc))
    assert r["status"] == status and r["score"] is None


@pytest.mark.parametrize("body", [b"not json", b"[1,2]", b"x" * 1_000_001])
def test_bad_bodies_are_invalid_responses(body):
    r = ss.fetch_stocktwits_approved("SHEL", "u", "p", opener=_opener(body=body))
    assert r["status"] == "invalid_response" and r["score"] is None


def test_valid_response_round_trip():
    r = ss.fetch_stocktwits_approved("SHEL", "u", "p",
                                     opener=_opener(body=json.dumps(_payload(41)).encode()))
    assert r["status"] == "ok" and r["score"] == 41


# ================================================================= app fixtures
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    secrets: dict = {}
    def __getattr__(self, n): return _Any()
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, here)
    spec = importlib.util.spec_from_file_location("app_p1", os.path.join(here, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path, monkeypatch):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    monkeypatch.delenv("STOCKTWITS_API_USERNAME", raising=False)
    monkeypatch.delenv("STOCKTWITS_API_PASSWORD", raising=False)
    return app


# ================================================================= Stocktwits (app)
def test_listing_identity_routing(app):
    assert app.stocktwits_symbol("SHEL") == "SHEL"           # US listing (the ADR itself)
    assert app.stocktwits_symbol("SHEL.L") is None            # never mapped to the ADR
    assert app.stocktwits_symbol("7203.T") is None
    assert app.stocktwits_symbol("BRK-B") == "BRK.B"          # explicit share-class map
    assert app.stocktwits_symbol("XYZ-W") is None             # unmapped hyphen -> skipped
    assert app.stocktwits_symbol("^GSPC") is None


def test_no_credentials_no_request_through_the_app(db, monkeypatch):
    app = db
    monkeypatch.setattr(app._ss, "fetch_stocktwits_approved",
                        lambda *a, **k: pytest.fail("no request without credentials"))
    r = [{"ticker": "AAA"}]
    app.attach_retail_sentiment(r)
    assert r[0]["stocktwits"]["status"] == "not_configured"


def test_circuit_breaker_stops_requests_after_401(db, monkeypatch):
    app = db
    monkeypatch.setenv("STOCKTWITS_API_USERNAME", "u")
    monkeypatch.setenv("STOCKTWITS_API_PASSWORD", "p")
    calls = []
    def fake(sym, u, p, window="24h"):
        calls.append(sym)
        return ss.normalize_stocktwits({}, sym, window) | {"status": "unauthorized"}
    monkeypatch.setattr(app._ss, "fetch_stocktwits_approved", fake)
    rs = [{"ticker": t} for t in ("AAA", "BBB", "CCC")]
    app.attach_retail_sentiment(rs)
    assert calls == ["AAA"], "after a 401 no further requests may be made"
    assert [r["stocktwits"]["status"] for r in rs] == ["unauthorized", "circuit_open", "circuit_open"]


def test_transient_failure_is_raised_out_of_the_cache(app, monkeypatch):
    monkeypatch.setattr(app._ss, "fetch_stocktwits_approved",
                        lambda *a, **k: {"status": "network_error", "score": None})
    with pytest.raises(app._StocktwitsTransient):
        app._fetch_stocktwits_cached("AAA", "24h", "u", "p")


def test_attach_keeps_the_original_fetch_time(db, monkeypatch):
    app = db
    monkeypatch.setenv("STOCKTWITS_API_USERNAME", "u")
    monkeypatch.setenv("STOCKTWITS_API_PASSWORD", "p")
    rec = ss.normalize_stocktwits(_payload(55), "AAA", "24h") | {"fetched_at": "2026-01-01T00:00:00+00:00"}
    monkeypatch.setattr(app, "_fetch_stocktwits_cached", lambda *a, **k: rec)
    r = [{"ticker": "AAA"}]
    app.attach_retail_sentiment(r)
    assert r[0]["stocktwits"]["fetched_at"] == "2026-01-01T00:00:00+00:00"


def test_missing_stocktwits_is_absent_from_candidates_not_neutral(app):
    idx = pd.bdate_range("2026-01-05", periods=230)
    frame = pd.DataFrame({"Close": np.linspace(100, 120, 230)}, index=idx)
    ok = {"ticker": "AAA", "stocktwits": {"status": "ok", "score": 34.0, "message_volume_score": 65.0}}
    miss = {"ticker": "BBB", "stocktwits": {"status": "unavailable", "score": None}}
    app.get_histories = lambda *a, **k: {}
    app.attach_candidate_signals([ok, miss], histories={"AAA": frame, "BBB": frame})
    assert ok["candidates"]["stocktwits_score"] == 34.0, "stored as provided, not converted"
    assert "stocktwits_score" not in miss["candidates"], "missing must never become 50"


def _scan_fixture(app, monkeypatch, tickers, frame):
    monkeypatch.setattr(app, "TICKER_UNIVERSE", {"USA": list(tickers)})
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_expectations", lambda t: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})


def test_stocktwits_through_a_real_scan_is_persisted_and_changes_no_score(db, monkeypatch):
    app = db
    idx = pd.bdate_range("2026-01-05", periods=230)
    frame = pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)],
                          "Volume": [1e6] * 230}, index=idx)
    _scan_fixture(app, monkeypatch, ["AAA"], frame)
    off, _ = app.run_engine(regions=["USA"], sources=[])            # no credentials
    monkeypatch.setenv("STOCKTWITS_API_USERNAME", "u")
    monkeypatch.setenv("STOCKTWITS_API_PASSWORD", "p")
    rec = ss.normalize_stocktwits(_payload(34), "AAA", "24h")
    monkeypatch.setattr(app, "_fetch_stocktwits_cached", lambda *a, **k: rec)
    on, _ = app.run_engine(regions=["USA"], sources=[])
    for k in ("composite", "recommendation", "momentum", "value", "technical",
              "hype_score", "quality", "theme"):
        assert on[0][k] == off[0][k], f"Stocktwits must not change {k}"
    assert on[0]["setup_components"]["revisions"] == off[0]["setup_components"]["revisions"]
    with app.get_conn() as c:
        row = c.execute("SELECT retail_sentiment, candidates FROM observations").fetchone()
    stw = json.loads(row[0])["stocktwits"]
    assert stw["score"] == 34 and stw["label"] == "Bearish" and stw["buy_pct"] is None
    assert json.loads(row[1])["stocktwits_score"] == 34


# ================================================================= benchmarks
def test_every_suffix_resolves_intentionally(app):
    import config
    assert app.benchmark_for("AAPL") == "SPY"
    for suffix, bench in config.BENCHMARKS.items():
        if suffix:
            assert app.benchmark_for(f"XYZ.{suffix}") == bench
    for unmapped in ("ASML.AS", "NESN.SW", "SAN.MC", "ENI.MI", "VOLV-B.ST",
                     "NOVO-B.CO", "EQNR.OL", "NOKIA.HE"):
        assert app.benchmark_for(unmapped) is None, f"{unmapped} must not default to SPY"


def test_scan_with_an_unmapped_listing_does_not_crash(db, monkeypatch):
    """Mixing None into the benchmark set used to raise TypeError in sorted()."""
    app = db
    idx = pd.bdate_range("2026-01-05", periods=230)
    frame = pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)],
                          "Volume": [1e6] * 230}, index=idx)
    _scan_fixture(app, monkeypatch, ["AAA", "ASML.AS"], frame)
    res, failed = app.run_engine(regions=["USA"], sources=[])
    by = {r["ticker"]: r for r in res}
    assert "ASML.AS" in by, f"scan must survive an unmapped listing (failed={failed})"
    assert by["ASML.AS"]["momentum_basis"] == "no_benchmark"
    with app.get_conn() as c:
        bt = dict(c.execute("SELECT ticker, benchmark_type FROM observations").fetchall())
    assert bt["ASML.AS"] == "unavailable" and bt["AAA"] == "etf_total_return"


# ================================================================= explanation weights
def test_explanation_uses_the_weights_that_produced_the_score(db):
    app = db
    a = {f: 1 / 6 for f in app.FACTORS}
    r = {"momentum": 80.0, "value": 40.0, "technical": 60.0, "hype_score": 50.0,
         "quality": 70.0, "theme": 30.0}
    r.update(app.score_with_weights(r, a))
    r["weights_snapshot"] = dict(a)
    app.save_weights({"momentum": 0.5, "value": 0.1, "technical": 0.1, "hype": 0.1,
                      "quality": 0.1, "theme": 0.1}, note="changed after the scan")
    w, exact = app.explanation_weights(r)
    assert exact is True and w == a
    bd = app._pick_breakdown(r, w)
    assert float(bd["contribution"].sum()) == pytest.approx(r["composite"], abs=1e-6)


def test_legacy_result_is_labelled_approximate(db):
    w, exact = db.explanation_weights({"composite": 60.0})
    assert exact is False and w == db.get_latest_weights()


# ================================================================= level refresh
def test_refresh_never_mutates_the_scan_time_result(app, monkeypatch):
    idx = pd.bdate_range("2026-01-05", periods=260)
    fresh = pd.DataFrame({"Close": np.linspace(100, 160, 260), "High": np.linspace(101, 161, 260),
                          "Low": np.linspace(99, 159, 260)}, index=idx)
    monkeypatch.setattr(app, "_bulk_history", lambda t, period="1y": {"AAA": fresh})
    r = {"ticker": "AAA", "price": 120.0, "composite": 71.0, "recommendation": "BUY",
         "price_date": "2026-06-01", "entry_lo": 110.0, "entry_hi": 115.0,
         "target_level": 130.0, "stop_level": 105.0, "atr": 2.0, "sma20": 118.0, "sma50": 112.0}
    before = dict(r)
    assert app.refresh_levels_for(r) is True
    assert {k: r[k] for k in before} == before, "scan-time fields must be untouched"
    ll = r["live_levels"]
    assert ll["price"] == pytest.approx(160.0) and ll["price_asof"] == idx[-1].date().isoformat()
    assert ll["fetched_at"]


def test_failed_refresh_leaves_everything_intact(app, monkeypatch):
    monkeypatch.setattr(app, "_bulk_history", lambda t, period="1y": {})
    r = {"ticker": "AAA", "price": 120.0, "composite": 71.0}
    before = dict(r)
    assert app.refresh_levels_for(r) is False and r == before


# ================================================================= quintiles
def _insert(app, rows):
    with app.get_conn() as c:
        for d, rg, comp, x in rows:
            c.execute("INSERT INTO observations (scan_id, obs_date, ticker, region, composite, "
                      "rank_pct, factors, x20, model_version) VALUES (?,?,?,?,?,?,?,?,?)",
                      ("s", d, f"T{np.random.randint(1e9)}", rg, comp, 50.0, "{}", x,
                       app.PRODUCTION_MODEL_VERSION))


def test_calendar_drift_is_not_stock_selection(db):
    """Each date shifts EVERY name's score and outcome together, while within a date the
    score is unrelated to the outcome. Pooled quintiles would call that skill."""
    app = db
    rng = np.random.default_rng(0)
    rows = []
    for d in range(8):
        day = (date(2026, 3, 2) + pd.Timedelta(days=7 * d)).isoformat()
        shift = d * 6.0
        for _ in range(20):
            rows.append((day, "USA", 40 + shift + rng.uniform(0, 5), shift + rng.normal(0, 1)))
    _insert(app, rows)
    sm = app.composite_summary(20)
    assert sm["cohorts"] == 8
    assert abs(sm["spread"]) < 1.0, "no within-date skill exists, so no spread may appear"


def test_tied_and_thin_cohorts_are_excluded(db):
    app = db
    rows = [("2026-03-02", "USA", 60.0, float(i)) for i in range(30)]          # all tied
    rows += [("2026-03-09", "USA", float(i), float(i)) for i in range(5)]       # too thin
    rows += [("2026-03-16", "USA", float(i), 1.0) for i in range(30)]           # valid
    _insert(app, rows)
    sm = app.composite_summary(20)
    assert sm["cohorts"] == 1 and sm["excluded_cohorts"] == 2


# ================================================================= as-of dating / snapshots
def test_pick_asof_prefers_price_date(app):
    assert app._pick_asof({"price_date": "2026-10-09", "timestamp": "2026-10-11T09:00:00"}) \
        == pd.Timestamp("2026-10-09")
    assert app._pick_asof({"price_date": None, "timestamp": "2026-10-11T09:00:00"}) \
        == pd.Timestamp("2026-10-11T09:00:00"), "legacy rows fall back explicitly"


def test_observation_log_is_append_only(db):
    app = db
    row = {"ticker": "AAA", "region": "USA", "price": 1.0, "composite": 70.0,
           "recommendation": "HOLD", "momentum": 60, "value": 50, "technical": 55,
           "hype_score": 40, "quality": 60, "theme": 50, "price_date": "2026-10-09",
           "weights_snapshot": {f: 1 / 6 for f in app.FACTORS}}
    app.record_observations([row])
    row["composite"] = 72.0
    app.record_observations([row])
    with app.get_conn() as c:
        daily = c.execute("SELECT composite FROM observations").fetchall()
        snaps = c.execute("SELECT composite, scored_at, model_version, weights_snapshot "
                          "FROM observation_snapshots ORDER BY id").fetchall()
    assert [d[0] for d in daily] == [72.0], "daily view: one row, replaced"
    assert [s[0] for s in snaps] == [70.0, 72.0], "log: every scan kept"
    assert all(s[1] for s in snaps) and snaps[0][2] == app.PRODUCTION_MODEL_VERSION
    assert set(json.loads(snaps[0][3])) == set(app.FACTORS)
