"""Test-only helper: a fake urllib.request.urlopen so tests run the REAL jp_board_transport
(TLS context creation, redirect check, size bound, charset decoding) without a network.

    jp_fake_http.install(monkeypatch, html_or_callable_or_dict, calls_list)

`pages` may be a str (served for every URL), a dict url -> str|Exception|FakeResponse, or a
callable(url) -> str|Exception|FakeResponse. Exceptions are raised (HTTPError, URLError,
ssl.SSLError, TimeoutError ...). Fixtures only: nothing here talks to Yahoo!.
"""
from __future__ import annotations
import urllib.request


class _Headers:
    def __init__(self, charset):
        self._charset = charset

    def get_content_charset(self):
        return self._charset


class FakeResponse:
    def __init__(self, body: bytes, url: str, status: int = 200, charset: str | None = "utf-8"):
        self.body, self.url, self.status, self.headers = body, url, status, _Headers(charset)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def geturl(self):
        return self.url

    def read(self, n: int = -1):
        return self.body if n is None or n < 0 else self.body[:n]


def fake_urlopen(pages, calls=None):
    def _urlopen(req, timeout=None, context=None):
        url = getattr(req, "full_url", str(req))
        if calls is not None:
            calls.append(url)
        v = pages(url) if callable(pages) else (pages[url] if isinstance(pages, dict) else pages)
        if isinstance(v, BaseException):
            raise v
        if isinstance(v, FakeResponse):
            return v
        return FakeResponse(v.encode("utf-8"), url)
    return _urlopen


def install(monkeypatch, pages, calls=None):
    fake = fake_urlopen(pages, calls)
    monkeypatch.setattr(urllib.request, "urlopen", fake)    # the transport resolves it at call time
    return fake
