"""Reference implementations, NOT an integrated replacement for the stock app.
Network access uses the documented approved Stocktwits API only.
No credentials: no request. Pure helpers are covered by offline tests.
"""
from __future__ import annotations
import base64
import json
import math
import re
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from typing import Any
import pandas as pd

JP_LABELS = (
    '\u5f37\u304f\u8cb7\u3044\u305f\u3044',
    '\u8cb7\u3044\u305f\u3044',
    '\u69d8\u5b50\u898b',
    '\u58f2\u308a\u305f\u3044',
    '\u5f37\u304f\u58f2\u308a\u305f\u3044',
)

def parse_jp_five_categories(scoped_text: str) -> dict[str, Any] | None:
    """Parse LABEL THEN PERCENT text from ONE isolated poll component.
    Do not pass a whole page. Reverse layouts need a separate verified adapter.
    Accept decimals, reject duplicate labels, missing categories and invalid totals.
    """
    alternatives = '|'.join(re.escape(x) for x in sorted(JP_LABELS, key=len, reverse=True))
    pattern = rf'(?P<label>{alternatives})\s*[:\uff1a]?\s*(?P<value>\d+(?:\.\d+)?)\s*[%\uff05]'
    values: dict[str, float] = {}
    for match in re.finditer(pattern, scoped_text):
        label, value = match['label'], float(match['value'])
        if label in values or not 0 <= value <= 100:
            return None
        values[label] = value
    if set(values) != set(JP_LABELS):
        return None
    # Proposed tolerance for display rounding, not a provider guarantee.
    if abs(sum(values.values()) - 100.0) > 2.5:
        return None
    return {
        'buy_pct': values[JP_LABELS[0]] + values[JP_LABELS[1]],
        'neutral_pct': values[JP_LABELS[2]],
        'sell_pct': values[JP_LABELS[3]] + values[JP_LABELS[4]],
        'categories': values,
        'metric_type': 'posting_sentiment_distribution',
        'source': 'yahoo_jp_board',
    }

def aligned_volume_confirmation(close: pd.Series, volume: pd.Series | None) -> bool:
    """Require all 25 immediately preceding price sessions to have valid volume.
    Compare latest five with preceding twenty; never bridge missing sessions.
    Caller must provide completed, exchange-local session-indexed bars.
    """
    c = close.dropna().sort_index()
    if volume is None or len(c) < 25 or c.index.has_duplicates or volume.index.has_duplicates:
        return False
    v = pd.to_numeric(volume.reindex(c.index[-25:]), errors='coerce')
    if v.isna().any() or not v.map(lambda x: math.isfinite(float(x)) and x > 0).all():
        return False
    return bool(v.iloc[-5:].mean() > 1.10 * v.iloc[:-5].mean())

def _score(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        value = float(value)
    except (ValueError, TypeError):
        return None
    return value if math.isfinite(value) and 0 <= value <= 100 else None

def normalize_stocktwits(payload: dict, symbol: str, window: str) -> dict:
    """Use documented valueNormalized/labelNormalized; never infer percentages.
    Exact requested window only. Do not silently substitute 15m for 24h.
    """
    now = datetime.now(timezone.utc).isoformat()
    out = {
        'source': 'stocktwits', 'symbol': symbol, 'window': window,
        'metric_type': 'provider_normalized_sentiment', 'status': 'unavailable',
        'score': None, 'label': None, 'message_volume_score': None,
        'buy_pct': None, 'sell_pct': None,
        'fetched_at': now, 'provider_asof': None,
        'parser_version': 'stocktwits-detail-v1',
    }
    data = payload.get('data')
    if not isinstance(data, dict):
        return out
    sentiment = data.get('sentiment')
    item = sentiment.get(window) if isinstance(sentiment, dict) else None
    if not isinstance(item, dict):
        return out
    score = _score(item.get('valueNormalized'))
    if score is None:
        return out
    label = item.get('labelNormalized')
    out.update(status='ok', score=score, label=label if isinstance(label, str) else None)
    volume = data.get('messageVolume')
    vol_item = volume.get(window) if isinstance(volume, dict) else None
    if isinstance(vol_item, dict):
        out['message_volume_score'] = _score(vol_item.get('valueNormalized'))
    return out

def fetch_stocktwits_approved(symbol: str, username: str | None, password: str | None,
                             window: str = '24h', timeout: float = 8.0) -> dict:
    """Reference synchronous client. Caller adds caching and request budgeting.
    Credentials must be APPROVED API credentials, not a consumer account login.
    Live authentication/entitlement is not tested in this reference package.
    """
    symbol = symbol.strip().upper()
    empty = normalize_stocktwits({}, symbol, window)
    if not username or not password:
        return dict(empty, status='not_configured')
    if not re.fullmatch(r'[A-Z0-9][A-Z0-9.\-]{0,19}', symbol):
        return dict(empty, status='invalid_symbol')
    url = ('https://api-gw-prd.stocktwits.com/api-middleware/external/sentiment/v2/'
           + urllib.parse.quote(symbol, safe='') + '/detail')
    token = base64.b64encode(f'{username}:{password}'.encode()).decode()
    req = urllib.request.Request(url, headers={
        'Authorization': 'Basic ' + token, 'Accept': 'application/json',
        'User-Agent': 'AlphaQuantResearch/1.0',
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read(1_000_001)
        if len(raw) > 1_000_000:
            return dict(empty, status='invalid_response')
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            return dict(empty, status='invalid_response')
        return normalize_stocktwits(payload, symbol, window)
    except urllib.error.HTTPError as exc:
        status = {401: 'unauthorized', 403: 'forbidden', 429: 'rate_limited'}.get(exc.code, 'http_error')
        # Do not log request headers, credentials, or response bodies.
        return dict(empty, status=status)
    except (urllib.error.URLError, TimeoutError, OSError):
        return dict(empty, status='network_error')
    except (ValueError, UnicodeError):
        return dict(empty, status='invalid_response')
