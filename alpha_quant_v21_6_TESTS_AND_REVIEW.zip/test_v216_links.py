"""v21.6 tests — "Open on Stocktwits" / "Open Yahoo!掲示板" links in the Deep Dive cards.

The links are for the user to read a source's public page in a browser. They are LINKS ONLY:
building or rendering them makes no request, and nothing on those pages enters the app,
the ledger or any score. Run: pytest -q test_v216_links.py
"""
import os
import sys
import types
import urllib.request

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))


class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getitem__(self, i): return _Any()
    def __bool__(self): return False
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    def __getattr__(self, n): return _Any()
    def columns(self, spec, **k):
        return [_Any() for _ in range(spec if isinstance(spec, int) else len(spec))]
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    sys.path.insert(0, HERE)
    spec = importlib.util.spec_from_file_location("app_v216", os.path.join(HERE, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


# ============================================================ the URLs
@pytest.mark.parametrize("ticker,stocktwits,jp", [
    ("AAPL", "https://stocktwits.com/symbol/AAPL", None),
    ("msft", "https://stocktwits.com/symbol/MSFT", None),
    ("BRK-B", "https://stocktwits.com/symbol/BRK.B", None),          # explicit share-class map
    ("BF-B", "https://stocktwits.com/symbol/BF.B", None),
    ("BABA", "https://stocktwits.com/symbol/BABA", None),            # a US-listed ADR: its own page
    ("7203.T", None, "https://finance.yahoo.co.jp/quote/7203.T/forum"),
    ("285A.T", None, "https://finance.yahoo.co.jp/quote/285A.T/forum"),
    ("7203.t", None, "https://finance.yahoo.co.jp/quote/7203.T/forum"),
])
def test_links_point_at_the_right_public_page(app, ticker, stocktwits, jp):
    assert app.source_links(ticker) == {"stocktwits": stocktwits, "jp_board": jp}


@pytest.mark.parametrize("ticker", ["SHEL.L", "ASML.AS", "0700.HK", "^GSPC", "XYZ-W", "7203.T/../x",
                                    "72030.T", "7203", "", None, "javascript:alert(1)", "AA PL"])
def test_no_link_for_anything_that_is_not_a_clean_us_or_tokyo_listing(app, ticker):
    assert app.source_links(ticker) == {"stocktwits": None, "jp_board": None}


def test_a_foreign_listing_is_never_sent_to_its_us_adr_page(app):
    assert app.source_links("SHEL.L")["stocktwits"] is None and app.source_links("SHEL")["stocktwits"].endswith("/SHEL")


def test_building_links_makes_no_request(app, monkeypatch):
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: pytest.fail("a link must not fetch"))
    for t in ("AAPL", "7203.T", "BRK-B"):
        app.source_links(t)


# ============================================================ the panel, in real Streamlit, both languages
@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    from test_v213_hype_panel import PANEL_SCRIPT, PANEL_DRIVER, _run_driver, JP_BASE, US_BASE
    cases = {
        "us": dict(US_BASE),
        "us_share_class": dict(US_BASE, ticker="BRK-B"),
        "jp": dict(JP_BASE),
        "jp_blocked": dict(JP_BASE, jp_forum_enabled=True, jp_board={"status": "unavailable", "reason": "http_403"}),
        "uk": {"ticker": "SHEL.L", "hype_score": 40.0},
    }
    batch = {f"{n}|{lang}": {"record": r, "lang": lang} for n, r in cases.items() for lang in ("en", "ja")}
    res = _run_driver(PANEL_DRIVER, tmp_path_factory.mktemp("links"), batch, PANEL_SCRIPT)
    for k, v in res.items():
        assert not v["exceptions"], (k, v["exceptions"])
    return res


def T(key, lang="en"):
    import config
    return config.TRANSLATIONS[lang][key]


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_a_us_stock_gets_exactly_the_stocktwits_link(panel, lang):
    links = panel[f"us|{lang}"]["link_button"]
    assert links == [{"label": T("hype_open_stocktwits", lang), "url": "https://stocktwits.com/symbol/AAPL",
                      "help": T("hype_link_help", lang)}]


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_a_tokyo_stock_gets_exactly_the_board_link_even_when_the_fetch_was_blocked(panel, lang):
    for name in ("jp", "jp_blocked"):
        links = panel[f"{name}|{lang}"]["link_button"]
        assert links == [{"label": T("hype_open_jp_board", lang),
                          "url": "https://finance.yahoo.co.jp/quote/7203.T/forum",
                          "help": T("hype_link_help", lang)}], name


def test_share_classes_link_to_the_mapped_symbol(panel):
    assert panel["us_share_class|en"]["link_button"][0]["url"] == "https://stocktwits.com/symbol/BRK.B"


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_a_listing_neither_source_covers_gets_no_link(panel, lang):
    assert panel[f"uk|{lang}"]["link_button"] == []


def test_the_tooltip_says_nothing_is_read_back(panel):
    h = panel["us|en"]["link_button"][0]["help"]
    assert "Nothing is fetched or read back" in h and "score does not change" in h


def test_rendering_with_links_still_fetches_nothing(panel):
    """The batch runs every case with urlopen and every data-source function booby-trapped
    (see test_v213_hype_panel.PANEL_SCRIPT); no case raised, so no link render fetched."""
    assert len(panel) == 10 and all(not v["exceptions"] for v in panel.values())
