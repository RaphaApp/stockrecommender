"""P0 regression tests: Japan board parser, stale-volume confirmation, demo isolation.

Offline and deterministic: synthetic HTML/price frames, a temp SQLite database, and
fixed weekday dates (never a bare date.today() offset as an entry date).
Every test here was mutation-checked: restoring the original bug makes it fail.
Run: pytest -q test_p0_fixes.py
"""
import json
import os
import sys
import types
from datetime import date, timedelta

import jp_fake_http
import numpy as np
import pandas as pd
import pytest

import sentiment_sources as ss
from indicators import aligned_volume_confirmation, early_setup, forum_sentiment_score

SB, B, N, S, SS = ss.JP_LABELS
HEAD = ss.JP_POLL_HEADINGS[0]            # "みんなの評価": parsing is scoped to its section


def poll(values):
    return f"{HEAD} " + " ".join(f"{lab}{val}%" for lab, val in zip(ss.JP_LABELS, values))


# ================================================================= Japan board parser
def test_five_categories_aggregate_correctly():
    """The old parser read 強く買いたい as 買いたい: this 67%-sell poll became 10/30."""
    r = ss.parse_jp_board(f"<div>{poll([10, 21, 2, 30, 37])}</div>")
    assert r["status"] == "ok" and r["layout"] == "five_category"
    assert (r["buy_pct"], r["neutral_pct"], r["sell_pct"]) == (31, 2, 67)
    assert r["categories"][SB] == 10 and r["categories"][SS] == 37


def test_decimal_categories():
    """Old parser accepted integers only and returned (0, 0) here."""
    r = ss.parse_jp_board(poll([33.33, 0, 0, 0, 66.67]))
    assert r["buy_pct"] == pytest.approx(33.33) and r["sell_pct"] == pytest.approx(66.67)


def test_one_percentage_cannot_bind_two_labels():
    """Old parser: '31%買いたい 売りたい67%' -> (67, 67). A mixed layout is rejected."""
    r = ss.parse_jp_board(f"{HEAD} 31%{B} {S}67%")
    assert r["status"] != "ok" and r["buy_pct"] is None


def test_simple_label_first_layout_still_works():
    r = ss.parse_jp_board(f"{HEAD} {B}31% {S}67%")
    assert r["status"] == "ok" and (r["buy_pct"], r["sell_pct"]) == (31, 67)


def test_percent_first_layout_is_its_own_adapter():
    r = ss.parse_jp_board(f"{HEAD} <b>64%</b>{B} <b>9%</b>{S}")
    assert r["status"] == "ok" and r["layout"] == "two_category_percent_first"
    assert (r["buy_pct"], r["sell_pct"]) == (64, 9)


def test_duplicate_components_counted_once():
    page = f"<div class=pc>{poll([10, 21, 2, 30, 37])}</div><div class=sp>{poll([10, 21, 2, 30, 37])}</div>"
    r = ss.parse_jp_board(page)
    assert r["status"] == "ok" and r["buy_pct"] == 31, "duplicates must not be summed"


def test_disagreeing_duplicates_are_ambiguous():
    page = poll([10, 21, 2, 30, 37]) + " ... " + poll([40, 21, 2, 0, 37])
    assert ss.parse_jp_board(page)["status"] == "ambiguous"


def test_unrelated_percentages_are_ignored():
    page = f"前日比 +2.35% 年初来 -12.1% {poll([10, 21, 2, 30, 37])} 信用倍率 15%"
    r = ss.parse_jp_board(page)
    assert (r["buy_pct"], r["sell_pct"]) == (31, 67)


def test_broken_five_category_never_falls_back_to_two_category():
    """With strong labels present, a two-category read would bind inside 強く…"""
    r = ss.parse_jp_board(f"{HEAD} {SB}10% {B}21% {S}30%")
    assert r["status"] == "parse_error" and r["buy_pct"] is None


@pytest.mark.parametrize("page", ["", "<html>Access denied</html>",
                                  poll([10, 20, 30, 40, 50]), poll([0, 0, 0, 0, 0])])
def test_malformed_or_blocked_is_unavailable_not_a_number(page):
    r = ss.parse_jp_board(page)
    assert r["status"] in ("unavailable", "parse_error") and r["buy_pct"] is None


# ================================================================= stale volume
def _vol_frame(n=60):
    idx = pd.bdate_range("2026-01-05", periods=n)
    return pd.Series(100.0, index=idx), idx


def test_valid_expansion_confirms():
    c, idx = _vol_frame()
    v = pd.Series([1e6] * (len(idx) - 5) + [1.13e6] * 5, index=idx)
    assert aligned_volume_confirmation(c, v) is True


@pytest.mark.parametrize("mutate", ["stale_last", "missing_interior", "zero", "negative",
                                    "infinite", "duplicated", "flat", "short"])
def test_invalid_volume_never_confirms(mutate):
    c, idx = _vol_frame()
    v = pd.Series([1e6] * (len(idx) - 5) + [2e6] * 5, index=idx)
    if mutate == "stale_last":
        v = v.iloc[:-1]
    elif mutate == "missing_interior":
        v = v.drop(idx[-10])
    elif mutate == "zero":
        v.iloc[-12] = 0.0
    elif mutate == "negative":
        v.iloc[-12] = -5.0
    elif mutate == "infinite":
        v.iloc[-12] = np.inf
    elif mutate == "duplicated":
        v = pd.concat([v, v.iloc[[-1]]])
    elif mutate == "flat":
        v = pd.Series(1e6, index=idx)
    elif mutate == "short":
        c, v = c.iloc[-20:], v.iloc[-20:]
    assert aligned_volume_confirmation(c, v) is False


def test_stale_volume_is_the_sole_reason_confirmation_fails():
    """End to end: price and technical breakout both TRUE; only the volume is stale.
    The previous raw-tail code confirmed this (volume_available False yet
    volume_confirmed True)."""
    closes = [100.0 * 1.002 ** i for i in range(180)]
    base = closes[-1]
    closes += [base * (1 + 0.004 * i) for i in range(12)] + [base * 1.048 * 1.03]
    idx = pd.bdate_range("2026-01-05", periods=len(closes))
    c = pd.Series(closes, index=idx)
    fresh = pd.Series([1e6] * (len(idx) - 5) + [4e6] * 5, index=idx)
    ok = early_setup(c, fresh)
    assert ok["technical_breakout"] and ok["price_breakout"] and ok["volume_confirmed"]

    stale = fresh.iloc[:-1]                       # volume stopped one session early
    out = early_setup(c, stale)
    assert out["technical_breakout"] is True and out["price_breakout"] is True
    assert out["volume_confirmed"] is False and out["confirmed"] is False
    assert out["state"] != "CONFIRMED"
    assert out["data_quality"]["volume_available"] is False


# ================================================================= app fixtures
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    def __getattr__(self, n): return _Any()
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, here)
    spec = importlib.util.spec_from_file_location("app_p0", os.path.join(here, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    return app


def _live_snapshot(app):
    with app.get_conn() as c:
        return {t: [tuple(r) for r in c.execute(f"SELECT * FROM {t} ORDER BY 1")]
                for t in ("recommendations", "kpi_weights", "system_weights",
                          "observations", "mock_portfolio")}


# ================================================================= demo isolation
def test_demo_seed_and_clear_leave_live_state_untouched(db):
    app = db
    before, weights = _live_snapshot(app), app.get_latest_weights()
    app.seed_demo_history()
    app.seed_demo_history()                       # idempotent reseed
    assert _live_snapshot(app) == before, "demo seeding must not write live tables"
    assert app.get_latest_weights() == weights, "demo seeding must not move live weights"
    demo = app.get_recommendations(demo=True)
    assert len(demo) == 40, "reseeding replaces, never duplicates"
    assert len(app.get_weight_history(demo=True)) == 6
    app.clear_demo_data()
    assert not os.path.exists(app.DEMO_DB_PATH)
    assert _live_snapshot(app) == before


def test_old_demo_contamination_is_detected_not_deleted(db):
    app = db
    app.save_weights({f: 1 / 6 for f in app.FACTORS}, note=app.DEMO_WEIGHT_NOTE)
    cont = app.live_demo_contamination()
    assert cont["active_weights_are_demo"] and cont["weight_rows"] == 1
    assert len(app.get_weight_history()) >= 2, "history is reported, not deleted"


# ================================================================= JP through a real scan
def test_jp_poll_flows_through_run_engine_and_ledger(db, monkeypatch):
    """Real run_engine with a mocked provider fetch: displayed values, the persisted
    snapshot and the composite's hype input all match the existing formula."""
    app = db
    idx = pd.bdate_range("2026-01-05", periods=230)
    frame = pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)],
                          "Volume": [1e6] * 230}, index=idx)
    # Mock at the HTTP layer so the REAL fetch -> parse -> score -> persist chain runs.
    page = f"<html><body><p>前日比 +1.2%</p><div>{poll([10, 21, 2, 30, 37])}</div></body></html>"
    calls = []
    jp_fake_http.install(monkeypatch, page, calls)
    # run_engine reads TICKER_UNIVERSE + promotions directly (not effective_universe)
    monkeypatch.setattr(app, "TICKER_UNIVERSE", {"Japan": ["7203.T"]})
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})

    on, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    assert len(calls) == 1 and "7203.T" in calls[0]
    r = on[0]
    assert (r["jp_bull"], r["jp_bear"]) == (31.0, 67.0)
    with app.get_conn() as c:
        rs = json.loads(c.execute("SELECT retail_sentiment FROM observations").fetchone()[0])
    assert rs["jp_board"]["buy_pct"] == 31 and rs["jp_board"]["neutral_pct"] == 2
    assert rs["jp_board"]["parser_version"] == ss.JP_PARSER_VERSION

    calls.clear()
    off, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=False)
    assert calls == [], "toggle off -> no fetch"
    base, fs = off[0]["hype_score"], forum_sentiment_score(31.0, 67.0)
    # the unchanged blend: 0.5 * volume-hype + 0.5 * forum score (before squeeze bonus)
    assert r["hype_score"] == pytest.approx(min(100.0, max(0.0, 0.5 * base + 0.5 * fs)))
