import math
import pandas as pd
import pytest
import review_examples as r

def poll(values):
    return ' '.join(f'{label}: {value}%' for label, value in zip(r.JP_LABELS, values))

def test_decimal_five_category_poll():
    got = r.parse_jp_five_categories(poll([33.33,0,0,0,66.67]))
    assert got['buy_pct'] == pytest.approx(33.33)
    assert got['sell_pct'] == pytest.approx(66.67)

def test_all_five_categories_aggregate():
    got = r.parse_jp_five_categories(poll([10,21,2,30,37]))
    assert (got['buy_pct'],got['neutral_pct'],got['sell_pct']) == (31,2,67)

@pytest.mark.parametrize('text', [poll([10,20,30,40,50]), poll([0,0,0,0,0]),
    poll([10,20,30,20,20])+' '+poll([10,20,30,20,20]), '31% buy 67% sell'])
def test_ambiguous_or_invalid_poll_rejected(text):
    assert r.parse_jp_five_categories(text) is None

def test_current_volume_expansion():
    idx=pd.bdate_range('2026-01-05',periods=30)
    c=pd.Series(100.,index=idx)
    v=pd.Series([1e6]*25+[1.13e6]*5,index=idx)
    assert r.aligned_volume_confirmation(c,v)
    assert not r.aligned_volume_confirmation(c,v.iloc[:-1])
    assert not r.aligned_volume_confirmation(c,v.drop(idx[-10]))
    v.iloc[-1]=0
    assert not r.aligned_volume_confirmation(c,v)

def payload(score=34):
    return {'data':{'sentiment':{'24h':{'valueNormalized':score,'labelNormalized':'Bearish'}},
        'messageVolume':{'24h':{'valueNormalized':65}}}}

def test_provider_score_is_not_buy_percentage():
    got=r.normalize_stocktwits(payload(),'SHEL','24h')
    assert got['score']==34 and got['label']=='Bearish'
    assert got['buy_pct'] is None and got['sell_pct'] is None
    assert got['message_volume_score']==65

def test_window_never_substituted():
    assert r.normalize_stocktwits(payload(),'SHEL','15m')['status']=='unavailable'

@pytest.mark.parametrize('score',[None,math.nan,math.inf,-1,101,True,'bad'])
def test_invalid_provider_scores(score):
    assert r.normalize_stocktwits(payload(score),'SHEL','24h')['status']=='unavailable'

def test_zero_is_valid_not_missing():
    assert r.normalize_stocktwits(payload(0),'SHEL','24h')['score']==0

def test_no_credentials_means_no_request(monkeypatch):
    def fail(*a,**kw):
        raise AssertionError('must not request without credentials')
    monkeypatch.setattr(r.urllib.request,'urlopen',fail)
    assert r.fetch_stocktwits_approved('SHEL',None,None)['status']=='not_configured'
