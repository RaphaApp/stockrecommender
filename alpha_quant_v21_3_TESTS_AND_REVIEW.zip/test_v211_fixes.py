"""v21.1 regression tests — the six findings from the independent review of v21.

  1. Japan parser accepted polls the scorers then skipped (101% total)
  2. Japan adapter did not isolate the poll widget (no heading required; a malformed
     duplicate was ignored)
  3. Duplicate volume dates crashed Early Setup; the confirmation-volume flag disagreed
     with the confirmation itself (zero volume)
  4. Stocktwits candidates were labelled "production" in the Model Lab
  5. Historical Accuracy counted outcomes of unknown provenance as verified
  6. Initialising the DEMO database touched (and failed on) the LIVE database

Offline and deterministic. Each test was mutation-checked against the v21 behaviour.
Run: pytest -q test_v211_fixes.py
"""
import os
import sys
import types

import numpy as np
import pandas as pd
import pytest

import indicators
import sentiment_sources as ss
from indicators import (aligned_volume_window, early_setup, forum_euphoria_sell_score,
                        forum_sentiment_score)

SB, B, N, S, SS = ss.JP_LABELS
HEAD = ss.JP_POLL_HEADINGS[0]


def poll(values, head=True):
    body = " ".join(f"{lab}{val}%" for lab, val in zip(ss.JP_LABELS, values))
    return f"{HEAD} {body}" if head else body


# ======================================================== 1. one policy, parser == scorer
def test_one_shared_rounding_tolerance():
    assert ss._TOTAL_TOLERANCE == indicators.JP_POLL_ROUNDING_TOLERANCE == 2.5


def test_a_101_percent_poll_is_shown_AND_scored():
    r = ss.parse_jp_board(poll([30, 30.5, 0, 20, 20.5]))               # totals 101
    assert r["status"] == "ok" and (r["buy_pct"], r["sell_pct"]) == (60.5, 40.5)
    # raw displayed values are kept, not renormalised; the scorer uses the net spread
    assert forum_sentiment_score(60.5, 40.5) == pytest.approx(50 + 20 * 0.7)
    assert forum_euphoria_sell_score(60.5, 40.5) is not None


def test_beyond_the_tolerance_both_sides_reject():
    assert ss.parse_jp_board(poll([30, 30.5, 0, 20, 23]))["status"] != "ok"     # 103.5
    assert forum_sentiment_score(60.5, 43.0) is None
    assert forum_euphoria_sell_score(60.5, 43.0) is None


def test_every_poll_the_parser_accepts_is_scorable():
    """Property check over 5,000 seeded random polls: no accepted poll may be skipped
    by the scorers. Random sampling alone missed boundary cases (see test_v212_fixes
    for the deterministic boundary grid)."""
    rng = np.random.default_rng(11)
    accepted = 0
    for _ in range(5000):
        vals = [round(float(rng.uniform(0, 60)), int(rng.integers(0, 3))) for _ in range(5)]
        r = ss.parse_jp_board(poll(vals))
        if r["status"] != "ok":
            continue
        accepted += 1
        # no exclusions: v21.1 skipped 0/0 here, which is how the all-様子見 poll slipped through
        n = r["neutral_pct"]
        assert forum_sentiment_score(r["buy_pct"], r["sell_pct"], n) is not None, vals
        assert forum_euphoria_sell_score(r["buy_pct"], r["sell_pct"], n) is not None, vals
    assert accepted > 50, "the generator must actually produce accepted polls"


# ======================================================== 2. isolation
def test_category_text_without_the_poll_heading_is_not_a_poll():
    r = ss.parse_jp_board(poll([10, 21, 2, 30, 37], head=False))
    assert r["status"] == "unavailable" and r["reason"] == "poll_heading_not_found"
    assert r["buy_pct"] is None


def test_valid_component_plus_malformed_duplicate_is_ambiguous():
    page = poll([10, 21, 2, 30, 37]) + " ... " + f"{HEAD} {SB}10% {B}21% {N}2% {S}30%"
    r = ss.parse_jp_board(page)
    assert r["status"] == "ambiguous" and r["buy_pct"] is None


def test_look_alike_labels_outside_the_scope_are_ignored():
    page = f"{SB}99% {B}1% " + "x" * 700 + poll([10, 21, 2, 30, 37])
    r = ss.parse_jp_board(page)
    assert (r["buy_pct"], r["sell_pct"]) == (31, 67)


def test_a_heading_menu_link_without_a_poll_is_ignored():
    r = ss.parse_jp_board(f"{HEAD} 掲示板 " + "x" * 700 + poll([10, 21, 2, 30, 37]))
    assert r["status"] == "ok" and r["buy_pct"] == 31


def test_scope_ends_at_the_next_heading():
    """Two adjacent widgets must be two scopes, not one merged poll."""
    one = poll([10, 21, 2, 30, 37])
    r = ss.parse_jp_board(one + " " + one)
    assert r["status"] == "ok" and "2 agreeing" in r["reason"]


# ======================================================== 3. volume validity decided once
def _px(n=200):
    idx = pd.bdate_range("2026-01-05", periods=n)
    return pd.Series([100 * 1.002 ** i for i in range(n)], index=idx), idx


def test_duplicate_volume_dates_do_not_crash_and_are_not_usable():
    c, idx = _px()
    v = pd.Series(1e6, index=idx)
    dup = pd.concat([v, v.iloc[[-1]]])
    out = early_setup(c, dup)                       # used to raise ValueError
    q = out["data_quality"]
    assert q["volume_available"] is False and q["confirmation_volume_available"] is False
    assert out["volume_confirmed"] is False and out["confirmed"] is False
    assert out["components"]["accumulation"] == 50.0


def test_zero_volume_is_not_confirmation_volume():
    c, idx = _px()
    v = pd.Series(1e6, index=idx)
    v.iloc[-3] = 0.0
    assert early_setup(c, v)["data_quality"]["confirmation_volume_available"] is False


def test_valid_flat_volume_is_available_but_does_not_confirm():
    c, idx = _px()
    out = early_setup(c, pd.Series(1e6, index=idx))
    assert out["data_quality"]["confirmation_volume_available"] is True
    assert out["volume_confirmed"] is False


def test_the_flag_and_the_confirmation_cannot_disagree():
    """volume_confirmed implies confirmation_volume_available, across stale / gappy /
    zero / duplicated / absent / valid volume on 300 random price paths."""
    rng = np.random.default_rng(5)
    for t in range(300):
        n = int(rng.integers(60, 240))
        idx = pd.bdate_range("2025-02-03", periods=n)
        c = pd.Series(100 * np.exp(np.cumsum(rng.normal(0.0005, 0.01, n))), index=idx)
        v = pd.Series(rng.uniform(5e5, 3e6, n), index=idx)
        v.iloc[-5:] *= 2.0
        k = t % 7
        if k == 1: v = v.iloc[:-2]
        if k == 2: v = v.drop(idx[n - 10])
        if k == 3: v.iloc[n - 12] = 0.0
        if k == 4: v = pd.concat([v, v.iloc[[-1]]])
        if k == 5: v = None
        out = early_setup(c, v)
        if out is None:
            continue
        if out["volume_confirmed"]:
            assert out["data_quality"]["confirmation_volume_available"] is True
        assert out["confirmed"] == (out["technical_breakout"] and out["price_breakout"]
                                    and out["volume_confirmed"])


def test_aligned_volume_window_contract():
    c, idx = _px()
    v = pd.Series(1e6, index=idx)
    assert aligned_volume_window(c, v, 25) is not None
    assert aligned_volume_window(c, v.iloc[:-1], 25) is None            # stale
    assert aligned_volume_window(c, None, 25) is None
    assert aligned_volume_window(c.iloc[:20], v.iloc[:20], 25) is None  # too short


# ======================================================== app fixtures
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getitem__(self, i): return _Any()          # st.columns(3)[0]
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    def __getattr__(self, n): return _Any()
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, here)
    spec = importlib.util.spec_from_file_location("app_v211", os.path.join(here, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    return app


# ======================================================== 1 + 2 through a real scan
def test_a_101_percent_poll_reaches_the_composite_through_run_engine(db, monkeypatch):
    app = db
    idx = pd.bdate_range("2026-01-05", periods=230)
    frame = pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)],
                          "Volume": [1e6] * 230}, index=idx)
    page = f"<html><body>{poll([30, 30.5, 0, 20, 20.5])}</body></html>"
    monkeypatch.setattr(app, "_reddit_get", lambda url, headers=None: page)
    monkeypatch.setattr(app, "TICKER_UNIVERSE", {"Japan": ["7203.T"]})
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})
    on, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    off, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=False)
    assert (on[0]["jp_bull"], on[0]["jp_bear"]) == (60.5, 40.5)
    base, fs = off[0]["hype_score"], forum_sentiment_score(60.5, 40.5)
    assert on[0]["hype_score"] == pytest.approx(min(100.0, max(0.0, 0.5 * base + 0.5 * fs))), \
        "a poll shown on screen must actually contribute to the score"


# ======================================================== 4. candidate labelling
def test_every_candidate_key_the_scan_can_write_is_a_labelled_candidate(app, monkeypatch):
    idx = pd.bdate_range("2026-01-05", periods=230)
    frame = pd.DataFrame({"Close": np.linspace(100, 130, 230)}, index=idx)
    monkeypatch.setattr(app, "get_histories", lambda *a, **k: {})
    r = {"ticker": "AAA",
         "expectations": {k: 60.0 for k in ("expectations_score", "eps_revision_score",
                                            "eps_trend_score", "forward_growth_score",
                                            "earnings_surprise_score")},
         "stocktwits": {"status": "ok", "score": 34.0, "message_volume_score": 65.0}}
    app.attach_candidate_signals([r], histories={"AAA": frame})
    keys = set(r["candidates"])
    assert {"stocktwits_score", "stocktwits_attention"} <= keys
    import config
    for k in keys:
        assert app.signal_kind(k) == "candidate", f"{k} would be shown as production"
        assert k in app.SIGNAL_LABEL_KEYS, f"{k} has no display name"
        tk = app.SIGNAL_LABEL_KEYS[k]
        assert tk in config.TRANSLATIONS["en"] and tk in config.TRANSLATIONS["ja"], tk


def test_the_rendered_ic_table_classifies_stocktwits_as_candidate(app):
    ic = pd.DataFrame({"signal": ["momentum", "hype", "stocktwits_score", "stocktwits_attention"],
                       "mean_ic": [0.04, 0.01, 0.02, -0.01], "n_dates": [12] * 4,
                       "pct_positive": [60.0] * 4, "n_obs": [300] * 4})
    out = app.ic_display_frame(ic).set_index(ic["signal"])
    cand, prod = app.tr("ic_kind_candidate"), app.tr("ic_kind_production")
    assert out.loc["momentum", "kind"] == prod and out.loc["hype", "kind"] == prod
    assert out.loc["stocktwits_score", "kind"] == cand
    assert out.loc["stocktwits_attention", "kind"] == cand
    assert not out["signal"].str.startswith("stocktwits_").any(), "raw keys must not be shown"


def test_production_factors_are_exactly_the_six(app):
    assert {f for f in app.FACTORS if app.signal_kind(f) == "production"} == set(app.FACTORS)
    assert app.signal_kind("some_future_signal") == "candidate"


# ======================================================== 5. accuracy provenance
def _recs(rows):
    return pd.DataFrame(rows, columns=["recommendation", "outcome", "outcome_basis"])


def test_only_benchmark_judged_outcomes_are_verified(app):
    df = _recs([("BUY", 1, "excess"), ("SELL", 0, "excess"),
                ("BUY", 1, "absolute"),
                ("BUY", 1, None), ("SELL", 1, None), ("BUY", 0, "legacy-other"),
                ("HOLD", 2, "excess"), ("BUY", 1, "excess"), ("BUY", None, "excess")])
    g = app.split_outcomes_by_basis(df)
    assert len(g["verified"]) == 3, "HOLD and unresolved outcomes are not directional results"
    assert len(g["absolute"]) == 1
    assert len(g["unknown"]) == 3, "NULL and unrecognised bases are never 'verified'"
    assert sum(len(x) for x in g.values()) == 7


def test_headline_excludes_legacy_and_suspected_demo_rows(app):
    # 40 old-seeder-style rows (basis NULL, all wins) must not inflate verified accuracy
    rows = [("BUY", 1, None)] * 40 + [("BUY", 1, "excess"), ("BUY", 0, "excess")]
    s = app.accuracy_summary(_recs(rows))
    assert len(s["headline"]) == 2 and s["win_rate"] == pytest.approx(50.0)
    assert len(s["groups"]["unknown"]) == 40, "kept and shown separately, not deleted"


def test_headline_is_blank_when_nothing_is_verified_yet(app):
    s = app.accuracy_summary(_recs([("BUY", 1, None), ("SELL", 0, None)]))
    assert s["headline"].empty and np.isnan(s["win_rate"])


def test_a_table_without_the_basis_column_is_all_unknown(app):
    df = pd.DataFrame({"recommendation": ["BUY", "SELL"], "outcome": [1, 0]})
    g = app.split_outcomes_by_basis(df)
    assert len(g["verified"]) == 0 and len(g["unknown"]) == 2


def test_demo_data_is_shown_whole(app):
    s = app.accuracy_summary(_recs([("BUY", 1, None), ("BUY", 0, None)]), demo=True)
    assert len(s["headline"]) == 2


# ======================================================== 6. demo init is self-contained
def test_demo_initialisation_never_touches_the_live_database(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live_never_created.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db(demo=True)                          # used to raise on the missing live table
    assert not os.path.exists(app.DB_PATH), "a demo init created a LIVE database file"
    assert len(app.get_weight_history(demo=True)) == 1       # demo got its own defaults row


def test_seeding_works_with_no_live_database_at_all(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live_never_created.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.seed_demo_history()
    assert not os.path.exists(app.DB_PATH)
    assert len(app.get_recommendations(demo=True)) == 40


# ======================================================== Model Lab visibility (found while verifying 4)
def test_model_lab_is_shown_even_with_an_empty_mock_portfolio(db, monkeypatch):
    """The Model Lab reads the observations ledger only, yet it sat below the mock-
    portfolio section's early return — so a fresh database or a user with no mock picks
    silently never saw it."""
    app = db
    calls = []
    monkeypatch.setattr(app, "render_model_lab", lambda: calls.append(1))
    with app.get_conn() as c:
        c.execute("INSERT INTO recommendations (ticker, rec_date, recommendation, composite, "
                  "price_at_rec, price_after, outcome, eval_date, outcome_basis) "
                  "VALUES ('AAA','2026-03-02','BUY',70,100,105,1,'2026-03-20','excess')")
    assert app.get_mock_portfolio().empty
    app.render_engine_audit(update_prices=False)
    assert calls == [1], "Model Lab must render exactly once on the empty-portfolio path"
