"""v21.3 tests — the Hype panel in Deep Dive and enforcement of the Japan-poll opt-in.

Why these exist: v21.2 made the Japan poll "off by default" by changing the sidebar
toggle's DEFAULT, and its test asserted only that constant. Three other paths ignored the
toggle (the first-run quick-scan button, run_engine's own default, and the Sell Scanner,
which scored a 100 "euphoric" sell signal from the unverified parser). A constant is not
behaviour, so these tests drive the real code paths:

  * the real Streamlit renderer (AppTest) for the panel, in English and Japanese;
  * the real hero button, clicked with the toggle off and on, network blocked and recorded;
  * run_engine and analyze_sell_signals with a recording fetch.

Offline and deterministic. Each test was mutation-checked against the v21.2 behaviour.
Run: pytest -q test_v213_hype_panel.py
"""
import json
import os
import re
import sys
import textwrap
import types

import numpy as np
import pandas as pd
import pytest

import sentiment_sources as ss

HERE = os.path.dirname(os.path.abspath(__file__))
SB, B, N, S, SS = ss.JP_LABELS
HEAD = ss.JP_POLL_HEADINGS[0]
JP_TITLE = "みんなの評価"


# ============================================================ real-Streamlit panel harness
# Real Streamlit (AppTest) runs in a CLEAN SUBPROCESS: other test modules replace
# sys.modules["streamlit"] with a stub for in-process app imports, which would break an
# AppTest started later in the same pytest session. All panel cases share one subprocess.
import subprocess

PANEL_SCRIPT = textwrap.dedent('''
    import importlib.util, json, os, sys, urllib.request
    import streamlit as st
    HERE = %r
    sys.path.insert(0, HERE)
    if "appmod_cached" not in sys.modules:
        sp = importlib.util.spec_from_file_location("appmod_cached", os.path.join(HERE, "app.py"))
        mod = importlib.util.module_from_spec(sp); sys.modules["appmod_cached"] = mod
        sp.loader.exec_module(mod)
    m = sys.modules["appmod_cached"]
    case = json.loads(st.session_state["case_json"])
    st.session_state["lang"] = case["lang"]
    m._LAST_HYPE_STATUS = case.get("status", "")
    m._LAST_HYPE_FETCHED_AT = case.get("fetched", 0.0)
    # EVERY render runs with all data sources booby-trapped: the panel must fetch nothing.
    def _boom(*a, **k): raise AssertionError("the panel must not fetch anything")
    urllib.request.urlopen = _boom
    for name in ("_reddit_get", "fetch_stocktwits", "fetch_jp_forum_detail", "fetch_jp_forum_rating",
                 "_fetch_jp_board_cached", "_fetch_stocktwits_cached", "get_histories", "fetch_history",
                 "fetch_hype_signals", "fetch_fundamentals"):
        if hasattr(m, name): setattr(m, name, _boom)
    m.render_hype_sentiment(case["record"])
''') % HERE

PANEL_DRIVER = textwrap.dedent('''
    import json, sys
    from streamlit.testing.v1 import AppTest
    cases = json.load(open(sys.argv[1]))
    at = AppTest.from_string(open(sys.argv[2]).read(), default_timeout=120)
    out = {}
    for name, case in cases.items():
        at.session_state["case_json"] = json.dumps(case)
        at.run()
        out[name] = {
            "exceptions": [e.value for e in at.exception],
            "markdown": [x.value for x in at.markdown],
            "caption": [x.value for x in at.caption],
            "info": [x.value for x in at.info],
            "text": [x.value for x in at.text],
            "metric": {x.label: x.value for x in at.metric},
        }
    print("RESULT_JSON:" + json.dumps(out))
''')


def _run_driver(driver_src, tmp_path, payload, script_src, timeout=240):
    (tmp_path / "driver.py").write_text(driver_src)
    (tmp_path / "script.py").write_text(script_src)
    (tmp_path / "payload.json").write_text(json.dumps(payload))
    r = subprocess.run([sys.executable, str(tmp_path / "driver.py"), str(tmp_path / "payload.json"),
                        str(tmp_path / "script.py")], capture_output=True, text=True,
                       timeout=timeout, cwd=str(tmp_path))
    line = [l for l in r.stdout.splitlines() if l.startswith("RESULT_JSON:")]
    assert line, f"driver failed:\n{r.stdout[-800:]}\n{r.stderr[-1500:]}"
    return json.loads(line[0][len("RESULT_JSON:"):])


def jp_ok(buy=31.0, neutral=2.0, sell=67.0):
    return {"status": "ok", "buy_pct": buy, "neutral_pct": neutral, "sell_pct": sell,
            "categories": {SB: 10.0, B: 21.0, N: neutral, S: 30.0, SS: 37.0},
            "layout": "five_category", "parser_version": ss.JP_PARSER_VERSION,
            "fetched_at": "2026-10-13T06:00:00+00:00", "reason": "1 agreeing component(s)"}


JP_BASE = {"ticker": "7203.T", "hype_score": 55.0, "hype_mentions": 12.0,
           "hype": {"breakout_days": 2}, "price_date": "2026-10-09"}
US_BASE = {"ticker": "AAPL", "hype_score": 48.0, "hype_mentions": 40.0,
           "hype": {"breakout_days": 0}, "price_date": "2026-10-09"}
EVIL = "<img src=x onerror=alert(1)> **bold** [x](http://evil.example)"
UNUSABLE = lambda reason, status: {"status": status, "reason": reason, "buy_pct": None,
                                   "sell_pct": None, "neutral_pct": None}

# name -> record. Every record is rendered in BOTH languages.
RECORDS = {
    "jp_applied": dict(JP_BASE, jp_board=jp_ok(), jp_bull=31.0, jp_bear=67.0),
    "jp_not_applied": dict(JP_BASE, jp_board=jp_ok()),
    "jp_disabled": dict(JP_BASE, jp_forum_enabled=False),
    "jp_not_collected": dict(JP_BASE),
    "jp_no_heading": dict(JP_BASE, jp_forum_enabled=True,
                          jp_board=UNUSABLE("poll_heading_not_found", "unavailable")),
    "jp_no_votes": dict(JP_BASE, jp_forum_enabled=True, jp_board=UNUSABLE("no_votes", "unavailable")),
    "jp_parse_error": dict(JP_BASE, jp_forum_enabled=True,
                           jp_board=UNUSABLE("five_category_component_invalid", "parse_error")),
    "us_plain": dict(US_BASE),
    "st_ok": dict(US_BASE, stocktwits={"status": "ok", "score": 34.0, "label": "Bearish",
                                       "message_volume_score": 65.0, "window": "24h",
                                       "fetched_at": "2026-10-13T06:00:00+00:00"}),
    "st_not_configured": dict(US_BASE, stocktwits={"status": "not_configured"}),
    "st_rate_limited": dict(US_BASE, stocktwits={"status": "rate_limited", "score": None}),
    "st_circuit_open": dict(US_BASE, stocktwits={"status": "circuit_open", "score": None}),
    "st_unauthorized": dict(US_BASE, stocktwits={"status": "unauthorized", "score": None}),
    "st_ok_no_score": dict(US_BASE, stocktwits={"status": "ok", "score": None}),
    "st_evil_label": dict(US_BASE, stocktwits={"status": "ok", "score": 20.0, "label": EVIL,
                                               "message_volume_score": 5.0}),
    "uk_listing": {"ticker": "SHEL.L", "hype_score": float("nan"), "hype_mentions": float("nan")},
}


@pytest.fixture(scope="module")
def panel(tmp_path_factory):
    cases = {}
    for name, rec in RECORDS.items():
        for lang in ("en", "ja"):
            cases[f"{name}|{lang}"] = {"record": rec, "lang": lang}
    import time
    cases["context|en"] = {"record": US_BASE, "lang": "en", "fetched": time.time() - 600,
                           "status": "Buzz sources — Reddit API ✓ · GDELT live ✓"}
    results = _run_driver(PANEL_DRIVER, tmp_path_factory.mktemp("panel"), cases, PANEL_SCRIPT)
    for k, v in results.items():
        assert not v["exceptions"], (k, v["exceptions"])
    return results


def T(key, lang="en", **kw):
    import config
    return (config.TRANSLATIONS[lang].get(key) or config.TRANSLATIONS["en"][key]).format(**kw)


def md(r):
    return " | ".join(r["markdown"])


def caps(r):
    return r["caption"]


def infos(r):
    return r["info"]


def metrics(r):
    return r["metric"]


def jp_ok(buy=31.0, neutral=2.0, sell=67.0):
    return {"status": "ok", "buy_pct": buy, "neutral_pct": neutral, "sell_pct": sell,
            "categories": {SB: 10.0, B: 21.0, N: neutral, S: 30.0, SS: 37.0},
            "layout": "five_category", "parser_version": ss.JP_PARSER_VERSION,
            "fetched_at": "2026-10-13T06:00:00+00:00", "reason": "1 agreeing component(s)"}


JP_BASE = {"ticker": "7203.T", "hype_score": 55.0, "hype_mentions": 12.0,
           "hype": {"breakout_days": 2}, "price_date": "2026-10-09"}
US_BASE = {"ticker": "AAPL", "hype_score": 48.0, "hype_mentions": 40.0,
           "hype": {"breakout_days": 0}, "price_date": "2026-10-09"}


# ============================================================ the panel: every state, both languages
@pytest.mark.parametrize("lang", ["en", "ja"])
@pytest.mark.parametrize("name", ["jp_applied", "jp_disabled", "jp_not_collected", "us_plain",
                                  "st_not_configured", "uk_listing"])
def test_both_source_headings_are_always_present(panel, name, lang):
    text = md(panel[f"{name}|{lang}"])
    assert JP_TITLE in text, f"Japan board heading missing ({name}, {lang})"
    assert "Stocktwits" in text, f"Stocktwits heading missing ({name}, {lang})"
    assert T("hype_panel_title", lang) in text


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_japan_poll_values_and_applied_state(panel, lang):
    r = panel[f"jp_applied|{lang}"]
    m = metrics(r)
    assert m[T("crowd_jp_buy", lang)] == "31.00%" and m[T("crowd_jp_sell", lang)] == "67.00%"
    assert m[T("crowd_jp_neutral", lang)] == "2.00%"
    assert T("hype_jp_applied", lang) in caps(r)
    assert T("hype_feed_ok", lang) in caps(r)


def test_a_shown_poll_is_not_claimed_as_a_scoring_input_unless_it_was(panel):
    """Applied means this scan's score really received the poll, not merely that a record
    exists: here jp_bull/jp_bear are absent (the poll was not used)."""
    r = panel["jp_not_applied|en"]
    assert T("hype_jp_not_applied") in caps(r) and T("hype_jp_applied") not in caps(r)


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_disabled_not_collected_and_not_applicable_are_visible_states(panel, lang):
    off = panel[f"jp_disabled|{lang}"]
    assert T("hype_feed_disabled", lang) in caps(off) and T("hype_jp_disabled_hint", lang) in infos(off)
    none = panel[f"jp_not_collected|{lang}"]
    assert T("hype_feed_not_collected", lang) in caps(none) and T("hype_feed_scan_hint", lang) in infos(none)
    us = panel[f"us_plain|{lang}"]
    assert T("hype_feed_not_applicable", lang) in caps(us)         # Japan card on a US listing
    assert T("hype_feed_not_applicable", lang) in caps(panel[f"jp_not_collected|{lang}"])  # Stocktwits on .T


@pytest.mark.parametrize("name,reason", [("jp_no_heading", "poll_heading_not_found"),
                                         ("jp_no_votes", "no_votes"),
                                         ("jp_parse_error", "five_category_component_invalid")])
def test_unusable_polls_show_status_and_reason_never_a_number(panel, name, reason):
    r = panel[f"{name}|en"]
    assert T("hype_no_number") in infos(r)
    assert not any("%" in v for v in metrics(r).values()), "no percentage may appear"
    assert any(reason in t for t in r["text"]), "the reason is shown in the details"


def test_stocktwits_score_is_a_score_out_of_100_never_a_percentage(panel):
    r = panel["st_ok|en"]
    m = metrics(r)
    assert m[T("crowd_st_score")] == "34.0 /100" and m[T("crowd_st_attention")] == "65.0 /100"
    assert not any("%" in v for v in m.values()), "a 34/100 score must never render as a percentage"
    assert T("hype_st_not_percent") in caps(r) and T("hype_st_role") in caps(r)


@pytest.mark.parametrize("lang", ["en", "ja"])
def test_stocktwits_score_wording_in_both_languages(panel, lang):
    assert T("hype_st_not_percent", lang) in caps(panel[f"st_ok|{lang}"])


@pytest.mark.parametrize("status,hint_key", [("not_configured", "hype_st_credentials"),
                                             ("rate_limited", "hype_no_number"),
                                             ("circuit_open", "hype_no_number"),
                                             ("unauthorized", "hype_no_number")])
def test_stocktwits_failures_show_a_state_and_no_number(panel, status, hint_key):
    r = panel[f"st_{status}|en"]
    assert T(f"hype_feed_{status}") in caps(r) and T(hint_key) in infos(r)
    st_values = [v for k, v in metrics(r).items() if "/100" in v and k != T("factor_hype")]
    assert st_values == [], "missing data must not become 0 or 50"


def test_status_ok_without_a_score_is_not_rendered_as_a_value(panel):
    r = panel["st_ok_no_score|en"]
    assert T("hype_no_number") in infos(r)
    assert T("crowd_st_score") not in metrics(r)


def test_a_provider_label_is_literal_text_not_html_or_markdown(panel):
    r = panel["st_evil_label|en"]
    assert EVIL in r["text"], "label must be shown verbatim as text"
    assert "onerror" not in md(r) and "evil.example" not in md(r), "and never as markdown/HTML"
    assert not any("onerror" in c for c in caps(r) + infos(r))


def test_rendering_never_fetches_anything(panel):
    """Every case in the batch ran with urlopen and every data-source function replaced by
    a function that raises. Reaching here with no exception in any case proves the panel
    fetched nothing (the fixture asserts no case raised)."""
    assert len(panel) >= 33


def test_reddit_gdelt_context_is_kept_in_the_deep_dive(panel):
    """The patch's panel replaced a block that also explained what the mention count is
    and which feeds produced it; that context is restored."""
    c = caps(panel["context|en"])
    assert T("hype_buzz_caption") in c
    assert "Buzz sources — Reddit API ✓ · GDELT live ✓" in c
    assert any(x.startswith("Sentiment updated") for x in c)


def test_snapshot_caption_states_nothing_is_fetched(panel):
    assert any("2026-10-09" in c and "does not fetch" in c for c in caps(panel["us_plain|en"]))


# ============================================================ opt-in enforcement: run_engine
class _Any:
    def __call__(self, *a, **k): return self
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def __getitem__(self, i): return _Any()
    def __bool__(self): return False
    def __getattr__(self, n): return _Any()


class _St(types.ModuleType):
    session_state: dict = {}
    def __getattr__(self, n): return _Any()
    def columns(self, spec, **k):
        return [_Any() for _ in range(spec if isinstance(spec, int) else len(spec))]
    def cache_data(self, *a, **k): return (lambda f: f)
    def cache_resource(self, *a, **k): return (lambda f: f)


@pytest.fixture(scope="module")
def app():
    sys.modules["streamlit"] = _St("streamlit")
    sys.modules["yfinance"] = types.ModuleType("yfinance")
    sys.modules["altair"] = _St("altair")
    import importlib.util
    sys.path.insert(0, HERE)
    spec = importlib.util.spec_from_file_location("app_v213", os.path.join(HERE, "app.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


@pytest.fixture
def db(app, tmp_path):
    app.DB_PATH = str(tmp_path / "live.db")
    app.DEMO_DB_PATH = str(tmp_path / "demo.db")
    app.init_db()
    app.st.session_state.clear()
    return app


POLL_PAGE = (f"<html><body><section><h2>{HEAD}</h2>"
             + " ".join(f"{lab}{v}%" for lab, v in zip(ss.JP_LABELS, [60, 30, 5, 3, 2]))
             + "</section></html>")


def _frame():
    idx = pd.bdate_range("2026-01-05", periods=230)
    return pd.DataFrame({"Close": [100 * 1.001 ** i for i in range(230)],
                         "High": [101 * 1.001 ** i for i in range(230)],
                         "Low": [99 * 1.001 ** i for i in range(230)],
                         "Volume": [1e6] * 230}, index=idx)


def _scan_env(app, monkeypatch, calls):
    frame = _frame()
    monkeypatch.setattr(app, "_reddit_get", lambda url, headers=None: (calls.append(url), POLL_PAGE)[1])
    monkeypatch.setattr(app, "TICKER_UNIVERSE", {"Japan": ["7203.T"]})
    monkeypatch.setattr(app, "get_promoted_universe", lambda: {})
    monkeypatch.setattr(app, "get_histories", lambda syms, period="1y": {s: frame for s in syms})
    monkeypatch.setattr(app, "fetch_hype_signals", lambda *a, **k: {})
    monkeypatch.setattr(app, "fetch_fundamentals", lambda t: {
        "pe": 15.0, "div_yield": 1.0, "market_cap": 1e10, "roe": 0.1, "short_pct": 0.0,
        "payout": 0.3, "name": t, "sector": "", "industry": ""})
    return frame


def test_run_engine_default_makes_no_board_request(db, monkeypatch):
    app, calls = db, []
    _scan_env(app, monkeypatch, calls)
    res, _ = app.run_engine(regions=["Japan"], sources=[])            # NO use_jp_forum argument
    assert calls == [], "run_engine's own default must respect the experimental opt-in"
    assert res[0]["jp_forum_enabled"] is False
    assert res[0].get("jp_board") is None


def test_run_engine_with_the_toggle_on_still_fetches_and_scores(db, monkeypatch):
    """The opt-in must work in BOTH directions: switched on, the poll is used."""
    app, calls = db, []
    _scan_env(app, monkeypatch, calls)
    on, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=True)
    off, _ = app.run_engine(regions=["Japan"], sources=[], use_jp_forum=False)
    assert len(calls) == 1 and on[0]["jp_forum_enabled"] is True
    assert on[0]["jp_board"]["status"] == "ok" and (on[0]["jp_bull"], on[0]["jp_bear"]) == (90.0, 5.0)
    assert on[0]["hype_score"] != off[0]["hype_score"], "an enabled poll must reach the hype score"


def test_production_model_version_separates_opt_in_enforced_rows(app):
    assert app.PRODUCTION_MODEL_VERSION == "composite-v6-jp-opt-in-enforced-everywhere"


# ============================================================ opt-in enforcement: Sell Scanner
def _sell_env(app, monkeypatch, calls):
    frame = _scan_env(app, monkeypatch, calls)
    monkeypatch.setattr(app, "fetch_analyst_signals", lambda t: {
        "changes": [], "num_analysts": 0, "rec_key": "", "rec_mean": float("nan"),
        "target_mean": float("nan"), "currency": ""})
    monkeypatch.setattr(app, "fetch_insider_activity", lambda t: {
        "available": False, "buy_value": 0.0, "n_buys": 0, "n_sells": 0, "sell_value": 0.0})
    return frame


def _forum(out):
    return [s for s in out["signals"] if s[0] == "forum"][0]


def test_sell_scanner_ignores_the_board_while_the_toggle_is_off(db, monkeypatch):
    """v21.2 fetched the board and scored a 100 'euphoric — possible retail top' sell
    signal from the unverified parser even with the feature switched off."""
    app, calls = db, []
    frame = _sell_env(app, monkeypatch, calls)
    out = app.analyze_sell_signals("7203.T", hist=frame)
    assert calls == [] and _forum(out)[1] is None
    app.st.session_state["_jp_forum_on"] = False
    calls.clear()
    out = app.analyze_sell_signals("7203.T", hist=frame)
    assert calls == [] and _forum(out)[1] is None


def test_sell_scanner_uses_the_board_when_the_toggle_is_on(db, monkeypatch):
    app, calls = db, []
    frame = _sell_env(app, monkeypatch, calls)
    app.st.session_state["_jp_forum_on"] = True
    out = app.analyze_sell_signals("7203.T", hist=frame)
    assert len(calls) == 1 and _forum(out)[1] == 100.0, "enabled: a euphoric poll scores"


def test_sell_scanner_never_fetches_for_non_japanese_listings(db, monkeypatch):
    app, calls = db, []
    frame = _sell_env(app, monkeypatch, calls)
    app.st.session_state["_jp_forum_on"] = True
    app.analyze_sell_signals("AAPL", hist=frame)
    assert calls == []


# ============================================================ opt-in enforcement: the real hero button
HERO_SCRIPT = textwrap.dedent('''
    import os, sys, types, time, urllib.request, urllib.error
    time.sleep = lambda *_a, **_k: None                  # skip the app's request pacing
    import pandas as pd
    HERE = %r
    sys.path.insert(0, HERE)
    import config
    config.TICKER_UNIVERSE = {"Japan": ["7203.T"]}       # one name: keep the scan fast
    def _blocked(req, *a, **k):
        with open("requests.log", "a") as f: f.write(getattr(req, "full_url", str(req)) + "\\n")
        raise urllib.error.URLError("blocked in test")
    urllib.request.urlopen = _blocked
    yf = types.ModuleType("yfinance")
    yf.download = lambda *a, **k: pd.DataFrame()
    def _t(*a, **k): raise RuntimeError("blocked in test")
    yf.Ticker = _t
    sys.modules["yfinance"] = yf
    exec(compile(open(os.path.join(HERE, "app.py")).read(), "app.py", "exec"), globals())
''') % HERE

HERO_DRIVER = textwrap.dedent('''
    import json, os, sys
    from streamlit.testing.v1 import AppTest
    toggle_on = json.load(open(sys.argv[1]))["toggle_on"]
    open("requests.log", "w").close()
    at = AppTest.from_string(open(sys.argv[2]).read(), default_timeout=120)
    at.run()
    out = {"startup_exceptions": [e.value for e in at.exception]}
    tog = [t for t in at.sidebar.toggle if "Yahoo" in str(t.label)]
    out["toggle_present"] = bool(tog)
    out["toggle_default"] = tog[0].value if tog else None
    if toggle_on and tog:
        tog[0].set_value(True).run()
    hero = [b for b in at.button if b.key == "hero_scan_btn"]
    out["hero_present"] = bool(hero)
    # what the SIDEBAR toggle publishes for other pages (the Sell Scanner reads this)
    out["published_toggle"] = (at.session_state["_jp_forum_on"]
                               if "_jp_forum_on" in at.session_state else None)
    if hero:
        hero[0].click().run()
    out["exceptions"] = [e.value for e in at.exception]
    out["requests"] = [l for l in open("requests.log").read().splitlines() if "yahoo.co.jp" in l]
    print("RESULT_JSON:" + json.dumps(out))
''')


@pytest.fixture(scope="module")
def hero_runs(tmp_path_factory):
    out = {}
    for flag in (False, True):
        d = tmp_path_factory.mktemp(f"hero_{flag}")
        res = _run_driver(HERO_DRIVER, d, {"toggle_on": flag}, HERO_SCRIPT, timeout=240)
        assert not res["startup_exceptions"] and not res["exceptions"], res
        out[flag] = res
    return out


def test_the_japan_toggle_exists_and_defaults_to_off(hero_runs):
    r = hero_runs[False]
    assert r["toggle_present"] and r["toggle_default"] is False and r["hero_present"]


def test_the_sidebar_toggle_publishes_its_state_to_the_sell_scanner(hero_runs):
    """The Sell Scanner reads st.session_state['_jp_forum_on']. If the sidebar stopped
    publishing it, switching the poll ON would silently leave the Sell Scanner off (it
    falls back to the default), and no in-process test would notice."""
    assert hero_runs[False]["published_toggle"] is False
    assert hero_runs[True]["published_toggle"] is True


def test_hero_quick_scan_respects_the_toggle_when_off(hero_runs):
    """v21.2: clicking this button with the toggle OFF still made a board request per
    Japanese name (the call hard-coded use_jp_forum=True)."""
    assert hero_runs[False]["requests"] == []


def test_hero_quick_scan_uses_the_board_when_the_toggle_is_on(hero_runs):
    reqs = hero_runs[True]["requests"]
    assert len(reqs) == 1 and "7203.T" in reqs[0]


# ============================================================ labels and timestamps
JP_STATUSES = {"ok", "unavailable", "parse_error", "ambiguous", "network_error",
               "disabled", "not_collected", "not_applicable"}
ST_STATUSES = set(ss.STOCKTWITS_STATUSES) | {"budget_exhausted", "not_collected", "not_applicable"}


def test_every_status_the_code_can_produce_has_a_label_in_both_languages():
    """An unlabelled status would be shown to the user as a raw code. Checked by IMPORTING
    config (the new keys are added with TRANSLATIONS['en'].update(...) after the main
    dict, so a regex over the source does not see them)."""
    import config
    for status in sorted(JP_STATUSES | ST_STATUSES):
        key = "hype_feed_" + status
        for lang in ("en", "ja"):
            assert config.TRANSLATIONS[lang].get(key), f"{key} missing in {lang}"
        assert config.TRANSLATIONS["en"][key] != config.TRANSLATIONS["ja"][key]


def test_translation_tables_stay_in_parity():
    import config
    assert set(config.TRANSLATIONS["en"]) == set(config.TRANSLATIONS["ja"])


def test_status_labels_cover_what_the_record_builder_returns(app):
    rec = app._hype_source_record
    assert rec({"ticker": "AAPL"}, "jp_board")["status"] == "not_applicable"
    assert rec({"ticker": "7203.T"}, "jp_board")["status"] == "not_collected"
    assert rec({"ticker": "7203.T", "jp_forum_enabled": False}, "jp_board")["status"] == "disabled"
    assert rec({"ticker": "7203.T"}, "stocktwits")["status"] == "not_applicable"
    assert rec({"ticker": "SHEL.L"}, "stocktwits")["status"] == "not_applicable"
    assert rec({"ticker": "AAPL"}, "stocktwits")["status"] == "not_collected"


def test_timestamps_keep_their_offset_and_never_invent_utc(app):
    f = app._hype_timestamp
    assert f("2026-10-13T06:00:00+00:00") == "2026-10-13T06:00+00:00"
    assert f("2026-10-13T15:00:00+09:00") == "2026-10-13T15:00+09:00"
    assert f("2026-10-13T06:00:00Z") == "2026-10-13T06:00+00:00"
    assert f("2026-10-13T06:00:00") == "2026-10-13T06:00", "an unknown timezone is NOT labelled UTC"
    assert f(None) == "\u2014" and f("") == "\u2014"
    assert f("not a date") == "not a date"


# ============================================================ typo
def test_japanese_board_is_spelled_with_the_right_kanji():
    """掲示板 (bulletin board). 掛示板 is not a word; it had crept into two user-visible
    Sell Scanner strings."""
    for f in ("app.py", "config.py", "indicators.py", "sentiment_sources.py"):
        assert "掛示板" not in open(os.path.join(HERE, f), encoding="utf-8").read(), f
